import 'package:flutter/material.dart';

import '../HomeScreen/BottomTabBarScreen/multipleHomeScreen/subCategory.dart';

class SubCategorySearchpage extends SearchDelegate{
  List<String> searchTerms = [
    "Plumber",
    "Electrian",
    "Doctor",
    "Psychologist",
    "Ethologist",
    "Surgeon",
    "Endocrinologist",
    "Oncologists",
    "Pediatrician",
    "Psychiatrists",
    "Radiologist",
    "Veterinarian"
  ];
  @override
  List<Widget>? buildActions(BuildContext context) {
    // TODO: implement buildActions
    return [
      IconButton(onPressed: (){
        query = '';
      }, icon: Icon(Icons.clear))
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    // TODO: implement buildLeading
    return IconButton(onPressed: (){
      close(context, null);
    }, icon: Icon(Icons.arrow_back,color: Colors.black,));
  }

  @override
  Widget buildResults(BuildContext context) {
    // TODO: implement buildResults
    throw UnimplementedError();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // TODO: implement buildSuggestions
    List<String> matchQuery = [];
    for (var fruit in CustomData.mydata) {
      if (fruit['name'].toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(fruit['name']);
      }
    }
    return ListView.builder(
      itemCount: matchQuery.length,
      itemBuilder: (context, index) {
        var result = matchQuery[index];
        return ListTile(
          title: Text(result),
        );
      },
    );
  }

}
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:solution_key/appcolor.dart';

class SetMeeting extends StatefulWidget {
  const SetMeeting({super.key});

  @override
  State<SetMeeting> createState() => _SetMeetingState();
}

class _SetMeetingState extends State<SetMeeting> {
  bool light = true;
  bool lighty = false;
  TimeOfDay timeofday = TimeOfDay.now();
  TimeOfDay endtimeofday = TimeOfDay.now();



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
       // centerTitle: true,
        title: Text('Set Your Online Hours',style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500),),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
              height: 30,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                ),
                  onPressed: (){}, child: Text('Next',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500,fontSize: 15),)),
            ),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Online All Days',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  SizedBox(
                    height: 10,
                    child: Switch(
                      // This bool value toggles the switch.
                      value: light,
                      activeColor: appcolor.appcolors,
                      onChanged: (bool value) {
                        // This is called when the user toggles the switch.
                        setState(() {
                          light = value;
                          print(value);
                        });
                      },
                    ),
                  )
                ],
              ),
              SizedBox(height: 10,),
              Text('You can set a same time or online and offline for all day',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 14),),
              SizedBox(height: 10,),
              Row(
                children: [
                  InkWell(
                    onTap: () async {
                      final TimeOfDay? timeofDay = await showTimePicker(
                          context: context,
                          initialTime: timeofday,
                          initialEntryMode: TimePickerEntryMode.dial,
                          builder: (context, Widget? child) {
                          return MediaQuery(
                            data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
                            child: child!,
                          );
                        },
                      );
                      if(timeofDay != null){
                        setState(() {
                          timeofday = timeofDay;
                        });
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black,width: 1),
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('${timeofday == null ? '09:00 AM': '${timeofday.format(context)}'}',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                      ),
                    ),
                  ),
                  SizedBox(width: 10,),
                  InkWell(
                    onTap: ()async{
                      final TimeOfDay? timeofDay = await showTimePicker(
                        context: context,
                        initialTime: timeofday.replacing(hour: timeofday.hour),
                        initialEntryMode: TimePickerEntryMode.dial,
                        builder: (context, Widget? child) {
                          return MediaQuery(
                            data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
                            child: child!,
                          );
                        },
                      );
                      if(timeofDay != null){
                        setState(() {
                          endtimeofday = timeofDay;
                        });
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black,width: 1),
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('${endtimeofday == null?'06:00 PM': '${endtimeofday.format(context)}'}',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                      ),
                    ),
                  )
                ],
              ),
              TextButton(onPressed: (){
              }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
              SizedBox(height: 10,),
              Container(
                color: Colors.black,
                height: 1,
              ),
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Customize All Days',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  SizedBox(
                    height: 10,
                    child: Switch(
                      // This bool value toggles the switch.
                      value: lighty,
                      activeColor: appcolor.appcolors,
                      onChanged: (bool value) {
                        // This is called when the user toggles the switch.
                        setState(() {
                          lighty = value;
                        });
                      },
                    ),
                  )
                ],
              ),
              SizedBox(height: 10,),
              Text('You can set different time or online and offline for   everyday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 14),),
              SizedBox(height: 10,),
              if(lighty == true)setVaccationWeakly()
            ],
          ),
        ),
      ),
    );
  }
}
class setVaccationWeakly extends StatefulWidget {
  const setVaccationWeakly({super.key});

  @override
  State<setVaccationWeakly> createState() => _setVaccationWeaklyState();
}

class _setVaccationWeaklyState extends State<setVaccationWeakly> {
  bool sunday = true;
  bool monday = true;
  bool tuesday = true;
  bool wenesday = true;
  bool thursday = true;
  bool friday = true;
  bool saturday = true;
  String? _timeString;
  TimeOfDay timeofdaysunday = TimeOfDay.now();
  TimeOfDay timeofdaysundyEnd = TimeOfDay.now();

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Column(
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Sunday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                SizedBox(
                  height: 10,
                  child: Switch(
                    // This bool value toggles the switch.
                    value: sunday,
                    activeColor: appcolor.appcolors,
                    onChanged: (bool value) {
                      // This is called when the user toggles the switch.
                      setState(() {
                        sunday = value;

                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                InkWell(
                  onTap: () async{
                    final TimeOfDay? timeofDay = await showTimePicker(
                      context: context,
                      initialTime: timeofdaysunday,
                      initialEntryMode: TimePickerEntryMode.dial,
                      builder: (context, Widget? child) {
                        return MediaQuery(
                          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
                          child: child!,
                        );
                      },
                    );
                    if(timeofDay != null){
                      setState(() {
                        timeofdaysunday = timeofDay;
                      });
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black,width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(5)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('${timeofdaysunday == null?'09:00 AM':'${timeofdaysunday.format(context)}'}',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                    ),
                  ),
                ),
                SizedBox(width: 10,),
                InkWell(
                  onTap: ()async{
                    final TimeOfDay? timeofDay = await showTimePicker(
                      context: context,
                      initialTime: timeofdaysunday,
                      initialEntryMode: TimePickerEntryMode.dial,
                      builder: (context, Widget? child) {
                        return MediaQuery(
                          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
                          child: child!,
                        );
                      },
                    );
                    if(timeofDay != null){
                      setState(() {
                        timeofdaysundyEnd = timeofDay;
                      });
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black,width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(5)),

                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('${timeofdaysundyEnd== null?'06:00 PM':'${timeofdaysundyEnd.format(context)}'}',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                    ),
                  ),
                )
              ],
            ),
            TextButton(onPressed: (){
            }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
            Container(color: Colors.black,height: 1,width: size.width,),
            SizedBox(height: 10,),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Monday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                SizedBox(
                  height: 10,
                  child: Switch(
                    // This bool value toggles the switch.
                    value: monday,
                    activeColor: appcolor.appcolors,
                    onChanged: (bool value) {
                      // This is called when the user toggles the switch.
                      setState(() {
                        monday = value;
                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                InkWell(
                  onTap: (){

                  },
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black,width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(5)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('09:00 AM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                    ),
                  ),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('06:00 PM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                )
              ],
            ),
            TextButton(onPressed: (){

            }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
            Container(color: Colors.black,height: 1,width: size.width,),
            SizedBox(height: 10,),

          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Tuesday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                SizedBox(
                  height: 10,
                  child: Switch(
                    // This bool value toggles the switch.
                    value: tuesday,
                    activeColor: appcolor.appcolors,
                    onChanged: (bool value) {
                      // This is called when the user toggles the switch.
                      setState(() {
                        tuesday = value;

                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('09:00 AM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('06:00 PM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                )
              ],
            ),
            TextButton(onPressed: (){

            }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
            Container(color: Colors.black,height: 1,width: size.width,),
            SizedBox(height: 10,),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Wenesday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                SizedBox(
                  height: 10,
                  child: Switch(
                    // This bool value toggles the switch.
                    value: wenesday,
                    activeColor: appcolor.appcolors,
                    onChanged: (bool value) {
                      // This is called when the user toggles the switch.
                      setState(() {
                        wenesday = value;

                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('09:00 AM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('06:00 PM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                )
              ],
            ),
            TextButton(onPressed: (){

            }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
            Container(color: Colors.black,height: 1,width: size.width,),
            SizedBox(height: 10,),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Thursday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                SizedBox(
                  height: 10,
                  child: Switch(
                    // This bool value toggles the switch.
                    value: thursday,
                    activeColor: appcolor.appcolors,
                    onChanged: (bool value) {
                      // This is called when the user toggles the switch.
                      setState(() {
                        thursday = value;

                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('09:00 AM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('06:00 PM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                )
              ],
            ),
            TextButton(onPressed: (){

            }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
            Container(color: Colors.black,height: 1,width: size.width,),
            SizedBox(height: 10,),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Friday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                SizedBox(
                  height: 10,
                  child: Switch(
                    // This bool value toggles the switch.
                    value: friday,
                    activeColor: appcolor.appcolors,
                    onChanged: (bool value) {
                      // This is called when the user toggles the switch.
                      setState(() {
                        friday = value;

                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('09:00 AM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('06:00 PM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                )
              ],
            ),
            TextButton(onPressed: (){

            }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
            Container(color: Colors.black,height: 1,width: size.width,),
            SizedBox(height: 10,),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Saturday',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                SizedBox(
                  height: 10,
                  child: Switch(
                    // This bool value toggles the switch.
                    value: saturday,
                    activeColor: appcolor.appcolors,
                    onChanged: (bool value) {
                      // This is called when the user toggles the switch.
                      setState(() {
                        saturday = value;

                      });
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('09:00 AM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(5)),

                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('06:00 PM',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                  ),
                )
              ],
            ),
            TextButton(onPressed: (){

            }, child: Text('+ Add New Slot',style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500),)),
            Container(color: Colors.black,height: 1,width: size.width,),
            SizedBox(height: 10,),
          ],
        ),

      ],
    );
  }
  void _getTime() {
    final DateTime now = DateTime.now();
    final String formattedDateTime = _formatDateTime(now);
    setState(() {
      _timeString = formattedDateTime;
    });
  }

  String _formatDateTime(DateTime dateTime) {
    return DateFormat('MM/dd/yyyy hh:mm:ss').format(dateTime);
  }
}




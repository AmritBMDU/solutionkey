import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:solution_key/LoginPage.dart';
import 'HomeScreen/mainScreen.dart';

class otp_verfication extends StatefulWidget {
  const otp_verfication({super.key});

  @override
  State<otp_verfication> createState() => _ForgotPasswod();
}

class _ForgotPasswod extends State<otp_verfication> {
  bool passwordVisible=false;
  bool passwordVisible1=false;

  TextEditingController email = TextEditingController();
  TextEditingController pasword = TextEditingController();
  TextEditingController cpasswod= TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    passwordVisible=true;

  }
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          SizedBox(height: 100,),
          Center(child: Text('Enter Verification Code', style: TextStyle(fontWeight: FontWeight.w600,fontSize: 25,color: Color(0xff1f42ba)),)),
          SizedBox(height: 20,),
          SizedBox(height: 30,),

          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: SizedBox(
              height: size.height * 0.06,
              child: TextFormField(
                controller: pasword,
                keyboardType: TextInputType.visiblePassword,
                obscureText: passwordVisible,
                decoration: InputDecoration(
                  hintText: 'Password',
                  fillColor: Color(0xfff1f3ff
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  filled: true,
                  suffixIcon: IconButton(
                    icon: Icon(passwordVisible
                        ? Icons.visibility
                        : Icons.visibility_off),
                    onPressed: () {
                      setState(
                            () {
                          passwordVisible = !passwordVisible;
                        },
                      );
                    },
                  ),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(11),
                      ),
                      borderSide: BorderSide()
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0xff1f42ba)
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(11))
                  ),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Username cannot be empty";
                  }else if(value.length < 6){
                    return "Password length should be atleast 6";
                  }
                  return null;
                },
                onChanged: (value) {
                  //  name = value;
                  setState(() {});
                },
              ),
            ),
          ),
          SizedBox(height: 25,),




          SizedBox(
            width: MediaQuery.of(context).size.width * 0.89,
            child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    shape: BeveledRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(3))
                    ),
                    backgroundColor: Color(0xff1f42ba

                    )
                ),
                onPressed: (){
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> MainPage()));
                }, child: Text('Verify OTP',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w300,color: Colors.white),)),
          ),
          TextButton(onPressed: (){
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage()));
          }, child: Text('Back to Login ',style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400,color: Colors.black),)),
          SizedBox(height: 60,),
          Text('Or Continue with',style: TextStyle(color: Color(0xff1f42ba)),),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.google,color: Colors.black,)),

              ),
              SizedBox(width: 10,),
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.facebook,color: Colors.black,)),

              ),
              SizedBox(width: 10,),
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.apple,color: Colors.black,)),

              ),
            ],
          )

        ],
      ),
    );
  }
}

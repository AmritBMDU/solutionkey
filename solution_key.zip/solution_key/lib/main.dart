import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';
import 'package:solution_key/DetailPage/Widget/filters/Gender_filters/gender_filter.dart';
import 'package:solution_key/DetailPage/Widget/filters/Location_filter.dart';
import 'package:solution_key/DetailPage/Widget/filters/experience_filter/experience.dart';
import 'package:solution_key/DetailPage/Widget/filters/subcategories_filter/sub_categories.dart';
import 'package:solution_key/DetailPage/detail_Screen.dart';

import 'SplashScreen.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Color(0xff1f42ba)
  ));
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home:SplashScreen()
    );
  }
}


// import 'package:flutter/material.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('City Filter'),
//         ),
//         body: Center(
//           child: CityFilter(),
//         ),
//       ),
//     );
//   }
// }

// class CityFilter extends StatefulWidget {
//   @override
//   _CityFilterState createState() => _CityFilterState();
// }

// class _CityFilterState extends State<CityFilter> {
//   // Define lists for states and cities
//   List<String> states = ['Uttar Pradesh', 'Punjab', 'Delhi'];
//   Map<String, List<String>> cities = {
//     'Uttar Pradesh': ['Ghaziabad', 'Noida', 'Agra'],
//     'Punjab': ['Jalandhar', 'Mohali', 'Chandigarh'],
//     'Delhi': ['New Delhi', 'Chandni Chowk', 'Parliament'],
//   };

//   String selectedState = 'Uttar Pradesh';
//   String selectedCity = 'Ghaziabad';

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(16.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           DropdownButton<String>(
//             value: selectedState,
//             onChanged: (String? newState) {
//               setState(() {
//                 selectedState = newState!;
//                 selectedCity = cities[selectedState]![0];
//               });
//             },
//             items: states.map<DropdownMenuItem<String>>((String value) {
//               return DropdownMenuItem<String>(
//                 value: value,
//                 child: Text(value),
//               );
//             }).toList(),
//           ),
//           SizedBox(height: 20),
//           DropdownButton<String>(
//             value: selectedCity,
//             onChanged: (String? newCity) {
//               setState(() {
//                 selectedCity = newCity!;
//               });
//             },
//             items: cities[selectedState]!.map<DropdownMenuItem<String>>((String value) {
//               return DropdownMenuItem<String>(
//                 value: value,
//                 child: Text(value),
//               );
//             }).toList(),
//           ),
//         ],
//       ),
//     );
//   }
// }




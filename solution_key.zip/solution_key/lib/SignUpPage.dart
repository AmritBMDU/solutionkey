import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:solution_key/LoginPage.dart';
import 'package:solution_key/mainPage.dart';

import 'HomeScreen/mainScreen.dart';
import 'Widget/elevatedButtn.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPage();
}

class _SignUpPage extends State<SignUpPage> {
  bool passwordVisible=false;
  bool passwordVisible1=false;

  TextEditingController email = TextEditingController();
  TextEditingController pasword = TextEditingController();
  TextEditingController cpasswod= TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    passwordVisible=true;
  }
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          SizedBox(height: 100,),
          Center(child: Text('Create Account', style: TextStyle(fontWeight: FontWeight.w600,fontSize: 25,color: Color(0xff1f42ba)),)),
          SizedBox(height: 20,),
          Center(child: Text('Create an account so you can explore all the\n                    existing jobs!' , style: TextStyle(fontWeight: FontWeight.w600,fontSize: 14,),)),
          SizedBox(height: 30,),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: Container(
              height: size.height * 0.09,
              child: TextField(
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  decoration: InputDecoration(
                    hintText: 'Mobile Number',
                    fillColor: Color(0xfff1f3ff
                    ),
                    suffixIcon: Icon(Icons.phone),
                    contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                    filled: true,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(11),
                        ),
                        borderSide: BorderSide(color: Colors.grey)
                    ),
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Color(0xff1f42ba),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(11))
                    ),
                  )
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: SizedBox(
              height: size.height * 0.06,
              child: TextFormField(
                controller: pasword,
                keyboardType: TextInputType.visiblePassword,
                obscureText: passwordVisible,
                decoration: InputDecoration(
                  hintText: 'Password',
                  fillColor: Color(0xfff1f3ff
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  filled: true,
                    suffixIcon: IconButton(
                      icon: Icon(passwordVisible
                          ? Icons.visibility
                          : Icons.visibility_off),
                      onPressed: () {
                        setState(
                              () {
                            passwordVisible = !passwordVisible;
                          },
                        );
                      },
                    ),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(11),
                      ),
                      borderSide: BorderSide()
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0xff1f42ba)
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(11))
                  ),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Username cannot be empty";
                  }else if(value.length < 6){
                    return "Password length should be atleast 6";
                  }
                  return null;
                },
                onChanged: (value) {
                  //  name = value;
                  setState(() {});
                },
              ),
            ),
          ),
          SizedBox(height: 25,),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: SizedBox(
              height: size.height * 0.06,
              child: TextFormField(
                controller: cpasswod,
                keyboardType: TextInputType.visiblePassword,
                obscureText: passwordVisible1,
                decoration: InputDecoration(
                  hintText: 'Conform Password',
                  fillColor: Color(0xfff1f3ff
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  filled: true,
                  suffixIcon: IconButton(
                    icon: Icon(passwordVisible1
                        ? Icons.visibility
                        : Icons.visibility_off),
                    onPressed: () {
                      setState(
                            () {
                          passwordVisible1 = !passwordVisible1;
                        },
                      );
                    },
                  ),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(11),
                      ),
                      borderSide: BorderSide()
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0xff1f42ba)
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(11))
                  ),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Username cannot be empty";
                  }else if(value.length < 6){
                    return "Password length should be atleast 6";
                  }
                  return null;
                },
                onChanged: (value) {
                  //  name = value;
                  setState(() {});
                },
              ),
            ),
          ),
          SizedBox(height: 20,),
          elevated(context: context,name: 'signup',navigative: MainPage()),
          TextButton(onPressed: (){
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage()));
          }, child: Text('Already have an account',style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400,color: Colors.black),)),
          SizedBox(height: 60,),
          Text('Or Continue with',style: TextStyle(color: Color(0xff1f42ba)),),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.google,color: Colors.black,)),
              ),
              SizedBox(width: 10,),
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.facebook,color: Colors.black,)),
              ),
              SizedBox(width: 10,),
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.apple,color: Colors.black,)),
              ),
            ],
          )

        ],
      ),
    );
  }
}

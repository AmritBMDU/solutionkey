

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pinput/pinput.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Reset_password.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/multipleHomeScreen/HomePage.dart';
import 'package:solution_key/SignUpPage.dart';
import 'package:solution_key/appcolor.dart';
import 'package:solution_key/forgot_pin.dart';


import 'fogot_password/ForgotPasswod.dart';
import 'HomeScreen/mainScreen.dart';
import 'Widget/customtextformfield.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool passwordVisible=false;
  TextEditingController password = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();
  final _formKey = GlobalKey<FormState>();
  
 
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    passwordVisible=true;
  }
  @override
  Widget build(BuildContext context) {
     const focusedBorderColor = Color.fromRGBO(23, 171, 144, 1);
    const fillColor = Color.fromRGBO(243, 246, 249, 0);
    const borderColor = Color.fromRGBO(23, 171, 144, 0.4);
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: const TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: borderColor),
      ),
    );
    var size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Form(
        key: _formKey,
        child:  Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 60,),
            Container(
                height: MediaQuery.of(context).size.height *0.4,
                width: MediaQuery.of(context).size.height ,
                child: Image.asset('assets/imgpsh_fullsize_anim 2.png',fit: BoxFit.contain,)),
        
             Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 Padding(
                   padding: const EdgeInsets.only(left:20),
                   child: Text("Login with your PIN",style: TextStyle(fontWeight: FontWeight.bold,color: appcolor.appcolors),),
                 ),
                 TextButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>ForgotPinScreen()));
                 }, child: Text("Forgot Your PIN?"))
               ],
             ),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Directionality(
                         // Specify direction if desired
                         textDirection: TextDirection.ltr,
                         child: Pinput(
                           controller: pinController,
                           focusNode: focusNode,
                           androidSmsAutofillMethod:
                               AndroidSmsAutofillMethod.smsUserConsentApi,
                           listenForMultipleSmsOnAndroid: true,
                           //defaultPinTheme: defaultPinTheme,
                           separatorBuilder: (index) => const SizedBox(width: 8),
                           validator: (value) {
                            return value == '2222' ? null : 'PIN is incorrect';
                           },
                           // onClipboardFound: (value) {
                           //   debugPrint('onClipboardFound: $value');
                           //   pinController.setText(value);
                           // },
                           hapticFeedbackType: HapticFeedbackType.lightImpact,
                           onCompleted: (pin) {
                            debugPrint('onCompleted: $pin');
                           },
                           onChanged: (value) {
                            debugPrint('onChanged: $value');
                           },
                           cursor: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                               Container(
                 margin: const EdgeInsets.only(bottom: 9),
                 width: 22,
                 height: 1,
                 color: focusedBorderColor,
                               ),
                            ],
                           ),
                           focusedPinTheme: defaultPinTheme.copyWith(
                            decoration: defaultPinTheme.decoration!.copyWith(
                               borderRadius: BorderRadius.circular(8),
                               border: Border.all(color: focusedBorderColor),
                            ),
                           ),
                           submittedPinTheme: defaultPinTheme.copyWith(
                            decoration: defaultPinTheme.decoration!.copyWith(
                               color: fillColor,
                               borderRadius: BorderRadius.circular(19),
                               border: Border.all(color: focusedBorderColor),
                            ),
                           ),
                           errorPinTheme: defaultPinTheme.copyBorderWith(
                            border: Border.all(color: Colors.redAccent),
                           ),
                         ),
                       ),
              ),
            ),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: (){
                  Navigator.pop(context);
                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                       shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(5.0),
  ),
                      color: Colors.grey.shade300,
                      
                      child: Center(child: Text("Go Back",style: TextStyle(color: appcolor.appcolors))),
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder:(context)=>MainPage()));
                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                      shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(5.0),
  ),
                      color: appcolor.appcolors,
                      
                      child: Center(child: Text("Login",style: TextStyle(color: Colors.white),)),
                    ),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
                        TextButton(
              onPressed: (){
                
              },
              child: Text("By Logging in, you are agree to our Terms & Conditions ",textAlign: TextAlign.center,style: TextStyle(color: appcolor.black,),)),

              SizedBox(
                height: 20,
              ),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
               children: [
                Text("Don't have an account?",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                 InkWell(onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>HomePage()));
                 }, child:Text("Sign Up",style: TextStyle(color: appcolor.appcolors,fontSize: 16,fontWeight: FontWeight.bold),)),
               ],
             )

          ],
        ),
      ),
    );
  }
}



import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Reset_password.dart';
import 'package:solution_key/SignUpPage.dart';
import 'package:solution_key/appcolor.dart';


import 'fogot_password/ForgotPasswod.dart';
import 'HomeScreen/mainScreen.dart';
import 'Widget/customtextformfield.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool passwordVisible=false;
  TextEditingController password = TextEditingController();
  TextEditingController email = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    passwordVisible=true;
  }
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Form(
        key: _formKey,
        child:  Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 60,),
            Container(
                height: MediaQuery.of(context).size.height *0.4,
                width: MediaQuery.of(context).size.height ,
                child: Image.asset('assets/imgpsh_fullsize_anim 2.png',fit: BoxFit.contain,)),
        
             Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 Padding(
                   padding: const EdgeInsets.only(left:20),
                   child: Text("Login with your PIN",style: TextStyle(fontWeight: FontWeight.bold,color: appcolor.appcolors),),
                 ),
                 TextButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Reset_password()));
                 }, child: Text("Forgot Your Pin?"))
               ],
             ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 70,
                child: Card(
                  color: Colors.white,
                  elevation: 10,
                   shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(20.0),
  ),
                 // child: 
                 child: Padding(
                   padding: const EdgeInsets.all(8.0),
                   child: TextFormField(
                    
                    decoration: InputDecoration(
                      hintText: "Enter Your Pin",
                      border: InputBorder.none
                    ),
                   ),
                 ),
              ),
            ),
            ),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: (){
                  Navigator.pop(context);
                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                       shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(20.0),
  ),
                      color: Colors.grey.shade300,
                      
                      child: Center(child: Text("Go Back",style: TextStyle(color: appcolor.appcolors))),
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder:(context)=>MainPage()));
                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                      shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(20.0),
  ),
                      color: appcolor.appcolors,
                      
                      child: Center(child: Text("Login",style: TextStyle(color: Colors.white),)),
                    ),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Center(child: Text("By Logging in, you are agree to our",style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.bold),)),
             InkWell(
              onTap: (){

              },
              child: Center(child: Text("Terms & Conditions and Privacy Policies",style: TextStyle(color: appcolor.newRedColor,fontWeight: FontWeight.bold,),))),

              SizedBox(
                height: 20,
              ),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
               children: [
                Text("Don't have an account?",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                 InkWell(onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUpPage()));
                 }, child:Text("Sign Up",style: TextStyle(color: appcolor.appcolors,fontSize: 16,fontWeight: FontWeight.bold),)),
               ],
             )

          ],
        ),
      ),
    );
  }
}

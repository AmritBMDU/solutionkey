

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:solution_key/SignUpPage.dart';


import 'fogot_password/ForgotPasswod.dart';
import 'HomeScreen/mainScreen.dart';
import 'Widget/customtextformfield.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool passwordVisible=false;
  TextEditingController password = TextEditingController();
  TextEditingController email = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    passwordVisible=true;
  }
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            SizedBox(height: 100,),
            Center(child: Text('Login here', style: TextStyle(fontWeight: FontWeight.w600,fontSize: 25,color: Color(0xff1f42ba)),)),
            SizedBox(height: 20,),
            Center(child: Text('Welcome back you have \n        been missed!' , style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20,),)),
            SizedBox(height: 30,),
            // Padding(
            //   padding: const EdgeInsets.only(left: 15,right: 15),
            //   child: customtextformfield(
            //     obsure: true,
            //     bottomLineColor: Colors.black,
            //     hinttext: 'Email',
            //     suffixIcon: Icon(Icons.email),
            //     newIcon: Icon(Icons.email,color: appcolor.appcolors,),
            //     key_type: TextInputType.visiblePassword,
            //     horizontalcontentPadding: 10,
            //     verticalContentPadding: 10,
            //      validator: (value) {
            //       if (value!.isEmpty) {
            //         return "Username cannot be empty";
            //       }
            //       return null;
            //     },
            //
            //
            //   ),
            // ),
            // Padding(
            //   padding: const EdgeInsets.only(right: 15,left: 15),
            //   child: Container(
            //     decoration: BoxDecoration(
            //         borderRadius: BorderRadius.all(Radius.circular(11))
            //     ),
            //     height: size.height * 0.1,
            //     child: customtextformfield(
            //         bottomLineColor: Colors.black,
            //         hinttext: 'Password',
            //         suffixIcon: Icon(Icons.password),
            //         newIcon: Icon(Icons.password,color: appcolor.appcolors,),
            //         key_type: TextInputType.visiblePassword,
            //         maxLength: 10,
            //         horizontalcontentPadding: 10,
            //         verticalContentPadding: 10,
            //       validator: (value) {
            //           if (value!.isEmpty) {
            //             return "Username cannot be empty";
            //           }else if(value.length < 6){
            //             return "Password length should be atleast 6";
            //           }
            //           return null;
            //         },
            //
            //
            //     ),
            //   ),
            // ),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: SizedBox(
                height: size.height * 0.09,
                child: TextField(
                  maxLength: 10,
                  controller: email,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(
                        horizontal: 10,vertical: 10),
                    hintText: 'Mobile Number',
                    fillColor: Color(0xfff1f3ff
                    ),
                    suffixIcon: Icon(Icons.phone),
                    filled: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(11),
                      ),
                      borderSide: BorderSide(color: Colors.grey)
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0xff1f42ba),
                    ),
                      borderRadius: BorderRadius.all(Radius.circular(11))
                  ),
                ),
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: SizedBox(
                height: size.height * 0.06,
                child: TextFormField(
                  controller: password,
                  keyboardType: TextInputType.visiblePassword,
                    obscureText: passwordVisible,
                    decoration: InputDecoration(
                      alignLabelWithHint: false,
                      filled: true,
                      hintText: 'Password',
                      fillColor: Color(0xfff1f3ff
                      ),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      suffixIcon: IconButton(
                        icon: Icon(passwordVisible
                            ? Icons.visibility
                            : Icons.visibility_off),
                        onPressed: () {
                          setState(
                                () {
                              passwordVisible = !passwordVisible;
                            },
                          );
                        },
                      ),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(11),
                          ),
                          borderSide: BorderSide()
                      ),

                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xff1f42ba)
                          ),
                        borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                    ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Username cannot be empty";
                    }else if(value.length < 6){
                      return "Password length should be atleast 6";
                    }
                    return null;
                   },
                  onChanged: (value) {
                  //  name = value;
                    setState(() {});
                  },
                  textInputAction: TextInputAction.done,
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>ForgotPasswod()));
                }, child: Text('Forgot your password?',style: TextStyle(color: Color(0xff1f42ba)),))
              ],
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.87,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      shape: BeveledRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(3))
                      ),
                      backgroundColor: Color(0xff1f42ba
                      )
                  ),
                  onPressed: (){
                    if(email.text == '' && password.text == ''){
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please Enter Email and Password')));
                    }else if(password.text.length < 6){
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please Enter Six Digit Password')));
                    }else{
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MainPage()));

                    }
                  }, child: Text('Sign in',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w300,color: Colors.white),)),
            ),
            TextButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUpPage()));
            }, child: Text('Create an account',style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400,color: Colors.black),)),
            SizedBox(height: 60,),
            Text('Or Continue with',style: TextStyle(color: Color(0xff1f42ba)),),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                  height: 50,
                  width: 50,
                  child: Center(child: FaIcon(FontAwesomeIcons.google,color: Colors.black,)),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                      color: Color(0xffececec),
                      borderRadius: BorderRadius.all(Radius.circular(11))                ),
                  height: 50,
                  width: 50,
                  child: Center(child: FaIcon(FontAwesomeIcons.facebook,color: Colors.black,)),
                ),
                SizedBox(width: 10,),
                Container(
                  decoration: BoxDecoration(
                      color: Color(0xffececec),
                      borderRadius: BorderRadius.all(Radius.circular(11))                ),
                  height: 50,
                  width: 50,
                  child: Center(child: FaIcon(FontAwesomeIcons.apple,color: Colors.black,)),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

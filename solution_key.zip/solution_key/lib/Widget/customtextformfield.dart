import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';

import 'gradient_text.dart';


Widget customtextformfield({
  bool ? obsure,
  bool ? readOnly,
  Color? hintTextColor,
  Color? bottomLineColor,
  String? hinttext,
  String? label,
  TextEditingController? controller,
  Widget? suffixIcon,
  bool showPassword = false,
  TextInputType? key_type,
  Widget? newIcon,
  Function()? callback,
  var validator,
  int? maxLength,
  double? horizontalcontentPadding,
  double? verticalContentPadding,
  Gradient? gradient,
  InputBorder? border,
  bool ? enabled,
}) {
  return Padding(
    padding: const EdgeInsets.all(1.0),
    child: Container(
      padding: EdgeInsets.symmetric(
        horizontal: 10,
      ),
      child: TextFormField(
        onTap: callback,
        readOnly: readOnly==null?false:readOnly,
        enabled: enabled,
        cursorHeight: 20,
        cursorColor: hintTextColor == null ? appcolor.black : hintTextColor,
        validator: validator,
        keyboardType: key_type,
        controller: controller,
        obscureText: showPassword,
        maxLength: maxLength,

        style: TextStyle(
          decorationStyle: TextDecorationStyle.dotted,
          decoration: TextDecoration.none,
          color: hintTextColor == null ? appcolor.black : hintTextColor,
          fontSize: 15,
        ),
        decoration: InputDecoration(
          // label: Row(
          //   children: [
          //     Text(hinttext.toString(),style: TextStyle(color: Colors.black,fontSize: 13),),
          //     Text(label==null?'':label.toString(),style: TextStyle(color: appcolor.appcolors),)
          //   ],
          // ),
          counter: Offstage(),
          alignLabelWithHint: false,
          contentPadding:
          EdgeInsets.symmetric(
            horizontal:
                horizontalcontentPadding == null ? 0 : horizontalcontentPadding,
            vertical: verticalContentPadding == null ? 0 : verticalContentPadding,
          ),

          suffixIcon:
          InkWell(
            onTap: callback,
            child: gradient == null
                ? Container(
                    child: GradientText(
                      gradient:appcolor.gradient,
                      widget: showPassword == false ? newIcon : newIcon,
                    ),
                  )
                : Container(
                    child: newIcon,
                  ),
          ),
          hintText: hinttext,
          hintStyle: TextStyle(
            color: hintTextColor == null ? Colors.black :  hintTextColor,
            fontSize: 15,
          ),
          fillColor:  Color(0xfff1f3ff),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: bottomLineColor == null
                  ? Colors.grey
                  : bottomLineColor,
            ),
          ),
          focusedBorder:border==null? OutlineInputBorder(
            borderSide: BorderSide(
              color: hintTextColor == null ?appcolor.appcolors : hintTextColor,
            ),
          ):border,
          border: OutlineInputBorder(
             borderRadius: BorderRadius.all(Radius.circular(11),
        ),
        ),
      ),
    ),
  )
  );

}
// Padding(
//   padding: const EdgeInsets.all(15.0),
//   child: TextField(
//     keyboardType: TextInputType.visiblePassword,
//     decoration: InputDecoration(
//       hintText: 'Email',
//       fillColor: Color(0xfff1f3ff
//       ),
//       filled: true,
//       border: OutlineInputBorder(
//         borderRadius: BorderRadius.all(Radius.circular(11),
//         ),
//         borderSide: BorderSide(color: Colors.grey)
//       ),
//       focusedBorder: OutlineInputBorder(
//         borderSide: BorderSide(color: Color(0xff1f42ba),
//       ),
//         borderRadius: BorderRadius.all(Radius.circular(11))
//     ),
//   ),
//
//   ),
// ),

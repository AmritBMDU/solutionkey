import 'package:flutter/material.dart';
import '../HomeScreen/mainScreen.dart';

Widget elevated({context, name,navigative}){
  return   SizedBox(
    width: MediaQuery.of(context).size.width * 0.89,
    child: ElevatedButton(
        style: ElevatedButton.styleFrom(
            shape: BeveledRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(3))
            ),
            backgroundColor: Color(0xff1f42ba)
        ),
        onPressed: (){
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> navigative));
        }, child: Text('$name',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w300,color: Colors.white),)),
  );
}
import 'package:flutter/material.dart';

import 'LoginPage.dart';
import 'SignUpPage.dart';

class mainPage extends StatefulWidget {
  const mainPage({super.key});

  @override
  State<mainPage> createState() => _mainPageState();
}

class _mainPageState extends State<mainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
              height: MediaQuery.of(context).size.height *0.55,
              width: MediaQuery.of(context).size.height ,
              child: Image.asset('assets/imgpsh_fullsize_anim 2.png',fit: BoxFit.contain,)),

          Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('  Discover Your \nDream Job here',style: TextStyle(fontSize: 35,fontWeight: FontWeight.w700,color: Color(0xff1f42ba
                )),),
                SizedBox(height: 20,),
                Text('Explore all the existing job roles based on \n      your interest and Study major',style: TextStyle(fontSize: 16,fontWeight: FontWeight.w700,
                ),),
                SizedBox(height: 80,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            shape: BeveledRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(3))
                            ),
                            backgroundColor: Color(0xff1f42ba

                            )
                        ),
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginPage()));
                        }, child: Text('Login',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),)),
                    TextButton(onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUpPage()));
                    }, child: Text('Register',style: TextStyle(fontWeight: FontWeight.bold,fontSize:20,color: Colors.black),))

                  ],
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:solution_key/appcolor.dart';

import 'LoginPage.dart';
import 'SignUpPage.dart';

class mainPage extends StatefulWidget {
  const mainPage({super.key});

  @override
  State<mainPage> createState() => _mainPageState();
}

class _mainPageState extends State<mainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 60,),
            Container(
                height: MediaQuery.of(context).size.height *0.4,
                width: MediaQuery.of(context).size.height ,
                child: Image.asset('assets/imgpsh_fullsize_anim 2.png',fit: BoxFit.contain,)),
        
             Padding(
               padding: const EdgeInsets.only(left:30),
               child: Text("Login with your mobile number",style: TextStyle(fontWeight: FontWeight.bold,color: appcolor.appcolors),),
             ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 65,
                child: Card(
                   shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(20.0),
  ),
                 
                  color: Colors.white,
                  elevation: 10,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: IntlPhoneField(
                                   //   focusNode: focusNode,
                      decoration: InputDecoration(
                        labelText: 'Phone Number',
                        border: InputBorder.none
                      ),
                      languageCode: "en",
                      initialCountryCode: "IN",
                      onChanged: (phone) {
                        print(phone.completeNumber);
                      },
                      onCountryChanged: (country) {
                        print('Country changed to: ' + country.name);
                      },
                    ),
                  ),
              ),
            ),
            ),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));
                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                       shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(20.0),
  ),
                      
                      color: Colors.grey.shade300,
                      
                      child: Center(child: Text("Login With Pin",style: TextStyle(color: appcolor.appcolors))),
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    //  Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));

                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                     shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(20.0),
  ),
                      color: appcolor.appcolors,
                      
                      child: Center(child: Text("Get OTP",style: TextStyle(color: Colors.white),)),
                    ),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Center(child: Text("By Logging in, you are agree to our",style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.bold),)),
             InkWell(
              onTap: (){

              },
              child: Center(child: Text("Terms & Conditions and Privacy Policies",style: TextStyle(color: appcolor.newRedColor,fontWeight: FontWeight.bold,),))),

              SizedBox(
                height: 20,
              ),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
               children: [
                Text("Don't have an account?",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                 InkWell(onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUpPage()));
                 }, child:Text("Sign Up",style: TextStyle(color: appcolor.appcolors,fontSize: 16,fontWeight: FontWeight.bold),)),
               ],
             )

          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:solution_key/appcolor.dart';

import 'LoginPage.dart';
import 'SignUpPage.dart';

class mainPage extends StatefulWidget {
  const mainPage({super.key});

  @override
  State<mainPage> createState() => _mainPageState();
}

class _mainPageState extends State<mainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 60,),
            Container(
                height: MediaQuery.of(context).size.height *0.4,
                width: MediaQuery.of(context).size.height ,
                child: Image.asset('assets/imgpsh_fullsize_anim 2.png',fit: BoxFit.contain,)),
        
             Padding(
               padding: const EdgeInsets.only(left:30),
               child: Text("Login with your mobile number",style: TextStyle(fontWeight: FontWeight.bold,color: appcolor.appcolors),),
             ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 65,
                child: Card(
                   shape: RoundedRectangleBorder( //<-- SEE HERE
    // side: BorderSide(
    //   color: Colors.grey,
    // ),
    borderRadius: BorderRadius.circular(5.0),
  ),
                 
                  color: Colors.white,
                  elevation: 10,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(children: [
                      CircleAvatar(
                        radius: 15,
                      backgroundImage: AssetImage("assets/india.png"),
                      ),
                      SizedBox(width: 10,),
                      Container(
                        height: 30,
                        width: 1,
                        color: Colors.grey.shade500,
                      ),
                      SizedBox(width: 10,),
                      Padding(
                        padding: const EdgeInsets.only(left:5.0,right: 5,bottom: 5),
                        child: Text("+91",style: TextStyle(color: Colors.grey.shade700,fontWeight: FontWeight.bold),),
                      ),
                      Expanded(
                        child: TextFormField(
                          style: TextStyle(color: Colors.grey.shade700,fontWeight: FontWeight.bold ),
                          keyboardType: TextInputType.phone,
                          maxLength: 10,
                        // maxLengthEnforcement:,
                          decoration: InputDecoration(

                            
                            counterText: "",
                            border:InputBorder.none,
                            hintText: "Phone number"
                          ),
                        ),
                      )

                    ],)
                  ),
              ),
            ),
            ),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: (){
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));
                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                       shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(5.0),
  ),
                      
                      color: Colors.white,
                      
                      child: Center(child: Text("Login With Pin",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w700))),
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    //  Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));

                  },
                  child: Container(
                    height: 60,
                    width: 170,
                    child: Card(
                     shape: RoundedRectangleBorder( //<-- SEE HERE
    side: BorderSide(
      color: Colors.grey,
    ),
    borderRadius: BorderRadius.circular(5.0),
  ),
                      color: appcolor.appcolors,
                      
                      child: Center(child: Text("Get OTP",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)),
                    ),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            //Center(child: Text("By Logging in, you are agree to our",style: TextStyle(color: appcolor.black,),)),
             TextButton(
              onPressed: (){
                
              },
              child: Text("By Logging in, you are agree to our Terms & Conditions ",textAlign: TextAlign.center,style: TextStyle(color: appcolor.black,),)),

              SizedBox(
                height: 20,
              ),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
               children: [
                Text("Don't have an account?",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                 InkWell(onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUpPage()));
                 }, child:Text("Sign Up",style: TextStyle(color: appcolor.appcolors,fontSize: 16,fontWeight: FontWeight.bold),)),
               ],
             )

          ],
        ),
      ),
    );
  }
}

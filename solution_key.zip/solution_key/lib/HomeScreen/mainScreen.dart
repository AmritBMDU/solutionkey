



import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/CatergoryData/Trending.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/CatergoryData/calling.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Bookmarks.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/HelpCenter/Help.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/History.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Profile.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Reset_password.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/User_Profile.dart';

import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/YourContact.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/favourite.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/legal_notice.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/message.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/schdule.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/upload_document.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/multipleHomeScreen/HomePage.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/wallet/wallet.dart';
import 'package:solution_key/appcolor.dart';
import 'package:solution_key/mainPage.dart';
import 'package:solution_key/notification.dart';
import 'package:solution_key/seachPage/SeacrhPage.dart';
import 'package:solution_key/seachPage/SetMetting.dart';


late String stringResponse;
late String mapResponse;
late String dataResponse ;

class MainPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() =>_MainPage();
}
class _MainPage extends State<MainPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int selectedItem = 0;
  var _pageData = [
    HomePage(),
    Trending(),
    Calling(),
    Schedule()
  ];

  @override
  Widget build(BuildContext context) {

    return WillPopScope(
      onWillPop: () async{
        final value =  await showDialog<bool>(
          context: context,
          builder: (context) =>
              AlertDialog(
                title: Text('Are you sure?', style: TextStyle(color: Colors.blueGrey),),
                content: Text('Do you want to exit?', style: TextStyle(color: Colors.blueGrey),),
                actions: <Widget>[
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: appcolor.appcolors,
                      shape: BeveledRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2))
                      )
                    ),
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text('No', style: TextStyle(color: Colors.white),),
                  ),
                SizedBox(height: 30,),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: appcolor.appcolors,
                        shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(2))
                        )
                    ),
                    onPressed: () => Navigator.of(context).pop(true),
                    child: Text('Yes', style: TextStyle(color: Colors.white),),
                  ),
                ],
              ),
        ); if(value !=null){
          return Future.value(value);
        }else{
          return Future.value(false);
        }
      },

      child: Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          leading:  Padding(
                    padding: const EdgeInsets.only(left: 15),
                    child: InkWell(
                      onTap: () {
                      _scaffoldKey.currentState!.openDrawer();
                      },
                      highlightColor: Colors.transparent,
                      child: CircleAvatar(
                        radius: 40,
                        child: Text("SB"),
                        backgroundColor: appcolor.greyColor,
                        
                      ),
                    ),
                  ),
          automaticallyImplyLeading: false,
          actions: [
                        Container(
               child: Row(
                children: [
                 
               //   Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
                  SizedBox(
                    width: 10,
                  ),
                  IconButton(onPressed:() {
                     Navigator.push(context, MaterialPageRoute(builder:(context)=>notifcation()));
                  }, icon: Icon(Icons.notifications_outlined)),
                  IconButton(onPressed:() {
                     Navigator.push(context, MaterialPageRoute(builder:(context)=>Favourite()));
                  }, icon: Icon(Icons.favorite_outline,)),
                  IconButton(onPressed:() {
                  showSearch(
                                        context: context,
                                        delegate: Searchpage());
                  }, icon:Icon(Icons.search_outlined)),
                  IconButton(onPressed: (){Navigator.push(context, MaterialPageRoute(builder:(BuildContext context)=>FilterPage()));}, icon: Icon(Icons.filter_alt_outlined))
                ],
               ),
              ),
        ],
        elevation: 5,
        ),
        drawer: Drawer(
       child: ListView(
        // Important: Remove any padding from the ListView.
        padding: EdgeInsets.zero,
        children: [
          SizedBox(
            height: 30,
          ),
           Padding(
             padding: const EdgeInsets.symmetric(vertical: 20,horizontal: 10),
             child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder:(context)=>User_Profile()));
              },
              
               child: Container(
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: appcolor.appcolors
               
                ),
                  child:Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.center,
                    
                      children: [
                       CircleAvatar(
                            radius: 25,
                            child: Text("SB"),
                            backgroundColor: appcolor.greyColor,
                            
                          ),
                          SizedBox(width: 20,),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                             Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 16,color:Colors.white),),
                             Text("Logged in via 8979034037",style: GoogleFonts.poppins(fontSize: 12,color: Colors.white),) 
                            ],
                          ),
                         
                      ],
                    ),
                  )
                         ),
             ),
             
           ),
       listTile(
                    title: 'Call Logs',
                    icon: Icons.call_end_outlined,
                    callback: (){

                      Navigator.push(context, MaterialPageRoute(builder: (context)=>YourContact()));
                    }
                ),
              
              listTile(
                  title: 'Transcation',
                  icon: Icons.payment_outlined,
                  callback: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Bookmarks()));
                  }
              ),
              listTile(
                  title: 'History',
                  icon: Icons.history_outlined,
                  callback: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>History()));
                  }
              ),
              listTile(
                title: "Upload Documents",
                icon: Icons.upload_file,
                callback: (){
                  Navigator.push(context, MaterialPageRoute(builder:(context)=>MyFilePickerWidget()));
                }
              ),
              listTile(
                  title: 'Wallet',
                  icon: Icons.payment_outlined,
                  callback: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>wallet()));
                  }
              ),
              listTile(
                  title: 'Schedule',
                  icon: Icons.schedule_outlined,
                  callback: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Schedule()));
                  }
              ),
              listTile(
                title: 'Message',
                  icon: Icons.message_outlined,
                callback: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Message()));
                }
              ),
              listTile(
                title:"Favorite ",
                icon: (Icons.favorite_outline) ,
                callback: () {
                  Navigator.push(context, MaterialPageRoute(builder:(context) => Favourite(),));
                },
              ),
              listTile(
                title:"Reset Password",
                icon: (Icons.password) ,
                callback: () {
                    Navigator.push(context, MaterialPageRoute(builder:(context) => Reset_password(),));
                },
              ),
              listTile(
                title:"Support",
                icon: (Icons.support_rounded) ,
                callback: () {
                  Navigator.push(context,MaterialPageRoute(builder:(context) => LegalNotice(),));
                },
              ),
              Divider(
                height: 2,
                color: Colors.grey.shade400,
              ),
              listTile(
                  title: 'Logout',
                  icon: Icons.logout_outlined,
                  callback: (){

                      showDialog(
                          context: context,
                          builder: (context){
                            return AlertDialog(
                              title: Text('Alert'),
                              content: Text('Are you sure exit?'),
                              actions: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ElevatedButton(onPressed: (){
                                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));

                                    }, child: Text('Yes')),
                                    ElevatedButton(onPressed: (){
                                      Navigator.pop(context);
                                    }, child: Text('No')),
                                  ],
                                )
                              ],
                            );
                          });
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));
                  }
              ),
        
        ],
      ),
      
    
    ),
        resizeToAvoidBottomInset: false,
        bottomNavigationBar: BottomNavigationBar(
          elevation: 5,
        //  fixedColor: appcolor.appcolors,
          backgroundColor: Color.fromARGB(255, 234, 204, 234),
          unselectedItemColor: Colors.black,
          showUnselectedLabels: true,
          selectedItemColor: appcolor.appcolors,
          items: [
            BottomNavigationBarItem(icon: FaIcon(FontAwesomeIcons.house),
                label: 'Home', ),
            BottomNavigationBarItem(icon: FaIcon(FontAwesomeIcons.globe),label: 'Trending ', ),
            BottomNavigationBarItem(icon: FaIcon(FontAwesomeIcons.phone),label: 'Calling', ),
            BottomNavigationBarItem(icon: FaIcon(FontAwesomeIcons.person),label: 'Schedule',),
          ],
          currentIndex: selectedItem,
          onTap: (setvalue) {
            setState(() {
              selectedItem = setvalue;
            });
          },
        ),
        body:
        Container(
          color: Colors.orange,
          child: Center(
            child: _pageData[selectedItem],
          ),
        ),

      ),
    );
  }
}
Widget listTile({String? title, icon, Function()? callback}){
  return ListTile(
    onTap: callback,
    title: Text('$title',style: GoogleFonts.poppins(fontWeight:FontWeight.w300,fontSize:18),),
    leading: Icon(icon,color: appcolor.appcolors,),
  );
}

// class Mydrawer extends StatefulWidget {
//    Mydrawer({super.key});

//   @override
//   State<Mydrawer> createState() => _MydrawerState();
// }

// class _MydrawerState extends State<Mydrawer> {
//   @override
//   Widget build(BuildContext context) {
//     return  Drawer(
//       width: MediaQuery.of(context).size.width*0.5,
//        child: ListView(
//         // Important: Remove any padding from the ListView.
//         padding: EdgeInsets.zero,
//         children: [
//           SizedBox(
//             height: 30,
//           ),
//            Padding(
//              padding: const EdgeInsets.symmetric(vertical: 20,horizontal: 10),
//              child: Container(
//               height: 100,
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(15),
//                 color: appcolor.appcolors

//               ),
//                 child:Padding(
//                   padding: const EdgeInsets.only(left: 10),
//                   child: Row(crossAxisAlignment: CrossAxisAlignment.center,
                  
//                     children: [
//                      CircleAvatar(
//                           radius: 25,
//                           child: Text("SB"),
//                           backgroundColor: appcolor.greyColor,
                          
//                         ),
//                         SizedBox(width: 20,),
//                         Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                            Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 16,color:Colors.white),),
//                            Text("Logged in via 8979034037",style: GoogleFonts.poppins(fontSize: 12,color: Colors.white),) 
//                           ],
//                         ),
                       
//                     ],
//                   ),
//                 )
//                        ),
             
//            ),
//        listTile(
//                     title: 'Call Logs',
//                     icon: Icons.call_end_outlined,
//                     callback: (){

//                       Navigator.push(context, MaterialPageRoute(builder: (context)=>YourContact()));
//                     }
//                 ),
              
//               listTile(
//                   title: 'Transcation',
//                   icon: Icons.payment_outlined,
//                   callback: (){
//                     Navigator.push(context, MaterialPageRoute(builder: (context)=>Bookmarks()));
//                   }
//               ),
//               listTile(
//                   title: 'History',
//                   icon: Icons.history_outlined,
//                   callback: (){
//                     Navigator.push(context, MaterialPageRoute(builder: (context)=>History()));
//                   }
//               ),
//               listTile(
//                   title: 'Wallet',
//                   icon: Icons.payment_outlined,
//                   callback: (){
//                     Navigator.push(context, MaterialPageRoute(builder: (context)=>wallet()));
//                   }
//               ),
//               listTile(
//                   title: 'Schedule',
//                   icon: Icons.schedule_outlined,
//                   callback: (){
//                     Navigator.push(context, MaterialPageRoute(builder: (context)=>Schedule()));
//                   }
//               ),
//               listTile(
//                 title: 'Message',
//                   icon: Icons.message_outlined,
//                 callback: (){
//                   Navigator.push(context, MaterialPageRoute(builder: (context)=>Message()));
//                 }
//               ),
//               listTile(
//                 title:"Favorite ",
//                 icon: (Icons.favorite_outline) ,
//                 callback: () {
//                   Navigator.push(context, MaterialPageRoute(builder:(context) => Favourite(),));
//                 },
//               ),
//               listTile(
//                 title:"Legal Notice",
//                 icon: (Icons.report) ,
//                 callback: () {
//                     Navigator.push(context, MaterialPageRoute(builder:(context) => LegalNotice(),));
//                 },
//               ),
//               listTile(
//                 title:"Support",
//                 icon: (Icons.support_rounded) ,
//                 callback: () {
//                   Navigator.push(context,MaterialPageRoute(builder:(context) => LegalNotice(),));
//                 },
//               ),
//               Divider(
//                 height: 2,
//                 color: Colors.grey.shade400,
//               ),
//               listTile(
//                   title: 'Logout',
//                   icon: Icons.logout_outlined,
//                   callback: (){

//                       showDialog(
//                           context: context,
//                           builder: (context){
//                             return AlertDialog(
//                               title: Text('Alert'),
//                               content: Text('Are you sure exit?'),
//                               actions: [
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                                   children: [
//                                     ElevatedButton(onPressed: (){
//                                       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));

//                                     }, child: Text('Yes')),
//                                     ElevatedButton(onPressed: (){
//                                       Navigator.pop(context);
//                                     }, child: Text('No')),
//                                   ],
//                                 )
//                               ],
//                             );
//                           });
//                       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));
//                   }
//               ),
        
//         ],
//       ),
      
    
//     );
//   }
// }

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MyFilePickerWidget extends StatefulWidget {
  @override
  _MyFilePickerWidgetState createState() => _MyFilePickerWidgetState();
}

class _MyFilePickerWidgetState extends State<MyFilePickerWidget> {
  String filePath = '';
  TextEditingController descriptionController = TextEditingController();

  void _pickDocument() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result != null) {
      setState(() {
        filePath = result.files.single.path!;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Document Upload',style:GoogleFonts.poppins()),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Image.asset("assets/upload.png"),
              SizedBox(height: 16.0),
              Center(
                child: Text(
                  'Selected File: $filePath',
                  style: TextStyle(fontSize: 16.0),
                ),
              ),
              SizedBox(height: 30.0),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  labelText: 'Document Description',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16.0),
                ElevatedButton(
                onPressed: _pickDocument,
                child: Text('Select Document'),
                style:ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(color: Colors.orangeAccent)
                  )
                )
              ),SizedBox(height: 10,),
              ElevatedButton(
                onPressed: () {
                  // Handle the document upload with file path and description
                  print('File Path: $filePath');
                  print('Description: ${descriptionController.text}');
                },
                 style:ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(color: Colors.orangeAccent)
                  )
                ),
                child: Text('Upload Document'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

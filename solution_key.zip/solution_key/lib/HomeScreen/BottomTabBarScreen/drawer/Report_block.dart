import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';


class Report_block extends StatefulWidget {
  const Report_block({super.key});

  @override
  State<Report_block> createState() => _Report_block();
}
class _Report_block extends State<Report_block> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Report & Blocks',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        // endDrawer: Drawers(context),
        resizeToAvoidBottomInset: false,

        body: Center(
          child: Image.asset('assets/NodataFound.png'),
        )
    );

  }


}





import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/appcolor.dart';
import 'package:solution_key/seachPage/SeacrhPage.dart';

class LegalNotice extends StatefulWidget {
  const LegalNotice({super.key});

  @override
  State<LegalNotice> createState() => _LegalNoticeState();
}

class _LegalNoticeState extends State<LegalNotice> {
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(actions: [
                        Container(
               child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10,right: 10),
                    child: InkWell(
                      onTap: () {
                   
                      },
                      highlightColor: Colors.transparent,
                      child: CircleAvatar(
                        radius: 30,
                        child: Text("SB"),
                        backgroundColor: appcolor.greyColor,
                        
                      ),
                    ),
                  ),
                  Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
                  SizedBox(
                    width: 25,
                  ),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.notifications_outlined)),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.favorite_outline,)),
                 
                ],
               ),
              ),
        ],
        elevation: 5,
        ),
      body: Column(
        children: [
            Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                  elevation: 5,
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(11)),
                      color: appcolor.greyColor
                    ),
                    width: MediaQuery.of(context).size.width,
                    child: Container(
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.search,color:appcolor.black,),
                              SizedBox(width: 10,),
                              InkWell(
                                  onTap: (){
                                    showSearch(context: context, delegate: Searchpage());
                                  },
                                  child: Text('What are you looking for?',style: GoogleFonts.poppins(fontWeight: FontWeight.w400,),)),
                            ],
                          ),
                          
                      
                        ],
                      ),
                    )
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 100,
              ),
       Image.asset('assets/NodataFound.png')


        ],
      ),
    ) ;
  }
}
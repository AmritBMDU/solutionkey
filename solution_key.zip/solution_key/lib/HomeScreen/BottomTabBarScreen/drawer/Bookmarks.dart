
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/appcolor.dart';


class Bookmarks extends StatefulWidget {
  const Bookmarks({super.key});

  @override
  State<Bookmarks> createState() => _Report_block();
}
class _Report_block extends State<Bookmarks> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
         appBar: AppBar(actions: [
                        Container(
               child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10,right: 10),
                    child: InkWell(
                      onTap: () {
                   
                      },
                      highlightColor: Colors.transparent,
                      child: CircleAvatar(
                        radius: 30,
                        child: Text("SB"),
                        backgroundColor: appcolor.greyColor,
                        
                      ),
                    ),
                  ),
                  Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
                  SizedBox(
                    width: 25,
                  ),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.notifications_outlined)),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.favorite_outline,)),
                 
                ],
               ),
              ),
        ],
        elevation: 5,
        ),
        resizeToAvoidBottomInset: false,
        // endDrawer: Drawers(context),
        body: Center(
          child: Image.asset('assets/NodataFound.png'),
        )
    );

  }


}





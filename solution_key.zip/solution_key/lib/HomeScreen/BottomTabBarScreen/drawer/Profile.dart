import 'dart:io';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/HelpCenter/Help.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/History.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Reset_password.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/User_Profile.dart';
import 'package:solution_key/appcolor.dart';
import 'package:solution_key/mainPage.dart';

import '../../../Widget/gradient_text.dart';
import '../../../seachPage/SetMetting.dart';
import 'Bookmarks.dart';
import 'Report_block.dart';
import 'YourContact.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  bool isSelected = false;
  File? SelectedImage;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body:Padding(
        padding: const EdgeInsets.only(left: 20,right: 20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 80,),
              InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>User_Profile()));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Stack(
                      children:[
                        CircleAvatar(
                        radius: 50,
                       backgroundImage:  AssetImage('assets/img_2.png'),

                       // backgroundImage: SelectedImage ==null ? Image(image: Image.file(SelectedImage!),): NetworkImage(),
                      ),
                        Positioned(
                            top: 60,
                            left: 60,
                            child: CircleAvatar(
                              radius: 20,
                               backgroundColor: appcolor.appcolors,
                                child: Center(
                                 child: IconButton(
                                  onPressed: (){

                              },icon: Icon(Icons.camera_alt,color: Colors.white,),
                            ),
                          ),
                        ))
          ]
                    ),
                    SizedBox(width: 10,),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Rahul ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:18),),
                        Text('abc@gmail.com',style: TextStyle(fontWeight:FontWeight.w400,fontSize:15),),
                      ],
                    ),

                  ],
                ),
              ),
             SizedBox(height: 30,),
             InkWell(
               onTap: (){
                 showDialog(
                     barrierDismissible: false,
                     context: context, builder: (context){
                   return AlertDialog(
                     title:Text('Age Confirmation Alert! ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:18),),
                     content:Row(
                       mainAxisAlignment: MainAxisAlignment.start,
                       crossAxisAlignment: CrossAxisAlignment.start,
                       children: [
                         // Checkbox(
                         //   checkColor: Colors.white,
                         //   // fillColor: Colors.red,
                         //   value: isSelected,
                         //   onChanged: (bool? value) {
                         //     setState(() {
                         //       isSelected = value!;
                         //     });
                         //   },
                         // ),
                         Text('Consultants must be 18 years,\nclick here to conform you are 18 \nyears and above',style: TextStyle(fontSize: 12),)
                       ],
                     ),
                     actions: [
                       ElevatedButton(
                           style:ElevatedButton.styleFrom(
                       backgroundColor: appcolor.appcolors
                   ),
                           onPressed: (){
                           Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>SetMeeting()));
                       }, child: Text('Next',style: TextStyle(color: Colors.white),))
                     ],
                   );
                 });
               },
               child: Container(
                 decoration: BoxDecoration(
                   border: Border.all(width: 1)
                 ),
                 height: 50,
                 child: Padding(
                   padding: const EdgeInsets.all(8.0),
                   child: Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       Text('Become Consulant',style: TextStyle(fontWeight:FontWeight.w400,fontSize:15,color: Colors.grey),),
                       Icon(Icons.arrow_forward_ios,color: appcolor.appcolors,)
                     ],
                   ),
                 ),
               ),
             ),
              SizedBox(height: 20,),


              // Card(
              //   child: Padding(
              //     padding: const EdgeInsets.all(8.0),
              //     child: Container(
              //       child: Column(
              //         children: [
              //           Row(
              //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //             children: [
              //               Column(
              //                 children: [
              //                   Text('Registered Email',style: TextStyle(fontWeight:FontWeight.w400,fontSize:15,color: Colors.grey),),
              //                   Text('abc@gmail.com',style: TextStyle(fontWeight:FontWeight.w400,fontSize:15),),
              //                 ],
              //               ),
              //               IconButton(onPressed: (){},icon: Icon(Icons.edit,color: appcolor.appcolors,),)
              //
              //             ],
              //           )
              //         ],
              //       ),
              //     ),
              //   ),
              // ),
              SizedBox(height: 20,),
              Card(
                child: listTile(
                    title: 'Your Contact List',
                    icon: Icons.contact_phone,
                    callback: (){

                      Navigator.push(context, MaterialPageRoute(builder: (context)=>YourContact()));
                    }
                ),
              ),
              Card(
                child: listTile(
                    title: 'Bookmars',
                    icon: Icons.bookmark,
                    callback: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Bookmarks()));
                    }
                ),
              ),
              Card(
                child: listTile(
                    title: 'History',
                    icon: Icons.history,
                    callback: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>History()));
                    }
                ),
              ),
              Card(
                child: listTile(
                    title: 'Report & Blocks',
                    icon: Icons.report,
                    callback: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Report_block()));
                    }
                ),
              ),
              Card(
                child: listTile(
                    title: 'Reset Password',
                    icon: Icons.lock_reset_rounded,
                    callback: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Reset_password()));
                    }
                ),
              ),
              Card(
                child: listTile(
                  title: 'Help',
                    icon: Icons.help,
                  callback: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Help()));
                  }
                ),
              ),
              Card(
                child:listTile(
                    title: 'Log Out',
                    icon: Icons.logout_outlined,
                    callback: (){

                        showDialog(
                            context: context,
                            builder: (context){
                              return AlertDialog(
                                title: Text('Alert'),
                                content: Text('Are you sure exit?'),
                                actions: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      ElevatedButton(onPressed: (){
                                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));

                                      }, child: Text('Yes')),
                                      ElevatedButton(onPressed: (){
                                        Navigator.pop(context);
                                      }, child: Text('No')),
                                    ],
                                  )
                                ],
                              );
                            });
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));
                    }
                ),
              ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.start,
              //   children: [
              //     Icon(Icons.contact_phone,color: appcolor.appcolors,),
              //     SizedBox(width: 10,),
              //     Text('Your Contact List',style: TextStyle(fontWeight:FontWeight.w400,fontSize:18),),
              //
              //   ],
              // ),
              // SizedBox(height: 15,),
              // Container(height: 1,color: Colors.grey,),
              //
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.start,
              //   children: [
              //     Icon(Icons.bookmark,color: appcolor.appcolors,),
              //     SizedBox(width: 10,),
              //     Text('Bookmarks',style: TextStyle(fontWeight:FontWeight.w400,fontSize:18),),
              //
              //   ],
              // ),
              // SizedBox(height: 15,),
              // Container(height: 1,color: Colors.grey,),
              // SizedBox(height: 10,),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.start,
              //   children: [
              //     Icon(Icons.report,color: appcolor.appcolors,),
              //     SizedBox(width: 10,),
              //     Text('Report & Blocks',style: TextStyle(fontWeight:FontWeight.w400,fontSize:18),),
              //
              //   ],
              // ),
              // SizedBox(height: 15,),
              // Container(height: 1,color: Colors.grey,),
              // SizedBox(height: 10,),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.start,
              //   children: [
              //     Icon(Icons.help,color: appcolor.appcolors,),
              //     SizedBox(width: 10,),
              //     Text('Help',style: TextStyle(fontWeight:FontWeight.w400,fontSize:18),),
              //
              //   ],
              // ),
              // SizedBox(height: 15,),
              // Container(height: 1,color: Colors.grey,),
              // SizedBox(height: 10,),

            ],
          ),
        ),
      ),
    );
  }

}
Widget listTile({String? title, icon, Function()? callback}){
  return ListTile(
    onTap: callback,
    title: Text('$title',style: GoogleFonts.poppins(fontWeight:FontWeight.w300,fontSize:18),),
    leading: Icon(icon,color: appcolor.appcolors,),
  );
}
Widget customwidget({
  Function()? callback,
  String? assetimagepath,
  String? title,
}) {
  return InkWell(
    onTap: callback,
    child: Column(
      children: [
        Container(
          child: PhysicalShape(
            elevation: 1,
            clipper: ShapeBorderClipper(shape: CircleBorder()),
            color: Color(0xffEEEEEE),
            child: Container(
                height: 80,
                width: 100,
                child: Image.asset(assetimagepath.toString(),fit: BoxFit.cover,)
            ),
          ),
        ),
        SizedBox(height: 10,),

        // CircleAvatar(
        //   radius: 39,
        //   backgroundColor: appcolor.greyColor,
        //   child:Image.asset(assetimagepath.toString(),fit: BoxFit.cover,)
        //   ),

        GradientText(
          widget: Text(
            '$title',
            style: TextStyle(
              fontSize: 14,color: appcolor.appcolors,
            ),
          ),
          gradient: appcolor.gradient,
        ),
      ],
    ),
  );
}



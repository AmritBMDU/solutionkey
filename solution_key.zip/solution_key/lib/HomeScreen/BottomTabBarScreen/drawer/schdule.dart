// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/appcolor.dart';

class Schedule extends StatefulWidget {
  const Schedule({super.key});

  @override
  State<Schedule> createState() => _ScheduleState();
}

class _ScheduleState extends State<Schedule> {
bool isSelected=true;
bool isSelected2=false;
 @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
            appBar: AppBar(
              title: Text("Schedules",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 24,color: Colors.black),),
              centerTitle: true,
              bottom: TabBar(
                tabs: const [
                  Tab(child:Text("Online",style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),)),
                    Tab(child:Text("Physical",style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),))
                ]
                
              ),
            ),
          resizeToAvoidBottomInset: false,
          // endDrawer: Drawers(context),
          body: TabBarView(children: [
            OnlineSchedule(),
           PhysicalSchedule()
          ])
      )
    );

  }
}



class OnlineSchedule extends StatefulWidget {
  const OnlineSchedule({super.key});

  @override
  State<OnlineSchedule> createState() => _OnlineScheduleState();
}

class _OnlineScheduleState extends State<OnlineSchedule> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SingleChildScrollView(
        child: Column(
        //  mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
         
            Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Completed",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.green),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
            SizedBox(height: 15,),
             Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Cancelled",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
            SizedBox(height: 15,),
             Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Pending",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
            SizedBox(height: 15,),
             Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Completed",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.green),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
         
          
          ],
        ),
      ),
    );
  }
}




class PhysicalSchedule extends StatefulWidget {
  const PhysicalSchedule({super.key});

  @override
  State<PhysicalSchedule> createState() => _PhysicalScheduleState();
}

class _PhysicalScheduleState extends State<PhysicalSchedule> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SingleChildScrollView(
        child: Column(
        //  mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
         
            Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Cancelled",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
            SizedBox(height: 15,),
             Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Cancelled",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
            SizedBox(height: 15,),
             Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Pending",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
            SizedBox(height: 15,),
             Container(
              color: Colors.grey.shade300,
              child: Column(
                children: [
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text("21-02-2000",style: TextStyle(fontWeight: FontWeight.bold),),
                 TextButton(onPressed: (){}, child:Text("View Details")),
                  ],
                 ),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                       Row(
                      children: [
                        Text("Status: ",style: TextStyle(fontWeight: FontWeight.bold),),
                         Text("Completed",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.green),),
                      ],
                    ),
                    Row(
                      children: [
                          Text("ID: ",style:TextStyle(fontWeight: FontWeight.bold)),
                        
                      Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("AB12R ",style:TextStyle(color: Colors.red,fontWeight: FontWeight.bold)),
                        ),
        
        
                      ],
                    )
                  ],
                 ),
                 SizedBox(
                  height: 10,
                 ),
                ],
              ),
            ),
         
          
          ],
        ),
      ),
    );
  }
}
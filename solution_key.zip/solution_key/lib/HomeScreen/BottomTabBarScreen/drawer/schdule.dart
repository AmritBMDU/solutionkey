import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/appcolor.dart';

class Schedule extends StatefulWidget {
  const Schedule({super.key});

  @override
  State<Schedule> createState() => _ScheduleState();
}

class _ScheduleState extends State<Schedule> {
 @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(automaticallyImplyLeading: false,
        //   centerTitle: true,
        //   leading: IconButton(onPressed: (){
        //     Navigator.pop(context);
        //   },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
        //   title: Text('Schedules',style: GoogleFonts.poppins(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        // ),
        resizeToAvoidBottomInset: false,
        // endDrawer: Drawers(context),
        body: Center(
          child: Image.asset('assets/NodataFound.png'),
        )
    );

  }
}
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/CatergoryData/SubCategoryData.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/CatergoryData/calling.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/multipleHomeScreen/HomePage.dart';
import 'package:solution_key/seachPage/SeacrhPage.dart';


class Favourite extends StatefulWidget {
  const Favourite({super.key});

  @override
  State<Favourite> createState() => _FavouriteState();
}

class _FavouriteState extends State<Favourite> {
   @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
        title: Text("Favourite",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
        centerTitle: true,
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon:Icon(Icons.navigate_before,size: 30,)),
        automaticallyImplyLeading: false,
        actions: [

                        Container(
               child: Row(
                children: [
                  // Padding(
                  //   padding: const EdgeInsets.only(left: 10,right: 10),
                  //   child: InkWell(
                  //     onTap: () {
                   
                  //     },
                  //     highlightColor: Colors.transparent,
                  //     // child: CircleAvatar(
                  //     //   radius: 30,
                  //     //   child: Text("SB"),
                  //     //   backgroundColor: appcolor.greyColor,
                        
                  //     // ),
                  //   ),
                  // ),
                  // Text("Favourite",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
                  // SizedBox(
                  //   width: 25,
                  // ),
                  // IconButton(onPressed:() {
                    
                  // }, icon: Icon(Icons.notifications_outlined)),
                  IconButton(onPressed:() {
                    showSearch(
                                        context: context,
                                        delegate: Searchpage());
                  }, icon:Icon(Icons.search_outlined)),
       
                  
                  
                 
                ],
               ),
              ),
        ],
        elevation: 5,
        ),
        body: ListView.builder(
          itemCount: FavouriteItmes.favouriteItems.length,
          itemBuilder: (context,int index){
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: CustomCallingWidget(
               // rating: double.parse(FavouriteItmes.favouriteItems[index][2]),isAvailable:bool.parse(FavouriteItmes.favouriteItems[index][4]) ,
                name: FavouriteItmes.favouriteItems[index][0],about:"with 30 years of proffessional lineage as a second-generation laweyer at delhi high court, bombay high court,karnataka high court, Telangana High Court", experience: "10", languages:["Hindi","English"], callCharge:double.parse(FavouriteItmes.favouriteItems[index][3]), onAudioCall: (){}, onVideoCall: (){}, potentialQuestions:[]),
            );
        
        
        
          // return ListTile(
          //   leading: Text(FavouriteItmes.favouriteItems[index][0],style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
          //   trailing: Text(FavouriteItmes.favouriteItems[index][2],style: TextStyle(fontSize: 16),),
          // );
        })
        // body: Center(
        //   child: Image.asset('assets/NodataFound.png'),
        // )
    );
  
  }
}

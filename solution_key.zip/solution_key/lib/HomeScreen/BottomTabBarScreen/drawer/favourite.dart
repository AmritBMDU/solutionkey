import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/appcolor.dart';

class Favourite extends StatefulWidget {
  const Favourite({super.key});

  @override
  State<Favourite> createState() => _FavouriteState();
}

class _FavouriteState extends State<Favourite> {
   @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
        title: Text("Favourite",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
        centerTitle: true,
        actions: [
                        Container(
               child: Row(
                children: [
                  // Padding(
                  //   padding: const EdgeInsets.only(left: 10,right: 10),
                  //   child: InkWell(
                  //     onTap: () {
                   
                  //     },
                  //     highlightColor: Colors.transparent,
                  //     // child: CircleAvatar(
                  //     //   radius: 30,
                  //     //   child: Text("SB"),
                  //     //   backgroundColor: appcolor.greyColor,
                        
                  //     // ),
                  //   ),
                  // ),
                  // Text("Favourite",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
                  // SizedBox(
                  //   width: 25,
                  // ),
                  // IconButton(onPressed:() {
                    
                  // }, icon: Icon(Icons.notifications_outlined)),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.favorite_outline,)),
                 
                ],
               ),
              ),
        ],
        elevation: 5,
        ),
        body: Center(
          child: Image.asset('assets/NodataFound.png'),
        )
    );
  
  }
}

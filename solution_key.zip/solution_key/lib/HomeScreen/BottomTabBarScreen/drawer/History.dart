// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:solution_key/appcolor.dart';


// class History extends StatefulWidget {
//   const History({super.key});

//   @override
//   State<History> createState() => _History();
// }
// class _History extends State<History> {

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(automaticallyImplyLeading: false,
//           centerTitle: true,
//           leading: IconButton(onPressed: (){
//             Navigator.pop(context);
//           },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
//           title: Text('History',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
//           actions: [
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Text('Amount: 0.00',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
//             ),
//           ],
//         ),
//         resizeToAvoidBottomInset: false,
//         // endDrawer: Drawers(context),
//         body: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 Table(
//               border: TableBorder.all(),
//               children: [
//                 TableRow(
//                     decoration: BoxDecoration(
//                         color: Colors.grey[300]
//                     ),
//                     children :[
//                       Text('Date',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('Profession',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('Method',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('Time/Order',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('Amount',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                     ]),
//                 TableRow(
//                     decoration: BoxDecoration(
//                         color: Colors.grey[300]
//                     ),
//                     children :[
//                       Text('05-10-2023',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('Doctor',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('call',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('10',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                       Text('100',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,
//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,
//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,
//                         ),
//                       ),
//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),
//                 TableRow(
//                     children :[
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,

//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,
//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),
//                       SizedBox(
//                         height: 30,
//                         child: TextFormField(
//                           readOnly: true,
//                           cursorColor: Colors.black,
//                           cursorHeight: 25,
//                           decoration: InputDecoration(
//                             filled: false,
//                             border: InputBorder.none,

//                           ),
//                           keyboardType: TextInputType.visiblePassword,

//                         ),
//                       ),

//                     ]),




//               ]
//       ),

//               ],
//             ),
//           ),
//         )
//     );

//   }


// }

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/appcolor.dart';

class History extends StatefulWidget {
  const History({super.key});

  @override
  State<History> createState() => _HistoryState();
}

class _HistoryState extends State<History> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(actions: [
                        Container(
               child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10,right: 10),
                    child: InkWell(
                      onTap: () {
                   
                      },
                      highlightColor: Colors.transparent,
                      child: CircleAvatar(
                        radius: 30,
                        child: Text("SB"),
                        backgroundColor: appcolor.greyColor,
                        
                      ),
                    ),
                  ),
                  Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
                  SizedBox(
                    width: 25,
                  ),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.notifications_outlined)),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.favorite_outline,)),
                 
                ],
               ),
              ),
        ],
        elevation: 5,
        ),
        body: Center(
          child: Image.asset('assets/NodataFound.png'),
        )
    );
  
  }
}



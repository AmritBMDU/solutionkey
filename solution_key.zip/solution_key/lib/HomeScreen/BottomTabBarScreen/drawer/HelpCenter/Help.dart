import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/HelpCenter/About_Us.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/HelpCenter/Privacy_Policy.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/HelpCenter/Terms_Condition.dart';
import 'package:solution_key/appcolor.dart';

import 'Contact_Us.dart';
import 'Feedback_Query.dart';


class Help extends StatefulWidget {
  const Help({super.key});

  @override
  State<Help> createState() => _Help();
}
class _Help extends State<Help> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,

        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Help',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        // endDrawer: Drawers(context),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: appcolor.appcolors,
                    backgroundImage: AssetImage('assets/splashlogo.png', ),
                  ),
                  SizedBox(width: 10,),
                  Text('Solution Key',style: TextStyle(fontWeight:FontWeight.w300,fontSize:18)),
                ],
              ),
            ),
            SizedBox(height: 20,),
            Container(height: 1,color: Colors.grey,),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ButtonList(
                    title: 'Feedback/Query',
                    context: context,
                    callback: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Feedback_Query()));
                    }
                  ),
                  // TextButton(onPressed: (){
                  //   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Feedback_Query()));
                  // }, child:Text('Feedback/Query',style: TextStyle(fontWeight: FontWeight.w400,color: appcolor.black),),
                  // ),

                  // Container(height: 1,color: Colors.grey[300],),
                  // SizedBox(height: 10,),
                  ButtonList(
                      title: 'About',
                      context: context,
                      callback: (){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>About_Us()));
                      }
                  ),
                  ButtonList(
                      title: 'Privacy & Policy',
                      context: context,
                      callback: (){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Privcay_Policy()));
                      }
                  ),

                  ButtonList(
                      title: 'Terms & Condition',
                      context: context,
                      callback: (){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Terms_Condition()));
                      }
                  ),
                  ButtonList(
                      title: 'Contact Us',
                      context: context,
                      callback: (){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Contact_Us()));
                      }
                  ),

                ]
              ),
            ),
          ],
        )
    );
  }
}
Widget ButtonList({
  Function()? callback,
  String? title,
  context
}) {
  return Column(
    children: [
      InkWell(
        onTap: callback,
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: 30,
          child:Text(title.toString(),style: TextStyle(fontWeight:FontWeight.w300,fontSize:18)),
        ),
      ),
      Container(height: 1,color: Colors.grey[300],),
      SizedBox(height: 10,),
    ],
  ) ;
}






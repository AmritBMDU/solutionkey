import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';


class Feedback_Query extends StatefulWidget {
  const Feedback_Query({super.key});

  @override
  State<Feedback_Query> createState() => _Feedback_Query();
}
class _Feedback_Query extends State<Feedback_Query> {

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false,

          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Feedback/Query',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),

        ),
        // endDrawer: Drawers(context),
        resizeToAvoidBottomInset: false,

        body: Padding(
          padding: const EdgeInsets.only(left: 20,right: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Subject',style: TextStyle(fontWeight: FontWeight.w500,color:Colors.grey),),
              SizedBox(height: 10,),
              SizedBox(
                height: size.height * 0.06,
                child: TextFormField(
                  keyboardType: TextInputType.visiblePassword,
                  decoration: InputDecoration(
                   // hintText: 'Conform Password',
                    fillColor: Color(0xfff1f3ff
                    ),
                    contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                    filled: true,
                   // suffixIcon: Icon(Icons.remove_red_eye),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(11),
                        ),
                        borderSide: BorderSide()
                    ),
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Color(0xff1f42ba)
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(11))
                    ),
                  ),


                ),
              ),
              SizedBox(height: 20,),
              Text('Feedback/Query',style: TextStyle(fontWeight: FontWeight.w500,color:Colors.grey),),
            SizedBox(height: 10,),
              SizedBox(
                height: 100, //     <-- TextField expands to this height.
                child: TextField(
                  maxLines: null, // Set this
                  expands: true, // and this
                  keyboardType: TextInputType.multiline,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(),
                   // contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 30)
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Center(child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: appcolor.appcolors
                  ),
                  onPressed: (){}, child: Text('Submit',style: TextStyle(color: Colors.white),)))
            ],
          ),
        )
    );

  }


}





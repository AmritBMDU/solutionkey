import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';


class Contact_Us extends StatefulWidget {
  const Contact_Us({super.key});

  @override
  State<Contact_Us> createState() => _Contact_Us();
}
class _Contact_Us extends State<Contact_Us> {

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        resizeToAvoidBottomInset: false,

        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Contact Us',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        // endDrawer: Drawers(context),
        body: Column(
          children: [
            SizedBox(height: 20,),
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundColor: appcolor.appcolors,
                child: Image.asset('assets/splashlogo.png',fit: BoxFit.contain,),
              ),
            ),
            Text(
              'Click on the below link to reach us:',
              style: TextStyle(
                fontSize: 18,fontWeight: FontWeight.w400
              ),
            ),
            SizedBox(height: 10,),
            Text(
              'support@solutionkey.com',
              style: TextStyle(
                  fontSize: 14,fontWeight: FontWeight.w400, decoration: TextDecoration.underline,color: appcolor.appcolors
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Container(
                    height: 1,
                      width: size.width * 0.4,
                     color: appcolor.appcolors,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Center(
                      child: CircleAvatar(
                        radius: 20,
                        child: Text(
                          'Or',
                          style: TextStyle(
                              fontSize: 16,fontWeight: FontWeight.w400
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 1,
                    width: size.width * 0.4,
                    color: appcolor.appcolors,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Text(
              'Call Us On:',
              style: TextStyle(
                  fontSize: 18,fontWeight: FontWeight.w400
              ),
            ),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: appcolor.appcolors,
                shape: BeveledRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(1))
                )
              ),
              onPressed: (){}, icon: Icon(Icons.call,color: Colors.white,),
              label: Text(
              '+91 9876543453',
              style: TextStyle(
                  fontSize: 14,fontWeight: FontWeight.w400,color: Colors.white
              ),
            ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 1,
                width: size.width ,
                color: appcolor.appcolors,
              ),
            ),
            Text(
              'Company Name:',
              style: TextStyle(
                  fontSize: 18,fontWeight: FontWeight.w500
              ),
            ),
            SizedBox(height: 10,),
            Text(
              'SOLUTION KEY',
              style: TextStyle(
                  fontSize: 16,fontWeight: FontWeight.w400
              ),
            ),
            SizedBox(height: 10,),
            Text(
              'Company Address:',
              style: TextStyle(
                  fontSize: 18,fontWeight: FontWeight.w500
              ),
            ),
            SizedBox(height: 10,),
            Text(
              '631,Mota singh nagar, greater Noida,',
              style: TextStyle(
                  fontSize: 16,fontWeight: FontWeight.w400
              ),
            ),
            Text(
              'Uttar Pardesh,144011',
              style: TextStyle(
                  fontSize: 16,fontWeight: FontWeight.w400
              ),
            ),
          ],
        )
    );

  }


}





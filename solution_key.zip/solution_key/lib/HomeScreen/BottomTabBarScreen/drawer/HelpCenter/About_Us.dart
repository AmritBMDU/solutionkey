import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';


class About_Us extends StatefulWidget {
  const About_Us({super.key});

  @override
  State<About_Us> createState() => _About_Us();
}
class _About_Us extends State<About_Us> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,

        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('About Us',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        // endDrawer: Drawers(context),
        body: Padding(
          padding: const EdgeInsets.only(left: 20,right: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'About SolutionKey',
                style: TextStyle(
                  color: appcolor.appcolors,
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10,),
              Text(
                'Please note as, per CBDTwhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries\nPlease note as, per CBDTwhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,  ',
                style: TextStyle(
                  fontSize: 14,
                  height: 1,
                ),
              ),
              SizedBox(height: 50,),
              Center(
                child: Text(
                  'End User Liscence Agreement',
                  style: TextStyle(
                    color: appcolor.appcolors,
                    fontSize: 18,
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Text(
                'To View the update terms & conditions please click on the link',
                style: TextStyle(
                  fontSize: 14,
                  height: 1,
                ),
              ),
              TextButton(
                onPressed: () {
                //  Get.to(termsandCondition());
                },
                child: Text(
                  'Click Here',
                  style: TextStyle(
                    fontSize: 14,
                    height: 1,
                  ),
                ),
              )
            ],
          ),
        )
    );

  }


}





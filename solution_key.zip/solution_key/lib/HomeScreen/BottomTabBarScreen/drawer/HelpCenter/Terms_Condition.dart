import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';


class Terms_Condition extends StatefulWidget {
  const Terms_Condition({super.key});

  @override
  State<Terms_Condition> createState() => _Terms_Condition();
}
class _Terms_Condition extends State<Terms_Condition> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Terms & Conditon',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        // endDrawer: Drawers(context),
        resizeToAvoidBottomInset: false,

        body:Padding(
          padding: const EdgeInsets.only(left: 20, right: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                '1. PayTm : Any Amount equal or above Rs. 1',
                style: TextStyle(fontSize: 14),
              ),
              Text(
                '2. Bank Transfer : Any Amount equal or above\n   Rs.300 ',
                style: TextStyle(fontSize: 14),
              ),
              Text(
                'Disclaimer',
                style: TextStyle(
                  color: appcolor.appcolors,
                  fontSize: 18,
                ),
              ),
              Text(
                '1. Please note as, per CBDTwhen an unknown\n   printer took a galley of type and scrambled \n   it to make a type specimen book. It has \n   survived not only five centuries, ',
                style: TextStyle(fontSize: 14),
              ),
              Text(
                '2. Please note as, per CBDTwhen an unknown\n   printer took a galley of type and scrambled \n   it to make a type specimen book. It has \n   survived not only five centuries, ',
                style: TextStyle(fontSize: 14),
              ),
              Text(
                'End User Liscence Agreement',
                style: TextStyle(
                    color: appcolor.appcolors,
                    fontSize: 18
                ),
              ),
              Text(
                'To View the update terms & conditions please click on the link',
                style: TextStyle(
                  fontSize: 14,
                  height: 1,
                ),
              ),
              TextButton(
                onPressed: () {

                },
                child: Text(
                  'Click Here',
                  style: TextStyle(
                    fontSize: 16,
                    height: 1,
                  ),
                ),
              )
            ],
          ),
        )
    );

  }


}












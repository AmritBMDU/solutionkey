import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';


class Privcay_Policy extends StatefulWidget {
  const Privcay_Policy({super.key});

  @override
  State<Privcay_Policy> createState() => _Privcay_Policy();
}
class _Privcay_Policy extends State<Privcay_Policy> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Privacy & Policy',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        // endDrawer: Drawers(context),
        resizeToAvoidBottomInset: false,

        body: Padding(
          padding: const EdgeInsets.only(left: 20,right: 20),
          child: Column(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('1. Payment : Any amount equal to above Rs. 1',style: TextStyle(fontSize: 14),),

                  Text('2. Bank Transfer : Any Amount equal or above \n    Rs.300',style: TextStyle(fontSize: 14),)
                ],
              ),
              SizedBox(height: 20,),
              Center(child: Text('Disclaimer', style: TextStyle(fontSize: 16,color: appcolor.appcolors),)),
              SizedBox(height: 10,),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(' 1. Please note as, per CBDTwhen an unknown \n       printer took a galley of type and scrambled \n       it to make a type specimen book. It has \n       survived not only five centuries,',style: TextStyle(fontSize: 14),),

                  Text(' 2. Please note as, per CBDTwhen an unknown \n       printer took a galley of type and scrambled \n       it to make a type specimen book. It has \n       survived not only five centuries,',style: TextStyle(fontSize: 14),),
                ],
              ),
              SizedBox(height: 20,),
              Center(child: Text('End User License Agreement', style: TextStyle(fontSize: 16,color: appcolor.appcolors),)),
              SizedBox(height: 10,),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('  To View the update terms & conditions please \n   clieck on the link',style: TextStyle(fontSize: 14),),

                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(width: 25,),
                  TextButton(onPressed: (){}, child: Text('Click Here')),
                ],
              )
            ],
          ),
        )
    );

  }


}





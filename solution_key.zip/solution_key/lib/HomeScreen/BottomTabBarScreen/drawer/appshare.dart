

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:share_plus/share_plus.dart';
import 'package:solution_key/Widget/blockbutton.dart';
import 'package:solution_key/Widget/gradient_text.dart';
import 'package:solution_key/appcolor.dart';
import 'package:url_launcher/url_launcher.dart';

class referandearn extends StatefulWidget {
  const referandearn({super.key});

  @override
  State<referandearn> createState() => _referandearnState();
}

class _referandearnState extends State<referandearn> {
  String copy= 'NEWSOLUTIONKEY12';
  
  @override
  Widget build(BuildContext context) {
     var Get= MediaQuery.of(context).size;
    return SafeArea(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            color: Colors.white

          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'),
          //   fit: BoxFit.fill,
          // ),
        ),
        child: Scaffold(
        //  backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: Text("Share & Earn"),
          elevation: 5,
        ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
               //   customAppBar('Refer & Earn'),
               
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          height: MediaQuery.of(context).size.height*0.2,
                          child: Image.asset("assets/share_earn.jpg")),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text("This is your code. Share it!"),
              
                      ),
                      SizedBox(height: 10,),
                       DottedBorder(
                        borderType: BorderType.RRect,
                        color: appcolor.newRedColor,
                        radius: Radius.circular(10),
                        child: Container(
                          decoration: BoxDecoration(
                            color: appcolor.greyColor,
                            borderRadius: BorderRadius.circular(
                              10,
                            ),
                          ),
                          padding: EdgeInsets.only(
                            top: 10,
                            left: 10,
                            right: 10,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                copy,
                                style: TextStyle(
                                  fontSize: 14,
                                  height: 1,
                                ),
                              ),
                              Spacer(),
                              Container(
                                margin: EdgeInsets.only(
                                  right: 5,
                                ),
                                width: 1,
                                color: Colors.black,
                                height: Get.height * 0.025,
                              ),
                              InkWell(
                                  onTap: (){
              
                                    },
                                child: Container(
                                  height: Get.height * 0.022,
                                  child: Image.asset('assets/Vector (1).png',color: appcolor.newRedColor,)
              
                                ),
                              ),
                              InkWell(
                                onTap: ()async {
                                  await Clipboard.setData(ClipboardData(text: copy));
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              
                                      content: Text(copy)));
                                },
                                child: Text(
                                  ' Copy',
                                  style: TextStyle(
                                    fontSize: 16,
                                    height: 1,
                                    color: Colors.blue[300],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 140,
                        width: MediaQuery.of(context).size.width*0.95,
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 20),
                            child: Column(
                              
                              children: [
                                Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 25,
                                      child: Image.asset("assets/rs_symbol.png"),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left:10),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("Total Reward"),
                                          Text("₹0")
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                                Divider(),
                                Text("0/10 people have joined with your refferal code")
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("How it works?",style: TextStyle(fontSize: 17,fontWeight: FontWeight.bold),),
                          Text("T&Cs",style: TextStyle(fontSize: 17,fontWeight: FontWeight.bold,color: Colors.redAccent),)
                        ],
                      ),
                      SizedBox(height: 10,),
                      Container(

                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    CircleAvatar(
                                      child: Image.asset("assets/chain.png"),
                                    ),
                                    Text("Invite Your friends to install the app")
                                  ],
                                ),
                                SizedBox(height: 10,),
                                 Row(
                                  children: [
                                    CircleAvatar(
                                      child: Image.asset("assets/chain.png"),
                                    ),
                                    Text("Invite Your friends to install the app")
                                  ],
                                ),
                                  SizedBox(height: 10,),
                                 Row(
                                  children: [
                                    CircleAvatar(
                                      child: Image.asset("assets/chain.png"),
                                    ),
                                    Text("Invite Your friends to install the app")
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Center(
                        child: ElevatedButton(onPressed: (){ 
                                  Share.share('$copy',subject: 'Solution Key');
                                
                        }, 
                        style: ElevatedButton.styleFrom(
                          backgroundColor: appcolor.newRedColor,
                        ),
                        child: Text("Refer your Friend",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),)),
                      ),
                     
                    ],
                  )
                ],
              ),
            ),
          ),
         // floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }

}

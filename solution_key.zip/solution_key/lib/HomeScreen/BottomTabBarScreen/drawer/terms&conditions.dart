import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';




class termsandCondition extends StatefulWidget {
  const termsandCondition({super.key});

  @override
  State<termsandCondition> createState() => _termsandConditionState();
}

class _termsandConditionState extends State<termsandCondition> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
    
        child: Scaffold(
          appBar: AppBar(
            title: Text("Terms & Conditions",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            automaticallyImplyLeading: false,
            centerTitle: true,
            leading: IconButton(onPressed: (){
              Navigator.pop(context);
            }, icon: Icon(Icons.navigate_before,color: appcolor.appcolors,size: 30,)),
            elevation: 0,
          ),
         // backgroundColor: Colors.transparent,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              
              Container(
                height: 1,
                width: MediaQuery.of(context).size.width,
                color: appcolor.appcolors,
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '1. PayTm : Any Amount equal or above Rs. 1',
                      style: TextStyle(fontSize: 14),
                    ),
                    Text(
                      '2. Bank Transfer : Any Amount equal or above\n   Rs.300 ',
                      style: TextStyle(fontSize: 14),
                    ),
                    Text(
                      'Disclaimer',
                      style: TextStyle(
                        color: appcolor.newRedColor,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      '1. Please note as, per CBDTwhen an unknown\n   printer took a galley of type and scrambled \n   it to make a type specimen book. It has \n   survived not only five centuries, ',
                      style: TextStyle(fontSize: 14),
                    ),
                    Text(
                      '2. Please note as, per CBDTwhen an unknown\n   printer took a galley of type and scrambled \n   it to make a type specimen book. It has \n   survived not only five centuries, ',
                      style: TextStyle(fontSize: 14),
                    ),
                    Text(
                      'End User Liscence Agreement',
                      style: TextStyle(
                        color: appcolor.newRedColor,
                        fontSize: 18
                      ),
                    ),
                    Text(
                      'To Know more About us please click on the button',
                      style: TextStyle(
                        fontSize: 14,
                        height: 1,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                       // Get.to(aboutUs());
                       Navigator.pop(context);
                      },
                      child: Text(
                        'Click Here',
                        style: TextStyle(
                          fontSize: 16,
                          height: 1,
                        ),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
       //   floatingActionButton:floatingActionButon(),
        ),
      
    );
  }
}

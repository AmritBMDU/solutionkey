import 'package:flutter/material.dart';


class BlogScreen extends StatelessWidget {
  final List<Blog> blogs = [
    Blog(
      title: 'Introduction to Flutter',
      content: 'Flutter is a UI toolkit that enables you to create natively compiled applications for mobile, web, and desktop from a single codebase.',
      date: 'December 1, 2023',
    ),
    Blog(
      title: 'Getting Started with Dart',
      content: 'Dart is a programming language optimized for building mobile, desktop, server, and web applications.',
      date: 'December 5, 2023',
    ),
    Blog(
      title: 'State Management in Flutter',
      content: 'State management is a crucial aspect of building scalable and maintainable Flutter applications. There are various state management solutions available, including Provider, Bloc, and Riverpod.',
      date: 'December 10, 2023',
    ),
    Blog(
      title: 'Responsive Design in Flutter',
      content: 'Creating responsive UIs is essential for ensuring that your Flutter applications look good on a variety of devices. Flutter provides widgets and techniques to achieve responsive design.',
      date: 'December 15, 2023',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Blogs'),
      ),
      body: ListView.builder(
        itemCount: blogs.length,
        itemBuilder: (context, index) {
          return BlogCard(blog: blogs[index]);
        },
      ),
    );
  }
}

class Blog {
  final String title;
  final String content;
  final String date;

  Blog({required this.title, required this.content, required this.date});
}

class BlogCard extends StatelessWidget {
  final Blog blog;

  BlogCard({required this.blog});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(16.0),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              blog.title,
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text(
              blog.content,
              style: TextStyle(fontSize: 16.0),
            ),
            SizedBox(height: 8.0),
            Text(
              'Date: ${blog.date}',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:solution_key/appcolor.dart';


class User_Profile extends StatefulWidget {
  const User_Profile({super.key});

  @override
  State<User_Profile> createState() => _User_Profile();
}
class _User_Profile extends State<User_Profile> {
  File? SelectedImage;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size; 
    return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Profile ',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        resizeToAvoidBottomInset: false,
        // endDrawer: Drawers(context),
        body:SingleChildScrollView(
          child: Column(
            children: [
             // SizedBox(height: 30,),
              Center(
                child: Stack(
                    children:[
                      CircleAvatar(
                        radius: 50,
                         backgroundImage:  AssetImage('assets/img_3.png'),
                        child: SelectedImage != null ? Image.file(SelectedImage!):Icon(Icons.person),
                        // backgroundImage: SelectedImage ==null ? Image(image: Image.file(SelectedImage!),): NetworkImage(),
                      ),
                      Positioned(
                          top: 60,
                          left: 60,
                          child: CircleAvatar(
                            radius: 20,
                            backgroundColor: appcolor.appcolors,
                            child: Center(
                              child: IconButton(
                                onPressed: (){
                                    showModalBottomSheet<void>(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return Container(
                                        height: 80,
                                        color:appcolor.appcolors,
                                        child: Center(
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            children: <Widget>[
                                              Column(
                                                children: [
                                                  IconButton(onPressed: (){
                                                    imagePickerCamera();
                                                  }, icon: Icon(Icons.camera,color: Colors.white,),
                                                  ),
                                                  Text('Camera',style: TextStyle(color: Colors.white),),
          
                                                ],
                                              ),
                                              SizedBox(width: 40,),
                                              Column(
                                                children: [
                                                  IconButton(onPressed: (){
                                                    imagePicker();
                                                  }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                                  ),
                                                  Text('File',style: TextStyle(color: Colors.white),),
                                                ],
                                              ),
          
                                              // ElevatedButton(
                                              //   child: const Text('Close BottomSheet'),
                                              //   onPressed: () => Navigator.pop(context),
                                              // ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                },icon: Icon(Icons.camera_alt,color: Colors.white,),
                              ),
                            ),
                          ))
                    ]
                ),
          
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left: 20,right: 20),
                child: Container(
                  height: size.height * 0.06,
                  child: ProfileTextFields(hinttext: "Saurabh", icon:Icons.person,isTrue: true,)
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left: 20,right: 20),
                child: Container(
                  height: size.height * 0.06,
                  child:ProfileTextFields(hinttext: "Baghel", icon: Icons.person,isTrue: true,)
                ),
              ),
              SizedBox(height: 10,),
              GenderSelction(gender: ["Select Gender","Male","Female","Other"], dropdownvalue: 'Select Gender',),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left: 20,right: 20),
                child: Container(
                  height: size.height * 0.06,
                  child: ProfileTextFields(hinttext: "+91 8979034037", icon: Icons.phone,isTrue: true,)
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left: 20,right: 20),
                child: Container(
                  height: size.height * 0.06,
                  child:ProfileTextFields(hinttext: "Email", icon: Icons.email)
                ),
              ),
              SizedBox(height: 10,),
              GenderSelction(gender: ["Select Martial Status","Married","Unmmaried"], dropdownvalue:"Select Martial Status"),
              SizedBox(height: 10,),
            DateTimer(),
            SizedBox(height: 10,),
          
              Padding(
                padding: const EdgeInsets.only(left: 20,right: 20),
                child: Container(
                  height: size.height * 0.06,
                  child: ProfileTextFields(hinttext: "City", icon: Icons.home)
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left: 20,right: 20),
                child: Container(
                  height: size.height * 0.06,
                  child: ProfileTextFields(hinttext: 'State', icon: Icons.location_pin,),
                ),
              ),
              SizedBox(height: 10,),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.89,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(3))
                        ),
                        backgroundColor: Color(0xff1f42ba
          
                        )
                    ),
                    onPressed: (){
                     // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> MainPage()));
                    }, child: Text('Update',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w300,color: Colors.white),)),
              ),
            ],
          ),
        )
    );

  }
  Future imagePicker()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    // Cropped Image
    CroppedFile? croppedFile = await ImageCropper().cropImage(sourcePath: returnedImage!.path

    );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(croppedFile!.path);
      Navigator.of(context).pop();
    });
  }
  Future imagePickerCamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);
    CroppedFile? croppedFile = await ImageCropper().cropImage(
        aspectRatioPresets: [
          CropAspectRatioPreset.square,
          CropAspectRatioPreset.ratio3x2,
          CropAspectRatioPreset.original,
          CropAspectRatioPreset.ratio4x3,
          CropAspectRatioPreset.ratio16x9,
        ],
        sourcePath: returnedImage!.path
    );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(croppedFile!.path);
      Navigator.of(context).pop();

    });
  }

}

class ProfileTextFields extends StatelessWidget {
   ProfileTextFields({

    super.key,required this.hinttext,required this.icon,this.isTrue=false
  });
  String hinttext;
  IconData icon;
  bool isTrue;


  @override
  Widget build(BuildContext context) {
    return TextField(
        keyboardType: TextInputType.visiblePassword,
        readOnly: isTrue,
        decoration: InputDecoration(
          hintText: hinttext,
          
          fillColor: Color(0xfff1f3ff
          ),
          suffixIcon: Icon(icon),
          contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(11),
              ),
              borderSide: BorderSide(color: Colors.grey)
          ),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xff1f42ba),
              ),
              borderRadius: BorderRadius.all(Radius.circular(11))
          ),
        )
    );
  }
}

class GenderSelction extends StatefulWidget {
   GenderSelction({super.key,required this.gender,required this.dropdownvalue});
  List<String> gender=[];
   String dropdownvalue;
  @override
  State<GenderSelction> createState() => _GenderSelctionState();
}

class _GenderSelctionState extends State<GenderSelction> {

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: Colors.grey)
      ),
      height: MediaQuery.of(context).size.height*0.06,
      width: MediaQuery.of(context).size.width*0.89,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: DropdownButtonHideUnderline(
          child: DropdownButton(
            value: widget.dropdownvalue,
            style: TextStyle(color: Colors.grey.shade700,fontSize: 17),
            //dropdownColor:  Color(0xfff1f3ff),
            //elevation: 0,
            
            items:widget.gender.map((String items) { 
                  return DropdownMenuItem( 
                    value: items, 
                    child: Text(items), 
                  ); 
                }).toList(), 
           onChanged:(value){
            setState(() {
              widget.dropdownvalue=value!;
            });
           }),
        ),
      ),
    );
  }
}





class DateTimer extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _DateTimer();
  }
}
 
class _DateTimer extends State<DateTimer> {
  TextEditingController dateInput = TextEditingController();
 
  @override
  void initState() {
    dateInput.text = ""; //set the initial value of text field
    super.initState();
  }
 
  @override
  Widget build(BuildContext context) {
    return  Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: Colors.grey)
      ),
      height: MediaQuery.of(context).size.height*0.06,
      width: MediaQuery.of(context).size.width*0.89,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width*0.77,
                  child: TextField(
                        controller: dateInput,
                        //editing controller of this TextField
                        decoration: InputDecoration(
                   //icon of text field
                   border:InputBorder.none,
                    hintText: "Select date Of birth", //label text of field
                     hintStyle: TextStyle(color: Colors.grey.shade600,fontSize: 17),
                    ),
                        readOnly: true,
                        //set it true, so that user will not able to edit text
                        onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1950),
                      //DateTime.now() - not to allow to choose before today.
                      lastDate: DateTime.now());
                       
                  if (pickedDate != null) {
                    print(
                        pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                    String formattedDate =
                        DateFormat('yyyy-MM-dd').format(pickedDate);
                    print(
                        formattedDate); //formatted date output using intl package =>  2021-03-16
                    setState(() {
                      dateInput.text =
                          formattedDate; //set output date to TextField value.
                    });
                  } else {}
                        },
                      ),
                ),
                    Icon(Icons.calendar_month)
              ],
            ),
          ),
        ));
  }
}

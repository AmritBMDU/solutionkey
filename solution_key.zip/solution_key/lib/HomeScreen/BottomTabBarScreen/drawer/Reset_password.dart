import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/LoginPage.dart';
import 'package:solution_key/Widget/elevatedButtn.dart';
import 'package:solution_key/appcolor.dart';


class Reset_password extends StatefulWidget {
  const Reset_password({super.key});

  @override
  State<Reset_password> createState() => _Report_block();
}
class _Report_block extends State<Reset_password> {
  bool passwordVisible=false;
  bool passwordVisible1=false;
  bool passwordVisible2=false;
  TextEditingController email = TextEditingController();
  TextEditingController pasword = TextEditingController();
  TextEditingController cpasswod= TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    passwordVisible=true;
    bool passwordVisible1=true;
    bool passwordVisible2=true;
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Reset Password',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        resizeToAvoidBottomInset: false,
        // endDrawer: Drawers(context),
      body: Column(
        children: [
          SizedBox(height: 90,),
          // Center(child: Text('Change password', style: TextStyle(fontWeight: FontWeight.w600,fontSize: 25,color: Color(0xff1f42ba)),)),
          // SizedBox(height: 50,),
        // Text("Current Password"),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            
            child: Container(
              height: size.height * 0.08,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.only(left:10),
                  child: TextFormField(
                    controller: pasword,
                    keyboardType: TextInputType.visiblePassword,
                    obscureText: passwordVisible2,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Old Password',
                    
                      // contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      // filled: true,
                      suffixIcon: IconButton(
                        icon: Icon(passwordVisible2
                            ? Icons.visibility
                            : Icons.visibility_off),
                        onPressed: () {
                          setState(
                                () {
                              passwordVisible2 = !passwordVisible2;
                            },
                          );
                        },
                      ),
                      // border: OutlineInputBorder(
                      //     borderRadius: BorderRadius.all(Radius.circular(11),
                      //     ),
                      //     borderSide: BorderSide()
                      // ),
                      // focusedBorder: OutlineInputBorder(
                      //     borderSide: BorderSide(color: Color(0xff1f42ba)
                      //     ),
                      //     borderRadius: BorderRadius.all(Radius.circular(11))
                      // ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Username cannot be empty";
                      }else if(value.length < 6){
                        return "Password length should be atleast 6";
                      }
                      return null;
                    },
                    onChanged: (value) {
                      //  name = value;
                      setState(() {});
                    },
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: SizedBox(
              height: size.height * 0.08,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: TextFormField(
                    controller: pasword,
                    keyboardType: TextInputType.visiblePassword,
                    obscureText: passwordVisible,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'New Password',
                     
                      suffixIcon: IconButton(
                        icon: Icon(passwordVisible
                            ? Icons.visibility
                            : Icons.visibility_off),
                        onPressed: () {
                          setState(
                                () {
                              passwordVisible = !passwordVisible;
                            },
                          );
                        },
                      ),
                      // border: OutlineInputBorder(
                      //     borderRadius: BorderRadius.all(Radius.circular(11),
                      //     ),
                      //     borderSide: BorderSide()
                      // ),
                      // focusedBorder: OutlineInputBorder(
                      //     borderSide: BorderSide(color: Color(0xff1f42ba)
                      //     ),
                      //     borderRadius: BorderRadius.all(Radius.circular(11))
                      // ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Username cannot be empty";
                      }else if(value.length < 6){
                        return "Password length should be atleast 6";
                      }
                      return null;
                    },
                    onChanged: (value) {
                      //  name = value;
                      setState(() {});
                    },
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: SizedBox(
              height: size.height * 0.08,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: TextFormField(
                    controller: cpasswod,
                    keyboardType: TextInputType.visiblePassword,
                    obscureText: passwordVisible1,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Confirm Password',
                      
                      suffixIcon: IconButton(
                        icon: Icon(passwordVisible1
                            ? Icons.visibility
                            : Icons.visibility_off),
                        onPressed: () {
                          setState(
                                () {
                              passwordVisible1 = !passwordVisible1;
                            },
                          );
                        },
                      ),
                     
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Username cannot be empty";
                      }else if(value.length < 6){
                        return "Password length should be atleast 6";
                      }
                      return null;
                    },
                    onChanged: (value) {
                      //  name = value;
                      setState(() {});
                    },
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: MediaQuery.of(context).size.height*0.3,),
          //elevated(context: context,name: 'Reset Password',navigative: ),
          SizedBox(
            height: 50,
            width: MediaQuery.of(context).size.width * 0.89,
            child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    shape: BeveledRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(3))
                    ),
                    backgroundColor: Color(0xff1f42ba)
                ),
                onPressed: (){
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage()));
                }, child: Text('Reset Password',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w700,color: Colors.white,),)),
          ),
          // TextButton(onPressed: (){
          //   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage()));
          // }, child: Text('Back to Login ',style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400,color: Colors.black),)),
          // SizedBox(height: 60,),
          // Text('Or Continue with',style: TextStyle(color: Color(0xff1f42ba)),),
          // SizedBox(height: 10,),
          // Row(
          //   mainAxisAlignment: MainAxisAlignment.center,
          //   children: [
          //     Container(
          //       decoration: BoxDecoration(
          //           color: Color(0xffececec),
          //           borderRadius: BorderRadius.all(Radius.circular(11))                ),
          //       height: 50,
          //       width: 50,
          //       child: Center(child: FaIcon(FontAwesomeIcons.google,color: Colors.black,)),
          //
          //     ),
          //     SizedBox(width: 10,),
          //     Container(
          //       decoration: BoxDecoration(
          //           color: Color(0xffececec),
          //           borderRadius: BorderRadius.all(Radius.circular(11))                ),
          //       height: 50,
          //       width: 50,
          //       child: Center(child: FaIcon(FontAwesomeIcons.facebook,color: Colors.black,)),
          //
          //     ),
          //     SizedBox(width: 10,),
          //     Container(
          //       decoration: BoxDecoration(
          //           color: Color(0xffececec),
          //           borderRadius: BorderRadius.all(Radius.circular(11))                ),
          //       height: 50,
          //       width: 50,
          //       child: Center(child: FaIcon(FontAwesomeIcons.apple,color: Colors.black,)),
          //
          //     ),
          //   ],
          // )

        ],
      ),
    );

  }


}





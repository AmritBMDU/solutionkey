import 'dart:convert';
import 'package:fast_contacts/fast_contacts.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:solution_key/appcolor.dart';


class YourContact extends StatefulWidget {
  const YourContact({super.key});

  @override
  State<YourContact> createState() => _YourContact();
}
class _YourContact extends State<YourContact> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,

        appBar: AppBar(automaticallyImplyLeading: false,
          centerTitle: true,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
          title: Text('Select Contact',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
        ),
        // endDrawer: Drawers(context),
        body:FutureBuilder(
          future: getContact(),
          builder: (context, snapshot){
            if(snapshot.data ==  null){
              return Center(child: CircularProgressIndicator());
            }else if(snapshot.data!= null){
              return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index){
                    Contact contact = snapshot.data![index];
                return ListTile(
                  title: Text(contact.displayName,style: TextStyle(fontWeight: FontWeight.w400,color: appcolor.black),),
                  leading: CircleAvatar(
                    radius: 20,
                    child: Icon(Icons.person),
                  ),
                //  subtitle: Text('${contact.phones}',style: TextStyle(fontWeight: FontWeight.w400,color: appcolor.black),),
                );
              });
            }
            return Center(child: CircularProgressIndicator());
          },
        )
    );

  }
  Future<List<Contact>> getContact()async {
    bool isGranted = await Permission.contacts.status.isGranted;
    if(!isGranted){
      isGranted = await Permission.contacts.request().isGranted;
    }
    if(isGranted){
      return await FastContacts.getAllContacts();
    }
    return[];
  }


}





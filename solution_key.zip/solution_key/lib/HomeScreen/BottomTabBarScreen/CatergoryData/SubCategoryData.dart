import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';

import '../../../DetailPage/detail_Screen.dart';
import '../../../Widget/gradient_text.dart';

class SubCategoryData extends StatefulWidget {

  const SubCategoryData({super.key});

  @override
  State<SubCategoryData> createState() => _SubCategoryDataState();
}
class _SubCategoryDataState extends State<SubCategoryData> {
  var selectedIndex= '';
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      // appBar: AppBar(automaticallyImplyLeading: false,
      //   centerTitle: true,
      //   leading: IconButton(onPressed: (){
      //     Navigator.pop(context);
      //   },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
      //   title: Text('SubCategory',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
      // ),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: size.width * 0.19,
            child:   SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Container(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      SizedBox(height: 40,),
                      Wrap(
                        spacing: 8,
                        runSpacing: 10,
                        children: <Widget>[
                          categorywidget(
                            assetimagepath: 'assets/img_6.png',
                            callback: () {
                              setState(() {
                                selectedIndex = '1';
                              });                          },
                            title: 'All Doctor',
                          ),
                          categorywidget(
                            assetimagepath: 'assets/img_7.png',
                            callback: () {
                              setState(() {
                                selectedIndex = '2';
                              });
                            },
                            title: 'Psychologist',
                          ),
                          categorywidget(
                            assetimagepath: 'assets/img_9.png',
                            callback: () {
                              setState(() {
                                selectedIndex = '3';
                              });
                            },
                            title: 'Neurology',
                          ),
                          categorywidget(
                            assetimagepath: 'assets/img_10.png',
                            callback: () {
                              setState(() {
                                selectedIndex = '4';
                              }); },
                            title: 'Ophthalmology',
                          ),
                          categorywidget(
                            assetimagepath: 'assets/img_3.png',
                            callback: () {
                              setState(() {
                                selectedIndex = '5';
                              });                          },
                            title: 'Psychologsit',
                          ),

                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),

          selectedIndex =='1'?
          Container(
            width: size.width * 0.7,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: 50,),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Rahul',
                    assetimagepath: 'assets/img_2.png',
                    context: context,

                    Profession: 'Doctor',
                    rating: '3.0',
                  ),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Nisha',
                    assetimagepath: 'assets/img_9.png',
                    context: context,
                    Profession: 'Neurology',
                    rating: '3.0',
                  ),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Mohit',
                    assetimagepath: 'assets/img_10.png',
                    context: context,
                    Profession: 'Ophthalmology',
                    rating: '5.0',
                  ),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Rajesh',
                    assetimagepath: 'assets/img_3.png',
                    context: context,
                    Profession: 'Psychologist',
                    rating: '3.0',
                  ),



                ],
              ),
            ),
          ) :
              selectedIndex == '2'? Container(
                width: size.width * 0.7,
                child: Column(
                  children: [
                    SizedBox(height: 60,),
                    productlist(
                      callback:   (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                      },
                      title: 'Rajesh',
                      assetimagepath: 'assets/img_7.png',
                      context: context,
                      Profession: 'Psychologist',
                      rating: '3.0',
                    ),
                  ],
                ),
              ):selectedIndex == '3'? Container(
                width: size.width * 0.7,
                child: Column(
                  children: [
                    SizedBox(height: 60,),
                    productlist(
                      callback:   (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                      },
                      title: 'Deepak',
                      assetimagepath: 'assets/img_9.png',
                      context: context,
                      Profession: 'Neurologist',
                      rating: '3.0',
                    ),
                  ],
                ),
              ):selectedIndex == '4'? Container(
                width: size.width * 0.7,
                child: Column(
                  children: [
                    SizedBox(height: 60,),
                    productlist(
                      callback:   (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                      },
                      title: 'Ankit',
                      assetimagepath: 'assets/img_10.png',
                      context: context,
                      Profession: 'Ophthalmologist',
                      rating: '3.0',
                    ),
                  ],
                ),
              ):
          Container(
            width: size.width * 0.7,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: 50,),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Rahul',
                    assetimagepath: 'assets/img_2.png',
                    context: context,

                    Profession: 'Doctor',
                    rating: '3.0',
                  ),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Nisha',
                    assetimagepath: 'assets/img_9.png',
                    context: context,
                    Profession: 'Neurology',
                    rating: '3.0',
                  ),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Mohit',
                    assetimagepath: 'assets/img_10.png',
                    context: context,
                    Profession: 'Ophthalmology',
                    rating: '5.0',
                  ),
                  productlist(
                    callback:   (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>MyScreen(profession: '', name: '', imgurl: '',)));
                    },
                    title: 'Rajesh',
                    assetimagepath: 'assets/img_3.png',
                    context: context,
                    Profession: 'Psychologist',
                    rating: '3.0',
                  ),



                ],
              ),
            ),
          ) ,


        ],
      ),

    );
  }
}
Widget categorywidget({
  Function()? callback,
  String? assetimagepath,
  String? title,
}) {
  return InkWell(
    onTap: callback,
    child: Column(
      children: [

        CircleAvatar(
          radius: 30,
          backgroundColor: appcolor.greyColor,
          backgroundImage: AssetImage(assetimagepath.toString()),
          // child:Image.asset(assetimagepath.toString(),fit: BoxFit.cover,)
        ),

        GradientText(
          widget: Text(
            '$title',
            style: TextStyle(
              fontSize: 8,color: appcolor.appcolors,
            ),
          ),
          gradient: appcolor.gradient,
        ),
      ],
    ),
  );
}
Widget productlist({
  context,
  Function()? callback,
  String? assetimagepath,
  String? title,
  String? email,
  String? rating,
  String? Profession,

}) {
  var size = MediaQuery.of(context).size;
  return  Column(
    children: [
      InkWell(
        onTap: callback,
        child: Container(
          height: size.height * 0.18,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.grey,
                          image: DecorationImage(
                              image: AssetImage(assetimagepath.toString()),fit: BoxFit.cover
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(11))
                      ),
                      height: size.height * 0.09,
                      width: size.width * 0.21,
                      // child: Image.asset(assetimagepath.toString(),fit: BoxFit.cover
                      //   ,height: size.height * 0.13,width: size.width * 0.5,),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text('Name: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                            Text(title.toString(),style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),
                          ],
                        ),
                        // Row(
                        //   children: [
                        //     Text('Email: ',style: TextStyle(fontWeight:FontWeight.w400,fontSize:12),),
                        //     Text(email.toString(),style: TextStyle(fontWeight:FontWeight.w400,fontSize:12,color: appcolor.appcolors),),
                        //   ],
                        // ),

                        Row(
                          children: [
                            Text('Profession: ',style: TextStyle(fontWeight:FontWeight.w400,fontSize:10),),
                            Text(Profession.toString(),style: TextStyle(fontWeight:FontWeight.w400,fontSize:10,color: appcolor.appcolors),),
                          ],
                        ),
                        Row(
                          children: [
                            Icon(Icons.star,color: Colors.yellow,),
                            Text(rating.toString(),style: TextStyle(fontWeight:FontWeight.w400,fontSize:12,color: appcolor.appcolors),),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Container(
                            //   decoration: BoxDecoration(
                            //       border: Border.all(color: Color(0xff54B2E6)),
                            //     borderRadius: BorderRadius.all(Radius.circular(5))
                            //   ),
                            //   child: Padding(
                            //     padding: const EdgeInsets.all(5.0),
                            //     child: Text('Not Rated',style: TextStyle(fontSize: 12)),
                            //   ),
                            // ),
                            // SizedBox(width: 60,),
                            Container(

                              decoration: BoxDecoration(
                                  color: Colors.green,
                                  borderRadius: BorderRadius.all(Radius.circular(5))
                              ),

                              height: 30,
                              width: 70,
                              child: Padding(
                                padding: const EdgeInsets.all(3.0),
                                child: Center(
                                  child:Icon(Icons.call,color: Colors.white,),
                                ),
                              ),
                            ),
                            SizedBox(width: 10,),
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.deepPurpleAccent,
                                  borderRadius: BorderRadius.all(Radius.circular(5))
                              ),

                              height: 30,
                              width: 70,
                              child: Center(
                                child:Icon(Icons.video_call,color: Colors.white,),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                ],
              ),
              // Padding(
              //   padding: const EdgeInsets.only(left: 10,right: 5,top: 5),
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //     children: [
              //       // Container(
              //       //   decoration: BoxDecoration(
              //       //       border: Border.all(color: Color(0xff54B2E6)),
              //       //     borderRadius: BorderRadius.all(Radius.circular(5))
              //       //   ),
              //       //   child: Padding(
              //       //     padding: const EdgeInsets.all(5.0),
              //       //     child: Text('Not Rated',style: TextStyle(fontSize: 12)),
              //       //   ),
              //       // ),
              //       // SizedBox(width: 60,),
              //       Container(
              //
              //         decoration: BoxDecoration(
              //             color: Colors.green,
              //             borderRadius: BorderRadius.all(Radius.circular(5))
              //         ),
              //
              //         height: 30,
              //         width: 70,
              //         child: Padding(
              //           padding: const EdgeInsets.all(3.0),
              //           child: Center(
              //             child:Icon(Icons.call,color: Colors.white,),
              //           ),
              //         ),
              //       ),
              //       Container(
              //         decoration: BoxDecoration(
              //             color: Colors.deepPurpleAccent,
              //             borderRadius: BorderRadius.all(Radius.circular(5))
              //         ),
              //
              //         height: 30,
              //         width: 70,
              //         child: Center(
              //           child:Icon(Icons.video_call,color: Colors.white,),
              //         ),
              //       ),
              //     ],
              //   ),
              // )
            ],
          ),
        ),
      ),
      Container(color: Colors.black,height: 1,width: size.width,),
      SizedBox(height: 10,),
    ],
  );
}

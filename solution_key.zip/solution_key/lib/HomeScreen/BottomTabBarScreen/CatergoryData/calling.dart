import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/DetailPage/detail_Screen.dart';
import 'package:solution_key/appcolor.dart';
import 'package:solution_key/seachPage/SeacrhPage.dart';

class Calling extends StatefulWidget {
  const Calling({super.key});

  @override
  State<Calling> createState() => _CallingState();
}

class _CallingState extends State<Calling> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(actions: [
      //                   Container(
      //          child: Row(
      //           children: [
      //             Padding(
      //               padding: const EdgeInsets.only(left: 10,right: 10),
      //               child: InkWell(
      //                 onTap: () {

      //                 },
      //                 highlightColor: Colors.transparent,
      //                 child: CircleAvatar(
      //                   radius: 30,
      //                   child: Text("SB"),
      //                   backgroundColor: appcolor.greyColor,

      //                 ),
      //               ),
      //             ),
      //             Text("Hi,Saurabh",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 20),),
      //             SizedBox(
      //               width: 25,
      //             ),
      //             IconButton(onPressed:() {

      //             }, icon: Icon(Icons.notifications_outlined)),
      //             IconButton(onPressed:() {

      //             }, icon: Icon(Icons.favorite_outline,)),

      //           ],
      //          ),
      //         ),
      //   ],
      //   elevation: 5,
      //   ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 5,
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(11)),
                      color: appcolor.greyColor),
                  width: MediaQuery.of(context).size.width,
                  child: Container(
                      child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.search,
                              color: appcolor.black,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            InkWell(
                                onTap: () {
                                  showSearch(
                                      context: context, delegate: Searchpage());
                                },
                                child: Text(
                                  'What are you looking for?',
                                  style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.w400,
                                  ),
                                )),
                          ],
                        ),
                      ],
                    ),
                  )),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Column(
              children: [
                CustomCallingWidget(
                  name: "Nisha",
                  imageUrl: "assets/img_8.png",
                  about:
                      "with 30 years of proffessional lineage as a second-generation laweyer at delhi high court, bombay high court,karnataka high court, Telangana High Court",
                  experience: "15 years of experience",
                  languages: ["Hindi,English,Tamil"],
                  callCharge: 27,
                  onAudioCall: () {},
                  onVideoCall: () {},
                  isAvailable: true,
                  isVerified: true,
                  rating: 4.8,
                  potentialQuestions: [
                    '1. What is your area of expertise?',
                    '2. How many years of experience do you have?',
                    //  '3. Can you provide information about your educational background?',
                    //  '4. What types of medical conditions do you specialize in?',
                    '3. How do you approach patient care?',
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                CustomCallingWidget(
                  name: "Saurabh",
                  imageUrl: "assets/img_7.png",
                  about:
                      "with 30 years of proffessional lineage as a second-generation laweyer at delhi high court, bombay high court,karnataka high court, Telangana High Court",
                  experience: "15 years of experience",
                  languages: ["Hindi,English,Tamil"],
                  callCharge: 37,
                  onAudioCall: () {},
                  onVideoCall: () {},
                  isAvailable: true,
                  isVerified: true,
                  rating: 4.8,
                  potentialQuestions: [
                    '1. Can you explain your treatment philosophy?',
                    '2. What services do you offer?',
                    '3. Do you accept insurance?',
                    '4. How do I schedule an appointment with you?',
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                CustomCallingWidget(
                  name: "Dr. Gangwar",
                  imageUrl: "assets/img_6.png",
                  about:
                      "with 30 years of proffessional lineage as a second-generation laweyer at delhi high court, bombay high court,karnataka high court, Telangana High Court",
                  experience: "10 years of experience",
                  languages: ["Hindi,English,Tamil"],
                  callCharge: 27,
                  onAudioCall: () {},
                  onVideoCall: () {},
                  isAvailable: true,
                  isVerified: true,
                  rating: 4.5,
                  potentialQuestions: [
                    '1. What is your area of expertise?',
                    '2. How many years of experience do you have?',
                    //  '3. Can you provide information about your educational background?',
                    //  '4. What types of medical conditions do you specialize in?',
                    '3. How do you approach patient care?',
                  ],
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}

class CustomCallingWidget extends StatefulWidget {
  final String name;
  final String imageUrl;
  final bool isVerified;
  final double rating;
  final String about;
  final String experience;
  final List<String> languages;
  final bool isAvailable;
  final double callCharge;
  final VoidCallback onAudioCall;
  final VoidCallback onVideoCall;
  final List<String> potentialQuestions;

  CustomCallingWidget(
      {required this.name,
      required this.imageUrl,
      this.isVerified = false,
      this.rating = 0.0,
      required this.about,
      required this.experience,
      required this.languages,
      this.isAvailable = false,
      required this.callCharge,
      required this.onAudioCall,
      required this.onVideoCall,
      required this.potentialQuestions});

  @override
  State<CustomCallingWidget> createState() => _CustomCallingWidgetState();
}

class _CustomCallingWidgetState extends State<CustomCallingWidget> {
  bool showFullAbout = false;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 40,
                backgroundImage: AssetImage(widget.imageUrl),
              ),
              SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.name,
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  if (widget.isVerified)
                    Row(
                      children: [
                        Icon(
                          Icons.verified,
                          color: Colors.blue,
                          size: 16,
                        ),
                        Text(
                          'Verified',
                          style: TextStyle(
                            color: Colors.blue,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                ],
              ),
              Spacer(),
              Row(
                children: [
                  Icon(
                    Icons.star,
                    color: Colors.yellow,
                  ),
                  Text(
                    '${widget.rating}',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Text(
              showFullAbout
                  ? widget.about
                  : '${widget.about.substring(0, 50)}...',
              maxLines: showFullAbout ? 10 : 3,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.poppins()),
          if (!showFullAbout)
            TextButton(
              onPressed: () {
                setState(() {
                  showFullAbout = true;
                });
              },
              child: Text('Read More', style: GoogleFonts.poppins()),
            ),
          if (showFullAbout)
            TextButton(
              onPressed: () {
                setState(() {
                  showFullAbout = false;
                });
              },
              child: Text('Read Less', style: GoogleFonts.poppins()),
            ),
          Text(
            'Experience: ${widget.experience}',
            style: GoogleFonts.poppins(),
          ),
          Text('Languages: ${widget.languages.join(', ')}',
              style: GoogleFonts.poppins()),
          Text(
              '${widget.isAvailable ? 'Available: New Delhi, Noida, Gurugram' : 'Not Available'}',
              style: GoogleFonts.poppins()),
          Text('Charges:\n \Rs${widget.callCharge.toStringAsFixed(2)}/per Min',
              style: GoogleFonts.poppins()),
          SizedBox(height: 10),
          Text(
            'What can you ask me?',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: widget.potentialQuestions
                .map((question) => Text(
                      '• $question',
                      style: GoogleFonts.poppins(),
                    ))
                .toList(),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ChatScreen(name: widget.name)));
                  },
                  style: IconButton.styleFrom(backgroundColor: Colors.green),
                  icon: Icon(Icons.chat_bubble_outline_outlined,size: 35, color: Colors.white,)),
              IconButton(
                style: IconButton.styleFrom(
                    backgroundColor: Colors.deepPurpleAccent),
                onPressed: widget.onAudioCall,
                icon: Icon(
                  Icons.call,
                  size: 35,
                ),
                color: Colors.white,
              ),
              // SizedBox(
              //   width: 30,
              // ),
              IconButton(
                style: IconButton.styleFrom(backgroundColor: Colors.green),
                onPressed: widget.onVideoCall,
                icon: Icon(
                  Icons.video_call,
                  size: 35,
                ),
                color: Colors.white,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

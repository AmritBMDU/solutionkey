import 'package:carousel_slider/carousel_slider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:like_button/like_button.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/multipleHomeScreen/subCategory.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Bookmarks.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/HelpCenter/Help.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/History.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Profile.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Report_block.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/Reset_password.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/YourContact.dart';
import 'package:solution_key/mainPage.dart';
import 'package:solution_key/seachPage/SeacrhPage.dart';
import 'package:solution_key/appcolor.dart';
import '../../../DetailPage/detail_Screen.dart';
import '../../../Widget/gradient_text.dart';
import '../../../seachPage/SetMetting.dart';
import '../../../DetailPage/Widget/filters/FilterPage.dart';
import '../CatergoryData/Trending.dart';

final imgList = [
  'assets/img.png',
  'assets/img_1.png',
  'assets/img_2.png',
  'assets/img_3.png',
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int _current = 0;
  PageController _pageController = PageController(viewportFraction: 0.9);
  var data;
  @override
  void initState() {
    super.initState();
    // latestProduct();
  }

  var product = {'counter': 8};
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      key: _scaffoldKey,
      resizeToAvoidBottomInset: false,
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               Padding(padding:EdgeInsets.all(8),
               child: OnlineStatusCount(),),


              // Padding(
              //   padding: const EdgeInsets.all(8.0),
              //   child: Card(
              //     elevation: 5,
              //     child: Container(
              //       height: 50,
              //       decoration: BoxDecoration(
              //           borderRadius: BorderRadius.all(Radius.circular(11)),
              //           color: appcolor.greyColor),
              //       width: MediaQuery.of(context).size.width,
              //       child: Container(
              //           child: Padding(
              //         padding: const EdgeInsets.all(12.0),
              //         child: Row(
              //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //           children: [
              //             // Row(
              //             //   children: [
              //             //     Icon(
              //             //       Icons.search,
              //             //       color: appcolor.black,
              //             //     ),
              //             //     SizedBox(
              //             //       width: 10,
              //             //     ),
              //             //     InkWell(
              //             //         onTap: () {
              //             //           showSearch(
              //             //               context: context,
              //             //               delegate: Searchpage());
              //             //         },
              //             //         child: Text(
              //             //           'Search for consultant',
              //             //           style: TextStyle(
              //             //             fontWeight: FontWeight.w400,
              //             //           ),
              //             //         )),
              //             //   ],
              //             // ),
              //             // Row(
              //             //   mainAxisAlignment: MainAxisAlignment.end,
              //             //   children: [
              //             //     SizedBox(
              //             //       width: 10,
              //             //     ),
              //             //     InkWell(
              //             //         onTap: () {
              //             //           Navigator.push(
              //             //               context,
              //             //               MaterialPageRoute(
              //             //                   builder: (context) =>
              //             //                       FilterPage()));
              //             //         },
              //             //         child: FaIcon(
              //             //           FontAwesomeIcons.filter,
              //             //           color: appcolor.black,
              //             //         ))
              //             //   ],
              //             // )
              //           ],
              //         ),
              //       )),
              //     ),
              //   ),
              // ),
              Column(children: [
                CarouselSlider.builder(
                    itemCount: imgList.length,
                    itemBuilder: (context, index, realindex) {
                      final urlimage = imgList[index];
                      return Container(
                        height: 100,
                        width: MediaQuery.of(context).size.width,
                        child: Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          shadowColor: appcolor.mixColor,
                          elevation: 5,
                          child: Image.asset(
                            urlimage,
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                    options: CarouselOptions(
                        autoPlay: true,
                        height: 200,
                        enlargeCenterPage: false,
                        aspectRatio: 2.0,
                        viewportFraction: 1.0,
                        initialPage: 0,
                        onPageChanged: (index, reason) {
                          setState(() {
                            _current = index;
                          });
                        })),
                Container(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: AnimatedSmoothIndicator(
                      activeIndex: _current,
                      count: imgList.length,
                      effect: JumpingDotEffect(
                          dotWidth: 8,
                          dotHeight: 8,
                          activeDotColor: appcolor.appcolors,
                          dotColor: Colors.black12),
                    ),
                  ),
                ),
              ]),
              // List of Category
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Wrap(
                          spacing: 8,
                          children: <Widget>[
                            customwidget(
                              assetimagepath: 'assets/img.png',
                              callback: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            MultiSelectItemPage()));
                              },
                              title: 'IT Consultant',
                            ),
                            customwidget(
                              assetimagepath: 'assets/img_1.png',
                              callback: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Trending()));
                              },
                              title: 'Developer',
                            ),
                            customwidget(
                              assetimagepath: 'assets/img_2.png',
                              callback: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Trending()));
                              },
                              title: 'Doctor',
                            ),
                            customwidget(
                              assetimagepath: 'assets/img_3.png',
                              callback: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Trending()));
                              },
                              title: 'Psychologist',
                            ),
                            customwidget(
                              assetimagepath: 'assets/img_4.png',
                              callback: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Trending()));
                              },
                              title: 'Educator',
                            ),
                            customwidget(
                              assetimagepath: 'assets/img_5.png',
                              callback: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Trending()));
                              },
                              title: 'science',
                            ),
                            customwidget(
                              assetimagepath: 'assets/img_6.png',
                              callback: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Trending()));
                              },
                              title: 'All',
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),

              // List of data

              customizelist(
                callback: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => MyScreen(profession: 'Doctor', name: 'Rahul Bhardwaj', imgurl: 'assets/img_2.png',)));
                },
                title: 'Rahul',
                assetimagepath: 'assets/img_2.png',
                context: context,
                Profession: 'Doctor',
                rating: '3.0',
              ),
              customizelist(
                callback: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) =>MyScreen(profession: 'Couple Relation', name: 'Nisha', imgurl: 'assets/img_8.png',)));
                },
                title: 'Nisha',
                assetimagepath: 'assets/img_8.png',
                context: context,
                Profession: 'Couple Relation',
                rating: '5.0',
              ),
              customizelist(
                callback: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) =>MyScreen(isAvailable: false,profession: 'Plumber', name: 'Mohit', imgurl:  'assets/img_1.png',)));
                },
                title: 'Mohit',
                assetimagepath: 'assets/img_1.jpg',
                context: context,
                Profession: 'BDM',
                rating: '4.0',
                isAvailable: false
              ),
              customizelist(
                callback: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) =>MyScreen(profession: 'Electrician', name: 'Rajesh', imgurl:'assets/img.png',)));
                },
                title: 'Rajesh',
                assetimagepath: 'assets/img.png',
                context: context,
                Profession: 'Lawyer',
                rating: '3.0',
              ),
              customizelist(
                callback: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) =>MyScreen(profession: 'Doctor', name: 'Rahul', imgurl:  'assets/img_2.png',)));
                },
                title: 'Rahul',
                assetimagepath: 'assets/img_2.png',
                context: context,
                Profession: 'Doctor',
                rating: '2.0',
              ),
              customizelist(
                callback: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) =>MyScreen(isAvailable: false,profession: 'Couple Relation', name: 'Nisha', imgurl:'assets/img_8.png',)));
                },
                title: 'Nisha',
                assetimagepath: 'assets/img_8.png',
                context: context,
                Profession: 'Couple Relation',
                rating: '5.0',
                isAvailable: false
              ),
              customizelist(
                  callback: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) =>MyScreen(profession: 'Plumber', name: 'Mohit', imgurl:'assets/img_1.png',)));
                  },
                  title: 'Mohit',
                  assetimagepath: 'assets/img_1.png',
                  context: context,
                  Profession: 'IT consultant',
                  rating: '4.0'),
              customizelist(
                callback: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) =>MyScreen(profession:"Electrician", name: 'Rajesh', imgurl: 'assets/img_2.png',)));
                },
                title: 'Rajesh',
                assetimagepath: 'assets/img_3.png',
                context: context,
                Profession: 'App Developer',
                rating: '3.0',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget customwidget({
  Function()? callback,
  String? assetimagepath,
  String? title,
}) {
  return InkWell(
    onTap: callback,
    child: Column(
      children: [
        // Container(
        //   child: PhysicalShape(
        //     elevation: 1,
        //     clipper: ShapeBorderClipper(shape: CircleBorder()),
        //     color: Color(0xffEEEEEE),
        //     child: Container(
        //         height: 80,
        //         width: 100,
        //         child: Image.asset(assetimagepath.toString(),fit: BoxFit.cover,)
        //     ),
        //   ),
        // ),
        // SizedBox(height: 10,),

        CircleAvatar(
          radius: 40,

          backgroundColor: appcolor.greyColor,
          backgroundImage: AssetImage(assetimagepath.toString()),
          // child:Image.asset(assetimagepath.toString(),fit: BoxFit.cover,)
        ),

        GradientText(
          widget: Text(
            '$title',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: appcolor.appcolors,
            ),
          ),
          gradient: appcolor.gradient,
        ),
      ],
    ),
  );
}

Widget customizelist(
    {context,
    Function()? callback,
    String? assetimagepath,
    String? title,
    String? email,
    String? rating,
    String? Profession,
    double? callCharge = 25,
    double? experience = 10,
    bool? isAvailable = true}) {
  var size = MediaQuery.of(context).size;
  List<String> languages = ["Hindi", "English", "Tamil"];
  return Container(
    margin: EdgeInsets.symmetric(vertical: 10),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.5),
          spreadRadius: 2,
          blurRadius: 5,
          offset: Offset(0, 3),
        ),
      ],
    ),
    child: Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: callback,
        child: Container(
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(20)),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.3),
                spreadRadius: 2,
                blurRadius: 10,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      image: DecorationImage(
                        image: AssetImage(assetimagepath.toString()),
                        fit: BoxFit.cover,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                    height: size.height * 0.2,
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      padding: EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Text(
                        'NEW',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(
                            '$title',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          SizedBox(width: 20,),
                         if(isAvailable! )
                          Container(
                            height: 10,
                            width: 10,
                            decoration: BoxDecoration(shape: BoxShape.circle,  color: Colors.green,),
                          
                          )
                          else
                           Container(
                            height: 10,
                            width: 10,
                            decoration: BoxDecoration(shape: BoxShape.circle,  color: Colors.red,),
                          
                          ),
                          SizedBox(width: 10,),
                         if( isAvailable! ) Text("Online")
                         else
                         Text("Offline")
                        ],
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.star,
                            color: Colors.yellow,
                          ),
                          Text(
                            '$rating',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Profession: $Profession',
                        style: TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                      // LikeButton(
                      //   size: 30,
                      //   circleColor: CircleColor(
                      //       start: Color(0xff00ddff), end: Color(0xff0099cc)),
                      //   bubblesColor: BubblesColor(
                      //     dotPrimaryColor: Color(0xff33b5e5),
                      //     dotSecondaryColor: Color(0xff0099cc),
                      //   ),
                      //   likeBuilder: (bool isLiked) {
                      //     return FaIcon(
                      //       FontAwesomeIcons.thumbsUp,
                      //       color: isLiked ? Colors.red : appcolor.appcolors,
                      //       size: 20,
                      //     );
                      //   },
                      //   likeCount: 665,
                      //   // countBuilder: (int count, bool isLiked, String text) {
                      //   //   var color = isLiked ? Colors.deepPurpleAccent : Colors.grey;
                      //   //   Widget result;
                      //   //   if (count == 0) {
                      //   //     result = Text(
                      //   //       "love",
                      //   //       style: TextStyle(color: color),
                      //   //     );
                      //   //   } else
                      //   //     result = Text(
                      //   //       text,
                      //   //       style: TextStyle(color: color),
                      //   //     );
                      //   //   return result;
                      //   // },
                      // ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Experience: ${experience}',
                        style: TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                      // SizedBox(width: 50,),
                      // LikeButton(
                      //   size: 30,
                      //   circleColor: CircleColor(
                      //       start: Color(0xff00ddff), end: Color(0xff0099cc)),
                      //   bubblesColor: BubblesColor(
                      //     dotPrimaryColor: Color(0xff33b5e5),
                      //     dotSecondaryColor: Color(0xff0099cc),
                      //   ),
                      //   likeBuilder: (bool isLiked) {
                      //     return FaIcon(
                      //       FontAwesomeIcons.thumbsUp,
                      //       color: isLiked ? Colors.red : appcolor.appcolors,
                      //       size: 20,
                      //     );
                      //   },
                      //   likeCount: 665,
                      //   // countBuilder: (int count, bool isLiked, String text) {
                      //   //   var color = isLiked ? Colors.deepPurpleAccent : Colors.grey;
                      //   //   Widget result;
                      //   //   if (count == 0) {
                      //   //     result = Text(
                      //   //       "love",
                      //   //       style: TextStyle(color: color),
                      //   //     );
                      //   //   } else
                      //   //     result = Text(
                      //   //       text,
                      //   //       style: TextStyle(color: color),
                      //   //     );
                      //   //   return result;
                      //   // },
                      // ),
                      Container(
                        width: 100,
                        height: 30,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: appcolor.appcolors),
                          onPressed: () {},
                          child: Text(
                            'Follow',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                                color: Colors.white),
                          ),
                         
                        ),
                      )

                      // Text(
                      //   'Experience: ${experience}',
                      //   style: TextStyle(
                      //     color: Colors.grey,
                      //   ),
                      // ),
                    ],
                  ),
                  Text(
                    'Languages: ${languages.join(', ')}',
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  ),
                  Text(
                    isAvailable!
                        ? 'Available: New Delhi, Noida, Gurugram'
                        : 'Not Available',
                    style: TextStyle(
                      color: isAvailable! ? Colors.green : Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                       Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Charges:',
                        style: TextStyle(
                          color: Colors.black,fontWeight: FontWeight.bold
                          
                        ),
                      ),
                      Row(
                        children: [
                          SizedBox(width: 5,),
                          Text(
                            '${callCharge}',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            '/min',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.bold
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 20),
              Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // Column(
                  //   children: [
                  //     Text(
                  //       'Charges:',
                  //       style: TextStyle(
                  //         color: Colors.black,
                  //       ),
                  //     ),
                  //     Row(
                  //       children: [
                  //         SizedBox(width: 5,),
                  //         Text(
                  //           '${callCharge}',
                  //           style: TextStyle(
                  //               color: Colors.black,
                  //               fontSize: 20,
                  //               fontWeight: FontWeight.bold),
                  //         ),
                  //         Text(
                  //           '/min',
                  //           style: TextStyle(
                  //             color: Colors.black,
                  //           ),
                  //         ),
                  //       ],
                  //     ),
                  //   ],
                  // ),
                  // SizedBox(
                  //   width: 40,
                  // ),
                  CustomActionButton(
                    backgroundColor: Colors.green,
                    icon: Icons.call,
                    onPressed: () {
                      // Implement your call action
                    },
                  ),
                  // SizedBox(
                  //   width: 25,
                  // ),
                  CustomActionButton(
                    backgroundColor: Colors.deepPurpleAccent,
                    icon: Icons.video_call,
                    onPressed: () {
                      // Implement your video call action
                    },
                  ),
                  CustomActionButton(backgroundColor: Colors.green, icon:Icons.chat_bubble_outlined)
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class CustomActionButton extends StatelessWidget {
  final Color backgroundColor;
  final IconData icon;
  final VoidCallback? onPressed;

  const CustomActionButton({
    required this.backgroundColor,
    required this.icon,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.all(Radius.circular(5)),
      ),
      height: 40,
      width: 90,
      child: InkWell(
        onTap: onPressed,
        child: Center(
          child: Icon(
            icon,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}


class OnlineStatusCount extends StatefulWidget {
  const OnlineStatusCount({super.key});

  @override
  State<OnlineStatusCount> createState() => _OnlineStatusCountState();
}

class _OnlineStatusCountState extends State<OnlineStatusCount> {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          height: 100,
          width: MediaQuery.of(context).size.width*0.48,
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            border: Border.all(color: Colors.grey,width: 1)
            
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [Text("Online",style: GoogleFonts.poppins(color: Colors.black,fontWeight:FontWeight.bold ),),
                Container(height: 10,width: 10,decoration: BoxDecoration(shape: BoxShape.circle,color: Colors.green),)
                ],
              ),
              Row(
                children: [
                  CircleAvatar(
                    backgroundImage: AssetImage("assets/img_2.png"),
                    radius: 20,
                  ),
                   CircleAvatar(
                    backgroundImage: AssetImage("assets/img_4.png"),
                    radius: 20,
                  ),
                   CircleAvatar(
                    backgroundImage: AssetImage("assets/img_3.png"),
                    radius: 20,
                  ),
                  SizedBox(width: 10,),
                  Text("+166",style: GoogleFonts.poppins(color: Colors.black),)
                ],
              )
              ],
            ),
          ),
        ),
        SizedBox(width: 10,),
       Container(
          height: 100,
          width: MediaQuery.of(context).size.width*0.45,
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            border: Border.all(color: Colors.grey,width: 1)
            
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
            children: [
           
             Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [Text("Ongoing calls",style: GoogleFonts.poppins(color: Colors.black,fontWeight:FontWeight.bold ),),
                Container(height: 10,width: 10,decoration: BoxDecoration(shape: BoxShape.circle,color: Colors.orange),)
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10,bottom: 10),
                child: Text("25",style: GoogleFonts.poppins(color: Colors.black)),
              )
              ],
            ),
          ),
        ),
      ],

    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/CatergoryData/Trending.dart';
import 'package:solution_key/Widget/elevatedButtn.dart';
import 'package:solution_key/appcolor.dart';

import '../../../seachPage/SubCategorySearchpage.dart';

class CustomData {
  static List<Map> mydata = [
    {
      "id": 1,
      "name": 'Tester1',
      "email": 'tester1@gamil.com',
      "address": 'Delhi'
    },
    {
      "id": 2,
      "name": 'Tester2',
      "email": 'tester2@gamil.com',
      "address": 'Noida'
    },
    {
      "id": 3,
      "name": 'Tester3',
      "email": 'tester3@gamil.com',
      "address": 'Kolkata'
    },
    {
      "id": 4,
      "name": 'Tester4',
      "email": 'tester4@gamil.com',
      "address": 'Goa'
    },
    {
      "id": 5,
      "name": 'Tester5',
      "email": 'tester5@gamil.com',
      "address": 'Mau'
    },
    {
      "id": 6,
      "name": 'Tester6',
      "email": 'tester6@gamil.com',
      "address": 'Bihar'
    },
    {
      "id": 7,
      "name": 'Tester7',
      "email": 'tester7@gamil.com',
      "address": 'Varanasi'
    },
    {
      "id": 8,
      "name": 'Tester8',
      "email": 'tester8@gamil.com',
      "address": 'GorakhPur'
    },
    {
      "id": 9,
      "name": 'Tester9',
      "email": 'tester9@gamil.com',
      "address": 'RameshNagar'
    },
    {
      "id": 10,
      "name": 'Tester10',
      "email": 'tester10@gamil.com',
      "address": 'Shakurpur'
    },
    {
      "id": 11,
      "name": 'Tester11',
      "email": 'tester11@gamil.com',
      "address": 'Patel Nagar'
    },
    {
      "id": 12,
      "name": 'Tester12',
      "email": 'tester12@gamil.com',
      "address": 'Mahuwari'
    },
    {
      "id": 13,
      "name": 'Tester13',
      "email": 'tester13@gamil.com',
      "address": 'Pali'
    },
    {
      "id": 14,
      "name": 'Tester14',
      "email": 'tester14@gamil.com',
      "address": 'Patana'
    },
    {
      "id": 15,
      "name": 'Tester15',
      "email": 'tester15@gamil.com',
      "address": 'Punjab'
    },
  ];


  }
  class MultiSelectItemPage extends StatefulWidget {
    const MultiSelectItemPage({super.key});

    @override
    State<MultiSelectItemPage> createState() => _MultiSelectItemPageStateState();
  }


class _MultiSelectItemPageStateState extends State<MultiSelectItemPage> {
  List<Map> MyData = CustomData.mydata;
  bool isSelectItem = false;
  Map<int, bool> selectedItem = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          },icon: Icon(Icons.arrow_back_outlined,color: appcolor.appcolors,),
        ),
        title: Text("SubCategory",style: TextStyle(color: appcolor.appcolors,fontWeight: FontWeight.w500,),),
        actions: [IconButton(onPressed: (){
          showSearch(context: context, delegate: SubCategorySearchpage());

        }, icon: Icon(Icons.search,color: appcolor.appcolors,))],
      ),

      body: ListView.builder(
        itemBuilder: (builder, index) {
          Map data = MyData[index];
          selectedItem?[index] = selectedItem?[index] ?? false;
          bool? isSelectedData = selectedItem[index];

          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListTile(
              // onLongPress: () {
              //   setState(() {
              //     selectedItem[index] = !isSelectedData!;
              //     isSelectItem = selectedItem.containsValue(true);
              //   });
              // },
              onTap: () {
                setState(() {
                      selectedItem[index] = !isSelectedData!;
                      isSelectItem = selectedItem.containsValue(true);
                    });
                // if (isSelectItem) {
                //   setState(() {
                //     selectedItem[index] = !isSelectedData!;
                //     isSelectItem = selectedItem.containsValue(true);
                //   });
                // } else {
                //   // Open Detail Page
                // }
              },
              title: Text("${data['name']}"),
              // subtitle: Container(
              //   child: Wrap(
              //     children: [
              //       Text("Email    :   "),
              //       Text("${data['email']}"),
              //     ],
              //   ),
              // ),
              // trailing: Text("${data['address']}"),
              leading: _mainUI(isSelectedData!, data),
            ),
          );
        },
        itemCount: MyData.length,
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(15.0),
        child: elevated(context: context,name: 'Continue', navigative: Trending()),
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //   },
      //   tooltip: 'Increment',
      //   child: const Icon(Icons.check),
      // ),
    );
  }


  Widget _mainUI(bool isSelected, Map ourdata) {
    return Icon(
        isSelected ? Icons.check_box : Icons.check_box_outline_blank,
        color: Theme.of(context).primaryColor,
      );
  }
}
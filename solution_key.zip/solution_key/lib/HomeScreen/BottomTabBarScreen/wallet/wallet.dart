import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/wallet/Statement.dart';
import 'package:solution_key/appcolor.dart';

import 'AddAmount.dart';

class wallet extends StatefulWidget {
  const wallet({super.key});

  @override
  State<wallet> createState() => _walletState();
}

class _walletState extends State<wallet> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title:  Text("Wallet",style: GoogleFonts.poppins(fontWeight: FontWeight.w400,fontSize: 22),) ,
        actions: [
                        Container(
               child: Row(
                children: [
                
               
                  SizedBox(
                    width: 25,
                  ),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.notifications_outlined)),
                  IconButton(onPressed:() {
                    
                  }, icon: Icon(Icons.favorite_outline,)),
                 
                ],
               ),
              ),
        ],
        elevation: 5,
        ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text('SolutionKey ',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
                Text('Wallet',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.black),),
                SizedBox(width: 100,),
                TextButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Statement()));
                }, child:  Text('Statement',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),))
              ],
            ),
            SizedBox(height: 30,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('₹0.00 ',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors,fontSize: 25),),
                SizedBox(width: 120,),
                OutlinedButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>AddAmount()));
                }, child:  Text('Add Money',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),))
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text('In case of any issue',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.black,fontSize:12),),
                TextButton(onPressed: (){}, child:  Text('Call Us',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors,fontSize: 15),))
              ],
            ),
            Text('SolutionKey Balance',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.black,fontSize: 14),),
            SizedBox(height: 10,),
            Card(
              child: Center(
                child: Container(
                  height: size.height * 0.1,
                  width: size.width* 0.7,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('0 ',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors,fontSize: 20),),
                          Text('Total Calls',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors,fontSize: 14),),

                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(height: size.height ,
                        width: 1,
                          color: Colors.black,
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('00:00 ',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors,fontSize: 20),),
                          Text('Total Mins',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors,fontSize: 14),),

                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 10,),
            Text('Recent Activity',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.black,fontSize: 14),),
            SizedBox(height: 30,),
            Center(
              child: Image.asset('assets/nocallfound.png',color: appcolor.appcolors,),
            )
          ],
        ),
      ),
    );
  }
}

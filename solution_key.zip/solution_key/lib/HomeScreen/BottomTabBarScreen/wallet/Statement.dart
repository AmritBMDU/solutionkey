import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';


class Statement extends StatefulWidget {
  const Statement({super.key});

  @override
  State<Statement> createState() => _Statement();
}
class _Statement extends State<Statement> {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false,
        centerTitle: true,
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
        title: Text('Statement',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
      ),
      // endDrawer: Drawers(context),
      body: Column(
        children: [
          Card(
            child: ExpansionTile(
              maintainState: true,
              expandedCrossAxisAlignment: CrossAxisAlignment.end,

              title: Text('Friday,30 Sep',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Transiont id: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('PQR0d0331098 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                      Row(
                        children: [
                          Text('Status: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Sucess',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: Colors.green),),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Time: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('10:35 AM ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                      Row(
                        children: [
                          Text('Amount: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Rs 500 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),


                    ],
                  ),

                ),
                SizedBox(height: 10,),
                Container(height: 1 ,color: Colors.black,),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Transiont id: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('PQR0d0331096 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),
                        ],
                      ),
                      Row(
                        children: [
                          Text('Status: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Failed   ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: Colors.red),),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Time: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('10:30 AM ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                      Row(
                        children: [
                          Text('Amount: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Rs 500 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                    ],
                  ),

                ),
                // ListTile(
                //     title: Row(
                //       children: [
                //         Text('Transiont id: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                //         Text('PQR0d0331098 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),
                //
                //       ],
                //     ),
                //     leading: Row(
                //      children: [
                //     Text('Status: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                //     Text('Sucessful',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: Colors.green),),
                //   ],
                // ),
                //   subtitle: Row(
                //     children: [
                //       Text('Time: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                //       Text('10:35 AM ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),
                //
                //     ],
                //   ),
                // ),

              ],

            ),
          ),
          Card(
            child: ExpansionTile(
              maintainState: true,
              expandedCrossAxisAlignment: CrossAxisAlignment.end,

              title: Text('Tuesday,25 Sep',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Transiont id: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('PQR0d0331522 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                      Row(
                        children: [
                          Text('Status: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Sucess',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: Colors.green),),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Time: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('12:14 AM ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                      Row(
                        children: [
                          Text('Amount: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Rs 200 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),


                    ],
                  ),

                ),
                SizedBox(height: 10,),
                Container(height: 1 ,color: Colors.black,),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Transiont id: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('PQR0d0331096 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),
                        ],
                      ),
                      Row(
                        children: [
                          Text('Status: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Failed   ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: Colors.red),),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text('Time: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('12:10 AM ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                      Row(
                        children: [
                          Text('Amount: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                          Text('Rs 400 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),

                        ],
                      ),
                    ],
                  ),

                ),
                // ListTile(
                //     title: Row(
                //       children: [
                //         Text('Transiont id: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                //         Text('PQR0d0331098 ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),
                //
                //       ],
                //     ),
                //     leading: Row(
                //      children: [
                //     Text('Status: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                //     Text('Sucessful',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: Colors.green),),
                //   ],
                // ),
                //   subtitle: Row(
                //     children: [
                //       Text('Time: ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13),),
                //       Text('10:35 AM ',style: TextStyle(fontWeight:FontWeight.w500,fontSize:13,color: appcolor.appcolors),),
                //
                //     ],
                //   ),
                // ),

              ],

            ),
          ),
        ],
      )
    );

  }


}





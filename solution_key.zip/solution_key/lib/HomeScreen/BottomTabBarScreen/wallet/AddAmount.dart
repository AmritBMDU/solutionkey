import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/appcolor.dart';


class AddAmount extends StatefulWidget {
   AddAmount({super.key,this.title="Add Amount",this.subtitle="Recharge Your Wallet Now",this.button="Pay Now"});
  String title;
  String subtitle;
  String button;

  @override
  State<AddAmount> createState() => _AddAmountState();
}
class _AddAmountState extends State<AddAmount> {

  TextEditingController add_money = new TextEditingController();
  List<String> values = ['₹50', '₹100', '₹200', '₹500',];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
    
        title: Text(widget.title,style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
      ),
      // endDrawer: Drawers(context),
      body:  Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          
      Center(child: Text(widget.subtitle,style: GoogleFonts.poppins(color: Colors.grey.shade700,fontSize: 24,fontWeight: FontWeight.bold),)),
      Center(child: Text("Available plans for your activity",style: GoogleFonts.poppins(color: Colors.black,fontSize: 16,fontWeight: FontWeight.w500),)),
          SizedBox(height: 10,),
        if(widget.button=="Pay Now")  Padding(
            padding: const EdgeInsets.all(15.0),
            child: Text('Enter amount in wallet',style: GoogleFonts.poppins(color: Colors.grey.shade700,fontSize: 20,fontWeight: FontWeight.w400),)
          ),
            if(widget.button=="Pay Now")  Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: TextFormField(
              keyboardType: TextInputType.phone,
              controller: add_money,
              decoration: InputDecoration(
                labelText: 'Amount',
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue),
                ),
              ),
            ),
          ),
           if(widget.button=="Pay Now")   Padding(
            padding: const EdgeInsets.symmetric(horizontal: 13,vertical: 5),
            child: Text("Minimum Recharge Amount is ₹50 ",style: GoogleFonts.poppins(),),
          ),
            if(widget.button=="Pay Now")  SizedBox(height: 10,),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children:
                  [ 
                    TappableContainer(
                    value: '₹50',
                      notOffer: true,
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹100',
                      notOffer: true,
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹200',
                    notOffer: true,
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  // TappableContainer(
                  //   value: '₹500',
                  //   onTap: (newValue) {
                  //     add_money.text = newValue;
                  //   },
                  //   color: _getColorByIndex(0),
                  // ),
                  ]
                ),
              ),
              SizedBox(
                width: 50,
              ),
               Padding(
            padding: const EdgeInsets.all(8.0),
            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children:
                  [ 
                    TappableContainer(
                    value: '₹500',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹1000',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹1200',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  // TappableContainer(
                  //   value: '₹2000',
                  //   onTap: (newValue) {
                  //     add_money.text = newValue;
                  //   },
                  //   color: _getColorByIndex(0),
                  // ),
                  ]
                ),
              ),
               SizedBox(
                width: 70,
              ),
               Padding(
            padding: const EdgeInsets.all(8.0),
            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children:
                  [ 
                    TappableContainer(
                    value: '₹1500',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹2000',
                    onTap: (newValue) {
                      add_money.text = newValue;
                      
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹4000',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  // TappableContainer(
                  //   value: '₹2000',
                  //   onTap: (newValue) {
                  //     add_money.text = newValue;
                  //   },
                  //   color: _getColorByIndex(0),
                  // ),
                  ]
                ),
              ),
               SizedBox(
                width: 70,
              ),
               Padding(
            padding: const EdgeInsets.all(8.0),
            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children:
                  [ 
                    TappableContainer(
                    value: '₹5000',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹8000',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  TappableContainer(
                    value: '₹15000',
                    onTap: (newValue) {
                      add_money.text = newValue;
                    },
                    color: _getColorByIndex(0),
                  ),
                  // TappableContainer(
                  //   value: '₹2000',
                  //   onTap: (newValue) {
                  //     add_money.text = newValue;
                  //   },
                  //   color: _getColorByIndex(0),
                  // ),
                  ]
                ),
              ), 
              SizedBox(height: 10,),
              Text("Note: You will be charged only when you begin your session",style: GoogleFonts.poppins(),textAlign: TextAlign.center,),
              SizedBox(
                width: 60,
              ),
             
            
          
        
          GestureDetector(
            onTap: (){
              setState(() {
                print(add_money);
                // add money code hear
              });
            },
    
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: appcolor.appcolors
                    ),
                    onPressed: (){
                      var amount =add_money.text;
                     // addAmount(amount,'addWallet');
    
                    },
                    child: Text(widget.button,style: TextStyle(
                        color: Colors.white
                    ),)),
              ),
            ),
          ),
        ],
      ),
    );

  }


}
Color _getColorByIndex(int index) {
  List<Color> colors = [Colors.green, Colors.deepPurpleAccent, Colors.red, Colors.cyan];
  return colors[index];
}

class TappableContainer extends StatelessWidget {

  final String value;
  final Function(String) onTap;
  final Color color;
  bool notOffer;

  TappableContainer({
    required this.value,
    required this.onTap,
    required this.color,
    this.notOffer=false
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 110,
      height:60,
      child: ElevatedButton(
        onPressed:  () {
        onTap(value);
      },
      
      style: ElevatedButton.styleFrom(
        elevation: 5,
        shape: RoundedRectangleBorder(side: BorderSide(color: Colors.orangeAccent),borderRadius: BorderRadius.circular(10))
         
      
       // shadowColor: Colors.orangeAccent
       // disabledBackgroundColor: 
        
      ),
       
        child:notOffer? Text(
          value,
          style: TextStyle(
            color: Colors.black,fontWeight: FontWeight.bold,fontSize: 18
          ),
        ):Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
          value,
          style: TextStyle(
            color: Colors.black,fontWeight: FontWeight.bold
          ),
        ),
        Container(
         
         // color: Colors.redAccent,
          child: Center(child: const Text("5% Extra",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),)),
        )
          ],
        )
        // decoration: BoxDecoration(
        //   borderRadius: BorderRadius.all(Radius.circular(10.0)),
        //   border: Border.all(color: color)
        // ),
      ),
    );
  }
}


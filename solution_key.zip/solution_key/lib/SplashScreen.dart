import 'dart:async';



import 'package:flutter/material.dart';

import 'mainPage.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(Duration(seconds: 2),(){
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>mainPage()));
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        alignment: Alignment.topCenter,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
            
              Center(
                child: Container(
                    height: 800,
                    width: 300,
                    child: Image.asset('assets/logo.jpeg',)),
              ),
              // SizedBox(height: 30,),
              // Text('Solution Key',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),)
            ],
          ),

        ],
      ),
    );
  }
}

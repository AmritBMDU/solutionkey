import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:pinput/pinput.dart';
import 'package:solution_key/LoginPage.dart';
import 'package:solution_key/Widget/elevatedButtn.dart';
import 'package:solution_key/appcolor.dart';
import 'package:solution_key/mainPage.dart';

import '../HomeScreen/mainScreen.dart';
import 'VerifyOtp.dart';
import 'newPassword.dart';

class VerifyOtp extends StatefulWidget {
  const VerifyOtp({super.key});

  @override
  State<VerifyOtp> createState() => _VerifyOtp();
}

class _VerifyOtp extends State<VerifyOtp> {
  var pinMatch ;


  TextEditingController email = TextEditingController();
  TextEditingController pasword = TextEditingController();
  TextEditingController cpasswod= TextEditingController();

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false,
        centerTitle: true,
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        },icon: Icon(Icons.arrow_back,color: appcolor.appcolors,),),
        title: Text('Verification',style: TextStyle(fontWeight: FontWeight.w500,color: appcolor.appcolors),),
      ),
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [

          SizedBox(height: 120,),
          Center(child: Text('Enter Verification Code ' , style: TextStyle(fontWeight: FontWeight.w600,fontSize: 14,),)),
          SizedBox(height: 30,),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: Pinput(
              length: 6,
              showCursor: true,
              onCompleted: (pin) {
                setState(() {
                  pinMatch  = pin;
                });

              },
            ),
          ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('If you did not receive a code.' , style: TextStyle(fontWeight: FontWeight.w600,fontSize: 12,color: Colors.grey),),
           TextButton(onPressed: (){}, child: Text('Resend ' , style: TextStyle(fontWeight: FontWeight.w600,fontSize: 12,),),
           )
            ],
          ),


          // Padding(
          //   padding: const EdgeInsets.only(left: 20,right: 20),
          //   child: SizedBox(
          //     height: size.height * 0.06,
          //     child: TextFormField(
          //       controller: pasword,
          //       keyboardType: TextInputType.visiblePassword,
          //       obscureText: passwordVisible,
          //       decoration: InputDecoration(
          //         hintText: 'Password',
          //         fillColor: Color(0xfff1f3ff
          //         ),
          //         contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          //         filled: true,
          //         suffixIcon: IconButton(
          //           icon: Icon(passwordVisible
          //               ? Icons.visibility
          //               : Icons.visibility_off),
          //           onPressed: () {
          //             setState(
          //                   () {
          //                 passwordVisible = !passwordVisible;
          //               },
          //             );
          //           },
          //         ),
          //         border: OutlineInputBorder(
          //             borderRadius: BorderRadius.all(Radius.circular(11),
          //             ),
          //             borderSide: BorderSide()
          //         ),
          //         focusedBorder: OutlineInputBorder(
          //             borderSide: BorderSide(color: Color(0xff1f42ba)
          //             ),
          //             borderRadius: BorderRadius.all(Radius.circular(11))
          //         ),
          //       ),
          //       validator: (value) {
          //         if (value!.isEmpty) {
          //           return "Username cannot be empty";
          //         }else if(value.length < 6){
          //           return "Password length should be atleast 6";
          //         }
          //         return null;
          //       },
          //       onChanged: (value) {
          //         //  name = value;
          //         setState(() {});
          //       },
          //     ),
          //   ),
          // ),
          // SizedBox(height: 25,),
          //
          // Padding(
          //   padding: const EdgeInsets.only(left: 20,right: 20),
          //   child: SizedBox(
          //     height: size.height * 0.06,
          //     child: TextFormField(
          //       controller: cpasswod,
          //       keyboardType: TextInputType.visiblePassword,
          //       obscureText: passwordVisible1,
          //       decoration: InputDecoration(
          //         hintText: 'Conform Password',
          //         fillColor: Color(0xfff1f3ff
          //         ),
          //         contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          //         filled: true,
          //         suffixIcon: IconButton(
          //           icon: Icon(passwordVisible1
          //               ? Icons.visibility
          //               : Icons.visibility_off),
          //           onPressed: () {
          //             setState(
          //                   () {
          //                 passwordVisible1 = !passwordVisible1;
          //               },
          //             );
          //           },
          //         ),
          //         border: OutlineInputBorder(
          //             borderRadius: BorderRadius.all(Radius.circular(11),
          //             ),
          //             borderSide: BorderSide()
          //         ),
          //         focusedBorder: OutlineInputBorder(
          //             borderSide: BorderSide(color: Color(0xff1f42ba)
          //             ),
          //             borderRadius: BorderRadius.all(Radius.circular(11))
          //         ),
          //       ),
          //       validator: (value) {
          //         if (value!.isEmpty) {
          //           return "Username cannot be empty";
          //         }else if(value.length < 6){
          //           return "Password length should be atleast 6";
          //         }
          //         return null;
          //       },
          //       onChanged: (value) {
          //         //  name = value;
          //         setState(() {});
          //       },
          //     ),
          //   ),
          // ),
          // SizedBox(height: 20,),
          elevated(context: context,name: 'Send', navigative: newPassword()),
          TextButton(onPressed: (){
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage()));
          }, child: Text('Back to Login ',style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400,color: Colors.black),)),
          SizedBox(height: 120,),
          Text('Or Continue with',style: TextStyle(color: Color(0xff1f42ba)),),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.google,color: Colors.black,)),

              ),
              SizedBox(width: 10,),
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.facebook,color: Colors.black,)),

              ),
              SizedBox(width: 10,),
              Container(
                decoration: BoxDecoration(
                    color: Color(0xffececec),
                    borderRadius: BorderRadius.all(Radius.circular(11))                ),
                height: 50,
                width: 50,
                child: Center(child: FaIcon(FontAwesomeIcons.apple,color: Colors.black,)),

              ),
            ],
          ),
          SizedBox(height: 60,),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.89,
            child:OutlinedButton(
                style: ElevatedButton.styleFrom(
                  shape: BeveledRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(3))
                  ),
                  //backgroundColor: Color(0xff1f42ba)
                ),
                onPressed: (){
                  //Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> navigative));
                }, child: Text('Sign Up',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w300,color: Colors.grey),)),
          )
        ],
      ),
    );
  }
}

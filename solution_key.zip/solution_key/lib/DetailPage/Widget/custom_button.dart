import 'package:flutter/material.dart';

class CustomIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;

  CustomIconButton({
    required this.icon,
    required this.onPressed,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: 100,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.grey.shade300,
      ),
      child: IconButton(
        icon: Icon(
          icon,
          color:Colors.black,
          size: 30.0,
        ),
        onPressed: onPressed,
      ),
    );
  }
}
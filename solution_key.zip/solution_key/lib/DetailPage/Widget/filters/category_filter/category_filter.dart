// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';
// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

// class Categories extends StatefulWidget {
//   Categories({Key? key}) : super(key: key);

//   @override
//   State<Categories> createState() => _CategoriesState();
// }

// class _CategoriesState extends State<Categories> {
//   TextEditingController searchController = TextEditingController();
//   List<String> availableFilters = ['Doctor', 'Mechanic', 'Lawyer', 'Plumber'];
//   List<String> displayedFilters = [];
//   List<String> selectedFilters = [];
//     bool checkboxValue1=false;
//  bool checkboxValue2=false;

//   bool checkboxValue3=false;

//   bool checkboxValue4=false;

//   bool checkboxValue5=false;
//   bool check=false;


//   @override
//   void initState() {
//     super.initState();
//     displayedFilters = List.from(availableFilters);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: EdgeInsets.symmetric(horizontal: 5),
//       child: Column(
//         children: [
//           Container(
//             decoration: BoxDecoration(
//               border: Border.all(),
//               borderRadius: BorderRadius.circular(10)
//             ),
//             child: Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 10),
//               child: TextField(
//                 controller: searchController,
//                 // onTap: (){
//                 //   setState(() {
                   
//                 //   });
//                 // },
//                 onChanged: (query) {
//                   setState(() {
//                     displayedFilters.clear();
//                     displayedFilters = availableFilters
//                         .where((filter) =>
//                             filter.contains(query))
//                         .toList();
//                         checkboxValue1=false;
//                         checkboxValue2=false;
//                         checkboxValue3=false;
//                         checkboxValue4=false;

//                   });
//                 },
//                 decoration: InputDecoration(
//                        hintText: "Search",
//                        border: InputBorder.none
              
//                 ),
//               ),
//             ),
//           ),
//             // displayedFilters.isEmpty?Padding(
//             //   padding: const EdgeInsets.all(8.0),
//             //   child: Container(),
//             // ): Column(
//             //   children: [
    
//                displayedFilters.length>1? Column(
//                  children: [
//                    CheckboxListTile(
//                           value: checkboxValue1,
//                           onChanged: (bool? value) {
//                             setState(() {
//                               checkboxValue1= value!;
                             
//                               selectedFilters.add(displayedFilters[0]);
//                             });
//                             setState(() {
                              
//                             });
//                           },
//                           title:  Text(
//                             displayedFilters[0],
//                             style:
//                                 GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
//                           ),
//                         ),
//                          const Divider(height: 0),
//                      CheckboxListTile(
//                       value: checkboxValue2,
//                       onChanged: (bool? value) {
//                         setState(() {
//                           checkboxValue2= value!;
                         
//                           selectedFilters.add(displayedFilters[1]);
//                         });
//                       },
//                       title:  Text(
//                         displayedFilters[1],
//                         style:
//                             GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
//                       ),
//                     ),
//                     const Divider(height: 0),
//                      CheckboxListTile(
//                       value: checkboxValue3,
//                       onChanged: (bool? value) {
//                         setState(() {
//                           checkboxValue3= value!;
                         
//                           selectedFilters.add(displayedFilters[2]);
//                         });
//                       },
//                       title:  Text(
//                         displayedFilters[2],
//                         style:
//                             GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
//                       ),
//                     ),
//                     CheckboxListTile(
//                       value: checkboxValue4,
//                       onChanged: (bool? value) {
//                         setState(() {
//                           checkboxValue4= value!;
                         
//                           selectedFilters.add(displayedFilters[2]);
//                         });
//                       },
//                       title:  Text(
//                         displayedFilters[3],
//                         style:
//                             GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
//                       ),
//                     ),
                  
//                     const Divider(height: 0),
//                  ],
//                ):  displayedFilters.length==0?Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Container(),
//                     ):CheckboxListTile(
//                       value: check,
//                       onChanged: (bool? value) {
//                         setState(() {
//                           check= value!;
                         
//                           selectedFilters.add(displayedFilters[0]);
//                         });
//                       },
//                       title:  Text(
//                         displayedFilters[0],
//                         style:
//                             GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
//                       ),
//                     ),
                   
//             //   ],
//             // ),
           
          
//           // ListView.builder(
//           //   itemCount: displayedFilters.length,
//           //   itemBuilder: (context, index) {
//           //     return Container(
//           //       width: 100,
//           //       child: CheckboxListTile(
//           //         value: selectedFilters.contains(availableFilters[index]),
//           //         onChanged: (bool? value) {
//           //           setState(() {
//           //             if (value != null) {
//           //               if (value) {
//           //                 selectedFilters.add(availableFilters[index]);
//           //               } else {
//           //                 selectedFilters.remove(availableFilters[index]);
//           //               }
//           //             }
//           //           });
//           //         },
//           //         title: Text(
//           //           displayedFilters[index],
//           //           style: GoogleFonts.poppins(
//           //             fontWeight: FontWeight.w400,
//           //             color: Colors.black,
//           //           ),
//           //         ),
//           //       ),
//           //     );
//           //   },
//           // ),

//           const Divider(height: 0),
//           SizedBox(
//             height: 280,
//           ),
//           Padding(
//             padding: const EdgeInsets.only(bottom: 10),
//             child: ElevatedButton(
//               onPressed: () {
//                 // Apply Filters
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => FilterByCatergory(
//                       selectedFilters: selectedFilters,
//                     ),
//                   ),
                 
//                 );
//                 setState(() {
                  
//                 });
                
//               },
//               child: Text('Apply'),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }


// // class Categories extends StatefulWidget {
// //    Categories({super.key});

// //   @override
// //   State<Categories> createState() => _CategoriesState();
// // }

// // class _CategoriesState extends State<Categories> {
// //   bool checkboxValue1=false;

// //   bool checkboxValue2=false;

// //   bool checkboxValue3=false;

// //   bool checkboxValue4=false;

// //   bool checkboxValue5=false;
// //   List<String> selectedFilters=[];
// //   TextEditingController _search=TextEditingController();
// //   bool isMatch(String search)
// //   { 
// //     List<UserModel> Users=UserModel.user;
// //     String val=search.toLowerCase();
// //     if(Users.contains(val))
// //     selectedFilters.add(val);
// //     return true;
// //     return false;
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     return Padding(padding:EdgeInsets.all(8),
// //     child: Column(
// //       children: [
// //         Container(
// //           decoration: BoxDecoration(
// //             border: Border.all(),
// //             borderRadius: BorderRadius.circular(10)
// //           ),
// //           child: Padding(
// //             padding: const EdgeInsets.symmetric(horizontal: 10),
// //             child: TextFormField(
// //               controller: _search,
// //              decoration: InputDecoration(
// //               border: InputBorder.none,
// //               hintText: "Search"
// //              ),
            
// //              onChanged: (value){
// //                 Navigator.push(
// //                     context,
// //                     MaterialPageRoute(
// //                       builder: (context) => FilterByCatergory(selectedFilters: selectedFilters,),
// //                     ),
// //                   );
// //              },
// //             ),
// //           ),
// //         ),
// //          CheckboxListTile(
// //               value: checkboxValue1,
// //               onChanged: (bool? value) {
// //                 setState(() {
// //                   checkboxValue1 = value!;
// //                 });
// //               },
// //               title:  Text(
// //                 'Doctor',
// //                 style:
// //                     GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
// //               ),
// //             ),
// //             const Divider(height: 0),
// //                CheckboxListTile(
// //               value: checkboxValue2,
// //               onChanged: (bool? value) {
// //                 setState(() {
// //                   checkboxValue2 = value!;
// //                 });
// //               },
// //               title:  Text(
// //                 'Mechanic',
// //                 style:
// //                     GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
// //               ),
// //             ),
// //             const Divider(height: 0),
// //              CheckboxListTile(
// //               value: checkboxValue3,
// //               onChanged: (bool? value) {
// //                 setState(() {
// //                   checkboxValue3 = value!;
// //                 });
// //               },
// //               title: Text(
// //                 'Lawyer',
// //                 style:
// //                     GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
// //               ),
// //             ),
// //             const Divider(height: 0),
// //                CheckboxListTile(
// //               value: checkboxValue4,
// //               onChanged: (bool? value) {
// //                 setState(() {
// //                   checkboxValue4 = value!;
// //                 });
// //               },
// //               title:  Text(
// //                 'Mechanic',
// //                 style:
// //                     GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
// //               ),
// //             ),
// //             const Divider(height: 0),
// //              CheckboxListTile(
// //               value: checkboxValue5,
// //               onChanged: (bool? value) {
// //                 setState(() {
// //                   checkboxValue5 = value!;
// //                 });
// //               },
// //               title:  Text(
// //                 'Plumber',
// //                 style:
// //                     GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
// //               ),
// //             ),
           
// //             const Divider(height: 0),
// //             SizedBox(
// //               height: 280,
// //             ),
// //              Padding(
// //                padding: const EdgeInsets.only(bottom: 10),
// //                child: ElevatedButton(
// //                 onPressed: () {
// //                   // Apply Filters
// //                    selectedFilters.clear();
// //                   if (checkboxValue1) selectedFilters.add('Doctor');
// //                   if (checkboxValue2) selectedFilters.add('Mechanic');
// //                   if (checkboxValue3) selectedFilters.add('Lawyer');
// //                   if (checkboxValue4) selectedFilters.add('Mechanic');
// //                   if (checkboxValue5) selectedFilters.add('Plumber');
               
// //                   // Navigate to another screen with filters
// //                   Navigator.push(
// //                     context,
// //                     MaterialPageRoute(
// //                       builder: (context) => FilterByCatergory(selectedFilters: selectedFilters,),
// //                     ),
// //                   );
// //                 },
// //                 child: Text('Apply'),
// //                            ),
// //              ),

// //       ],
// //     ),
// //     );
// //   }
// // }


// class FilterByCatergory extends StatefulWidget {
//   FilterByCatergory({Key? key,required this.selectedFilters}) : super(key: key);
  
//   final List<String> selectedFilters;

//   @override
//   State<FilterByCatergory> createState() => _FilterByCatergoryState();
// }

// class _FilterByCatergoryState extends State<FilterByCatergory> {
//   List<UserModel> Users=UserModel.user;
//   @override
//   Widget build(BuildContext context) {
//    List<UserModel> filteredUsers = Users
//         .where((user) => widget.selectedFilters.contains(user.category))
//         .toList();
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Filtered Screen'),
//       ),
//       body: Container(
//         height: MediaQuery.of(context).size.height,
//         width: MediaQuery.of(context).size.width,
//         child: ListView.builder(
//           itemCount: filteredUsers.length,
//           itemBuilder: (context, int index) {
//             return UserCard(user: filteredUsers[index]);
//           },
//         ),
//       ),
//     );

    
//   }
// }
// // 

import 'package:flutter/material.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class CategoryFilter extends StatefulWidget {
  const CategoryFilter({Key? key});

  @override
  State<CategoryFilter> createState() => _CategoryFilterState();
}

class _CategoryFilterState extends State<CategoryFilter> {
  List<String> categories = ['Doctor', 'Mechanic', 'Lawyer', 'Plumber'];
  List<bool> checkboxValues = [];
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    checkboxValues = List<bool>.filled(categories.length, false);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: MediaQuery.of(context).size.width*0.45,
                decoration: BoxDecoration(
                  border: Border.all(),
                  borderRadius: BorderRadius.circular(10)
                ),
                child: TextField(
                  controller: searchController,
                  
                  onChanged: (query) {
                    setState(() {
                      // Filter categories based on the search query
                      categories = ['Doctor', 'Mechanic', 'Lawyer', 'Plumber']
                          .where((category) =>
                              category.toLowerCase().contains(query.toLowerCase()))
                          .toList();
                      // Reset checkbox values
                      checkboxValues = List<bool>.filled(categories.length, false);
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Search',
                    prefixIcon: Icon(Icons.search),
                    border: InputBorder.none
              
                  ),
                ),
              ),
               TextButton(
            onPressed: () {
              List<String> selectedCategories = getSelectedCategories();
              // Perform actions with selected categories
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FilteredScreen(selectedFilters: selectedCategories),
                ),
              );
              // For example, navigate to a filtered screen
            },
            child: Text('Apply'),
          ),
            ],
          ),
          for (int i = 0; i < categories.length; i++)
            CheckboxListTile(
              value: checkboxValues[i],
              onChanged: (bool? value) {
                setState(() {
                  checkboxValues[i] = value!;
                });
              },
              title: Text(categories[i]),
            ),
          SizedBox(
            height: 340,
          ),
          // ElevatedButton(
          //   onPressed: () {
          //     List<String> selectedCategories = getSelectedCategories();
          //     // Perform actions with selected categories
          //     Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //         builder: (context) => FilteredScreen(selectedFilters: selectedCategories),
          //       ),
          //     );
          //     // For example, navigate to a filtered screen
          //   },
          //   child: Text('Apply'),
          // ),
        ],
      ),
    );
  }

  List<String> getSelectedCategories() {
    List<String> selectedCategories = [];
    for (int i = 0; i < categories.length; i++) {
      if (checkboxValues[i]) {
        selectedCategories.add(categories[i]);
      }
    }
    return selectedCategories;
  }
}

class FilteredScreen extends StatefulWidget {
  final List<String> selectedFilters;

  FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
  List<UserModel> users = UserModel.user;

  @override
  Widget build(BuildContext context) {
    List<UserModel> filteredUsers = users
        .where((user) => widget.selectedFilters.contains(user.category))
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );
  }
}
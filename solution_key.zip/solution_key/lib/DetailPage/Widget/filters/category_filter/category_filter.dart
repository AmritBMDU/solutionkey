import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class Categories extends StatefulWidget {
   Categories({super.key});

  @override
  State<Categories> createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  bool checkboxValue1=false;

  bool checkboxValue2=false;

  bool checkboxValue3=false;

  bool checkboxValue4=false;

  bool checkboxValue5=false;
  List<String> selectedFilters=[];

  @override
  Widget build(BuildContext context) {
    return Padding(padding:EdgeInsets.all(8),
    child: Column(
      children: [
         CheckboxListTile(
              value: checkboxValue1,
              onChanged: (bool? value) {
                setState(() {
                  checkboxValue1 = value!;
                });
              },
              title:  Text(
                'Doctor',
                style:
                    GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
              ),
            ),
            const Divider(height: 0),
               CheckboxListTile(
              value: checkboxValue2,
              onChanged: (bool? value) {
                setState(() {
                  checkboxValue2 = value!;
                });
              },
              title:  Text(
                'Mechanic',
                style:
                    GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
              ),
            ),
            const Divider(height: 0),
             CheckboxListTile(
              value: checkboxValue3,
              onChanged: (bool? value) {
                setState(() {
                  checkboxValue3 = value!;
                });
              },
              title: Text(
                'Lawyer',
                style:
                    GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
              ),
            ),
            const Divider(height: 0),
               CheckboxListTile(
              value: checkboxValue4,
              onChanged: (bool? value) {
                setState(() {
                  checkboxValue4 = value!;
                });
              },
              title:  Text(
                'Mechanic',
                style:
                    GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
              ),
            ),
            const Divider(height: 0),
             CheckboxListTile(
              value: checkboxValue5,
              onChanged: (bool? value) {
                setState(() {
                  checkboxValue5 = value!;
                });
              },
              title:  Text(
                'Plumber',
                style:
                    GoogleFonts.poppins(fontWeight: FontWeight.w400, color: Colors.black),
              ),
            ),
           
            const Divider(height: 0),
            SizedBox(
              height: 280,
            ),
             Padding(
               padding: const EdgeInsets.only(bottom: 10),
               child: ElevatedButton(
                onPressed: () {
                  // Apply Filters
                   selectedFilters.clear();
                  if (checkboxValue1) selectedFilters.add('Doctor');
                  if (checkboxValue2) selectedFilters.add('Mechanic');
                  if (checkboxValue3) selectedFilters.add('Lawyer');
                  if (checkboxValue4) selectedFilters.add('Mechanic');
                  if (checkboxValue5) selectedFilters.add('Plumber');
               
                  // Navigate to another screen with filters
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FilterByCatergory(selectedFilters: selectedFilters,),
                    ),
                  );
                },
                child: Text('Apply'),
                           ),
             ),

      ],
    ),
    );
  }
}


class FilterByCatergory extends StatefulWidget {
  FilterByCatergory({Key? key,required this.selectedFilters}) : super(key: key);
  
  final List<String> selectedFilters;

  @override
  State<FilterByCatergory> createState() => _FilterByCatergoryState();
}

class _FilterByCatergoryState extends State<FilterByCatergory> {
  List<UserModel> Users=UserModel.user;
  @override
  Widget build(BuildContext context) {
   List<UserModel> filteredUsers = Users
        .where((user) => widget.selectedFilters.contains(user.category))
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );

    
  }
}
// }
// class UserCard extends StatelessWidget {
//   final UserModel user;

//   UserCard({required this.user});

//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       elevation: 5,
//       margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
//       child: ListTile(
//         leading: CircleAvatar(
//           radius: 30,
//           backgroundImage: AssetImage('assets/img_2.png'), // Replace with the actual image path
//         ),
//         title: Text(user.name ?? ''),
//         subtitle: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Category: ${user.category ?? ''}'),
//             Text('Location: ${user.location ?? ''}'),
//             Text('Languages: ${user.languages?.join(', ') ?? ''}'),
//             Text('Subcategory: ${user.subCategory ?? ''}'),
//             Text('Rating: ${user.experience ?? ''}'),
//           ],
//         ),
//         trailing: Icon(Icons.arrow_forward_ios),
//         onTap: () {
//           // Implement any action when the user taps on the card
//         },
//       ),
//     );
//   }
// }

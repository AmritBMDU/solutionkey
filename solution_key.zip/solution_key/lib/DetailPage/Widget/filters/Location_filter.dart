import 'dart:core';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class LocationFilter extends StatefulWidget {
  const LocationFilter({super.key});

  @override
  State<LocationFilter> createState() => _LocationFilterState();
}

class _LocationFilterState extends State<LocationFilter> {
  // Map<String, List<String>> categorySubcategories = {
  //   'Doctor': ['Surgeon', 'Physiotherapist', 'Pediatrician'],
  //   'Mechanic': ['Car Mechanic', 'Truck Mechanic', 'Bike Mechanic'],
    
  // };
 List<String> Locations = [];
  List<bool> checkboxValues = [];

  @override
  void initState() {
    super.initState();
    // subcategories = categorySubcategories[widget.selectedCategory] ?? [];
     Locations=["Delhi","Ghaziabad","Noida","Gurugram"];
    
      checkboxValues = List<bool>.filled(Locations.length, false);
  }

  @override
  Widget build(BuildContext context) {
 
    return 
       Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            children: [
              for (int i = 0; i < Locations.length; i++)
                CheckboxListTile(
                  value: checkboxValues[i],
                  onChanged: (bool? value) {
                    setState(() {
                      checkboxValues[i] = value!;
                    });
                  },
                  title: Text(Locations[i]),
                ),
                SizedBox(
                  height: 340,
                ),
              ElevatedButton(
                onPressed: () {
                 List<String> selectedLocations = getSelectedLocations();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FilteredScreen(selectedFilters: selectedLocations)
                    ),
                  );
                },
                child: Text('Apply'),
              ),
            ],
          ),
        
      
    );
  }

  // List<String> getLocations(String category) {
  //   return categorySubcategories[category] ?? [];
  // }

  List<String> getSelectedLocations() {
    List<String> selectedLocations = [];
    for (int i = 0; i < Locations.length; i++) {
      if (checkboxValues[i]) {
        selectedLocations.add(Locations[i]);
      }
    }
    return selectedLocations;
  }
}

class FilteredScreen extends StatefulWidget {
  final List<String> selectedFilters;

  FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
    List<UserModel> Users=UserModel.user;

  @override
  Widget build(BuildContext context) {
   List<UserModel> filteredUsers = Users
        .where((user) => widget.selectedFilters.contains(user.location))
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body:  Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );

    
  }
}
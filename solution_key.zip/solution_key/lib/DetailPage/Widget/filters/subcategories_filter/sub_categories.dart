// import 'package:flutter/material.dart';
// import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

// // class UserModel {
// //   final String name;
// //   final String category;

// //   UserModel({required this.name, required this.category});
// // }

// class SubcategoriesScreen extends StatefulWidget {
//   final String selectedCategory;

//   SubcategoriesScreen({Key? key, required this.selectedCategory}) : super(key: key);

//   @override
//   _SubcategoriesScreenState createState() => _SubcategoriesScreenState();
// }

// class _SubcategoriesScreenState extends State<SubcategoriesScreen> {
//   // Map<String, List<String>> categorySubcategories = {
//   //   'Doctor': ['Surgeon', 'Physiotherapist', 'Pediatrician'],
//   //   'Mechanic': ['Car Mechanic', 'Truck Mechanic', 'Bike Mechanic'],
    
//   // };

//   List<String> subcategories = [];
//   List<bool> checkboxValues = [];

//   @override
//   void initState() {
//     super.initState();
//     subcategories = [ 'overThinking', 'Anxity','Lonelliness', 'Sexual Wellness', 'Family&\n Relationship','Depression','Emotional\nwellness','Career\nCounselling','Loss of\n productivity','Women\nHealth','Sleep','Grief/Loss'];
//     checkboxValues = List<bool>.filled(subcategories.length, false);
//     subcategories.clear();
//   }

//   @override
//   Widget build(BuildContext context) {
//     List<String> selectedSubcategories=[];
//     return Expanded(
//       child: GridView.count(crossAxisCount: 2,
//       crossAxisSpacing: 8,
//       mainAxisSpacing: 10,
//       children: List.generate(10, (index){
//         return categoryCard("assets/overthinking.png",subcategories[index],() => {selectedSubcategories.add(subcategories[index]),print(selectedSubcategories[index]),
//         Navigator.push(context, MaterialPageRoute(builder:(context)=>FilteredScreen(selectedFilters: selectedSubcategories),
      
//         ),
        
        
//         ),
      
//         },);
//       }),
//       ),
      
//     );
//     // return  Padding(
//     //     padding: EdgeInsets.all(8),
//     //     child: Column(
//     //       children: [
//     //         categoryCard(() => {
//     //           selectedSubcategories.add(subcategories[0])
//     //         }),
//     //         // for (int i = 0; i < subcategories.length; i++)
//     //         //   CheckboxListTile(
//     //         //     value: checkboxValues[i],
//     //         //     onChanged: (bool? value) {
//     //         //       setState(() {
//     //         //         checkboxValues[i] = value!;
//     //         //       });
//     //         //     },
//     //         //     title: Text(subcategories[i]),
//     //         //   ),
//     //           SizedBox(
//     //             height: 200,
//     //           ),
//     //         ElevatedButton(
//     //           onPressed: () {
//     //            // List<String> selectedSubcategories = getSelectedSubcategories();
//     //             Navigator.push(
//     //               context,
//     //               MaterialPageRoute(
//     //                 builder: (context) => FilteredScreen(
//     //                   selectedFilters: [widget.selectedCategory, ...selectedSubcategories],
//     //                 ),
//     //               ),
//     //             );
//     //           },
//     //           child: Text('Apply'),
//     //         ),
//     //       ],
//     //     ),
      
//     // );
//   }

//   // List<String> getSubcategories(String category) {
//   //   return categorySubcategories[category] ?? [];
//   // }

//   // List<String> getSelectedSubcategories() {
//   //   List<String> selectedSubcategories = [];
//   //   for (int i = 0; i < subcategories.length; i++) {
//   //     if (checkboxValues[i]) {
//   //       selectedSubcategories.add(subcategories[i]);
//   //     }
//   //   }
//   //   return selectedSubcategories;
//   // }
// }

// class FilteredScreen extends StatefulWidget {
//   final List<String> selectedFilters;

//   FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

//   @override
//   State<FilteredScreen> createState() => _FilteredScreenState();
// }

// class _FilteredScreenState extends State<FilteredScreen> {
//     List<UserModel> Users=UserModel.user;

//   @override
//   Widget build(BuildContext context) {
//    List<UserModel> filteredUsers = Users
//         .where((user) => widget.selectedFilters.contains(user.subCategory))
//         .toList();
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Filtered Screen'),
//       ),
//       body: Container(
//         height: MediaQuery.of(context).size.height,
//         width: MediaQuery.of(context).size.width,
//         child: ListView.builder(
//           itemCount: filteredUsers.length,
//           itemBuilder: (context, int index) {
//             return UserCard(user: filteredUsers[index]);
//           },
//         ),
//       ),
//     );

    
//   }
// }
// // void main() {
// //   runApp(MaterialApp(
// //     home: SubcategoriesScreen(selectedCategory: 'Doctor'),
// //   ));
// // }


// Widget categoryCard(
//   String imgurl,String text,
//   Function() onTap,){
//   return InkWell(
//     onTap: onTap,
//     child: Container(

//       decoration: BoxDecoration(
//         color: const Color.fromARGB(255, 191, 220, 243),
//         border: Border.all(color: const Color.fromARGB(255, 151, 186, 246)),
//         borderRadius: BorderRadius.circular(10),
        
//       ),
      
      
//       height: 80,
//       width: 80,
//       child: Column(children: [
//         Container(
//           height: 50,
//           width: 50,
//           child: Image.asset(imgurl)),
//         Text(text)
//       ],),
//     ),
//   );
// }


import 'package:flutter/material.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class SubcategoriesScreen extends StatefulWidget {
  final String selectedCategory;

  SubcategoriesScreen({Key? key, required this.selectedCategory}) : super(key: key);

  @override
  _SubcategoriesScreenState createState() => _SubcategoriesScreenState();
}

class _SubcategoriesScreenState extends State<SubcategoriesScreen> {
  List<String> subcategories = [
    'overThinking', 'Anxiety', 'Loneliness', 'Sexual Wellness', 'Family  &\n Relationship',
    'Depression', 'Emotional\nwellness', 'Career\nCounselling', 'Loss of\n productivity',
    'Women\nHealth', 'Sleep', 'Grief/Loss'
  ];

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 18,
        mainAxisSpacing: 35,
        children: List.generate(subcategories.length, (index) {
          return categoryCard(
            "assets/overthinking.png",
            subcategories[index].toUpperCase(),
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FilteredScreen(selectedFilters: [subcategories[index]]),
                  
                ),
              );
              print(subcategories[index]);
            },
          );
        }),
      ),
    );
  }
}

class FilteredScreen extends StatefulWidget {
  final List<String> selectedFilters;

  FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
  // Assuming UserModel is defined somewhere
  // List<UserModel> users = UserModel.user;

  List<UserModel> Users=UserModel.user;
  @override
  Widget build(BuildContext context) {
   List<UserModel> filteredUsers = Users
        .where((user) => widget.selectedFilters.contains(user.subCategory))
        .toList();
        print(filteredUsers);
        print(widget.selectedFilters);
        print(UserModel.user[0].subCategory);
       // print()
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );

    
  }
}

Widget categoryCard(String imgurl, String text, Function() onTap) {
  return InkWell(
    onTap: onTap,
    child: Container(
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 191, 220, 243),
        border: Border.all(color: const Color.fromARGB(255, 151, 186, 246)),
        borderRadius: BorderRadius.circular(10),
      ),
      height: 70,
      width: 60,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            height: 40,
            width: 50,
            child: Image.asset(imgurl),
          ),
          Text(text),
        ],
      ),
    ),
  );
}

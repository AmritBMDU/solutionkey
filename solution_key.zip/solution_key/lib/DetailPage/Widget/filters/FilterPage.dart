import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/DetailPage/Widget/filters/Gender_filters/gender_filter.dart';
import 'package:solution_key/DetailPage/Widget/filters/Language_filter/language_filter.dart';
import 'package:solution_key/DetailPage/Widget/filters/Location_filter.dart';
import 'package:solution_key/DetailPage/Widget/filters/appointment_filters.dart';
import 'package:solution_key/DetailPage/Widget/filters/availablity_filter.dart';
import 'package:solution_key/DetailPage/Widget/filters/category_filter/category_filter.dart';
import 'package:solution_key/DetailPage/Widget/filters/experience_filter/experience.dart';
import 'package:solution_key/DetailPage/Widget/filters/price_filters.dart';
import 'package:solution_key/DetailPage/Widget/filters/rating_filters/rating_filters.dart';
import 'package:solution_key/DetailPage/Widget/filters/subcategories_filter/sub_categories.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/drawer/User_Profile.dart';
import 'package:solution_key/HomeScreen/BottomTabBarScreen/multipleHomeScreen/HomePage.dart';
import 'package:solution_key/HomeScreen/mainScreen.dart';
import 'package:solution_key/appcolor.dart';

class FilterPage extends StatefulWidget {
  const FilterPage({super.key});

  @override
  State<FilterPage> createState() => _FilterPage();
}

class _FilterPage extends State<FilterPage> {
  var selectedTab = '10';
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back,
            color: appcolor.appcolors,
          ),
        ),
        title: Text(
          'Filter',
          style:
              TextStyle(fontWeight: FontWeight.w500, color: appcolor.appcolors),
        ),
      ),
      resizeToAvoidBottomInset: false,
      // endDrawer: Drawers(context),
      body: Row(
        children: [
          Container(
            height: size.height,
            width: size.width * 0.32,
            color: Colors.grey[200],
            child: Column(
              children: [
                  TextButton(
                  onPressed: () {
            
                    setState(() {
                      selectedTab = '10';
                    });
                  },
                  child: Text(
                    'Appointments',
                    style: TextStyle(
                        fontWeight: FontWeight.w500, color: Colors.black),
                  ),
                ),
                TextButton(
                  onPressed: () {
            
                    setState(() {
                      selectedTab = '1';
                    });
                  },
                  child: Text(
                    'Category',
                    style: TextStyle(
                        fontWeight: FontWeight.w500, color: Colors.black),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      selectedTab = '2';
                    });
                  },
                  child: Text(
                    'SubCategory',
                    style: TextStyle(
                        fontWeight: FontWeight.w500, color: Colors.black),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      selectedTab = '3';
                    });
                  },
                  child: Text(
                    'Location',
                    style: TextStyle(
                        fontWeight: FontWeight.w500, color: Colors.black),
                  ),
                ),
                   TextButton(
            onPressed: () {
              setState(() {
                selectedTab = '8';
              });
            },
            child: Text(
              'Prices',
              style:
                  TextStyle(fontWeight: FontWeight.w500, color: Colors.black),
            ),
                      ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      selectedTab = '4';
                    });
                  },
                  child: Text(
                    'Language',
                    style: TextStyle(
                        fontWeight: FontWeight.w500, color: Colors.black),
                  ),
                ),
                   TextButton(
            onPressed: () {
              setState(() {
                selectedTab = '5';
              });
            },
            child: Text(
              'Gender',
              style:
                  TextStyle(fontWeight: FontWeight.w500, color: Colors.black),
            ),
                      ),
                       TextButton(
            onPressed: () {
              setState(() {
                selectedTab = '6';
              });
            },
            child: Text(
              'Experience',
              style:
                  TextStyle(fontWeight: FontWeight.w500, color: Colors.black),
            ),
                      ),
                                             TextButton(
            onPressed: () {
              setState(() {
                selectedTab = '7';
              });
            },
            child: Text(
              'Ratings',
              style:
                  TextStyle(fontWeight: FontWeight.w500, color: Colors.black),
            ),
                      ),
            //                  TextButton(
            // onPressed: () {
            //   setState(() {
            //     selectedTab = '8';
            //   });
            // },
            // child: Text(
            //   'Prices',
            //   style:
            //       TextStyle(fontWeight: FontWeight.w500, color: Colors.black),
            // ),
            //           ),
                             TextButton(
            onPressed: () {
              setState(() {
                selectedTab = '9';
              });
            },
            child: Text(
              'Availibility',
              style:
                  TextStyle(fontWeight: FontWeight.w500, color: Colors.black),
            ),
                      ),
                    
                    
                      
              ],
            ),
          ),
        //  SizedBox(width: 2,),
          Container(
            height: size.height,
            width: size.width * 0.675,
            child: Column(
              children: [
                         if(selectedTab == '1') CategoryFilter(),
                         if(selectedTab=='2')SubcategoriesScreen(selectedCategory: "Mechanic",),
                         if(selectedTab=='3')LocationFilter(),
                         if(selectedTab=='4')LangaugeFilter(),
                         if(selectedTab=='5')GenderFilter(),
                         if(selectedTab=='6')RatingFilters(),
                         if(selectedTab=='7')RatingFilter(),
                         if(selectedTab=='8')PriceFilters(),
                         if(selectedTab=='9')AvailabilityFilters(),
                          if(selectedTab=='10')AppointmentFilter()
              ],
            ),
          ),
        ],
      ),

     
    );
  }
}






class UserModel {
  String? name;
  String? location;
  List<String>? languages;
  String? category;
  String? subCategory;
  String? gender;
  double? experience;
  String? img;
  double? rating;
  String? priceRange;
  String? availability;
  String? appointments;

  UserModel({
    required this.category,
    required this.name,
    required this.location,
    required this.gender,
    required this.languages,
    required this.subCategory,
    this.experience,
    this.img,
    this.rating,
   this.priceRange,
    this.availability,
    this.appointments,

  });

  static List<UserModel> user = [
    UserModel(
      category: "Doctor",
      name: "Nisha",
      location: "Ghaziabad",
      gender: "Female",
      languages: ["Hindi", "English"],
      subCategory: "overThinking",
      experience: 10,
      img: "assets/",
      rating: 4,
      availability: "Available",
      appointments: "Both"
    ),
    UserModel(
      category: "Doctor",
      name: "Saurabh",
      location: "Noida",
      gender: "Male",
      languages: ["Hindi", "English"],
      subCategory: "Anxiety",
      experience: 8,
      rating: 5,
      priceRange: "Below 50",
      availability: "Available",
      appointments: "Online"
    ),
    UserModel(
      category: "Plumber",
      name: "Deepak Kumar",
      location: "Delhi",
      gender: "Male",
      languages: ["Hindi", "English", "Urdu"],
      subCategory: "Experienced",
      experience: 6,
      rating: 4.5,
      priceRange: "Below 50",
        availability: "Available",
      appointments: "Both"
    ),
    UserModel(
      category: "Doctor",
      name: "Roshan Singh",
      location: "Ghaziabad",
      gender: "Male",
      languages: ["Hindi", "English"],
      subCategory: 'Family&\n Relationship',
      experience: 7,
      rating: 4.7,
      priceRange: "60-70",
         availability: "Available",
      appointments: "Online"
    ),
    UserModel(
      category: "Mechanic",
      name: "Jitesh",
      location: "Noida",
      gender: "Male",
      languages: ["Hindi"],
      subCategory: "Bike Mechanic",
      experience: 5,
      rating: 4.3,
      priceRange: "60-70",
       availability: "Available",
      appointments: "Physical"
    ),
    UserModel(
      category: "Carpenter",
      name: "Priyanshu",
      location: "Ghaziabad",
      gender: "Male",
      languages: ["Punjabi"],
      subCategory: "Experienced",
      experience: 5,
      rating: 4.2,
      availability: "Available",
      appointments: "Physical"
    ),
    UserModel(
      category: "Lawyer",
      name: "Sanjeev",
      location: "Ghaziabad",
      gender: "Male",
      languages: ["Hindi", "English", "Punjabi"],
      subCategory: "Criminal Lawyer",
      experience: 4,
      rating: 4,
        availability: "Not Available",
      priceRange: "50-60",
      appointments: "Online"

    ),
    UserModel(
      category: "Lawyer",
      name: "Nisha",
      location: "Delhi",
      gender: "Female",
      languages: ["Hindi", "English"],
      subCategory: "High Court lawyer",
      experience: 10,
      rating: 4.1,
      priceRange: "60-70",
      availability: "Available",
      appointments: "Physical"

    ),
    // Add more data as needed
  ];
}



// class UserCard extends StatelessWidget {
//   final UserModel user;

//   UserCard({required this.user});

//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       elevation: 5,
//       margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
//       child: ListTile(
//         leading: CircleAvatar(
//           radius: 30,
//           backgroundImage: AssetImage('assets/img_2.png'), // Replace with the actual image path
//         ),
//         title: Text(user.name ?? ''),
//         subtitle: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Category: ${user.category ?? ''}'),
//             Text('Location: ${user.location ?? ''}'),
//             Text('Languages: ${user.languages?.join(', ') ?? ''}'),
//             Text('Subcategory: ${user.subCategory ?? ''}'),
//             Text('Experience: ${user.experience ?? ''} years'),
//           ],
//         ),
//         trailing: Icon(Icons.arrow_forward_ios),
//         onTap: () {
//           // Implement any action when the user taps on the card
//         },
//       ),
//     );
//   }
// }



// class UserCard extends StatelessWidget {
//   final UserModel user;

//   UserCard({required this.user});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(15),
//         color: Colors.white,
//         boxShadow: [
//           BoxShadow(
//             color: Colors.grey.withOpacity(0.5),
//             spreadRadius: 2,
//             blurRadius: 5,
//             offset: Offset(0, 3),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               CircleAvatar(
//                 radius: 40,
//                 backgroundImage: AssetImage("assets/img_1.png"),
//               ),
//               SizedBox(width: 10),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     user.name ?? '',
//                     style: GoogleFonts.poppins(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 18,
//                     ),
//                   ),
                
//                     Row(
//                       children: [
//                         Icon(
//                           Icons.verified,
//                           color: Colors.blue,
//                           size: 16,
//                         ),
//                         Text(
//                           'Verified',
//                           style: TextStyle(
//                             color: Colors.blue,
//                             fontSize: 12,
//                           ),
//                         ),
//                       ],
//                     ),
//                 ],
//               ),
//               Spacer(),
//           //     Row(
//           //       children: [
//           //         Icon(
//           //           Icons.star,
//           //           color: Colors.yellow,
//           //         ),
//           //         Text(
//           //           '${user.rating}',
//           //           style: GoogleFonts.poppins(
//           //             fontWeight: FontWeight.bold,
//           //           ),
//           //         ),
//           //       ],
//           //     ),
//           //   ],
//           // ),
//           Text(
//             "with 30 years of proffessional lineage as a second-generation laweyer at delhi high court, bombay high court,karnataka high court,",
//             maxLines: 3,
//             overflow: TextOverflow.ellipsis,
//             style: GoogleFonts.poppins(),
//           ),
//           SizedBox(height: 10),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   primary: Colors.deepPurpleAccent,
//                 ),
//                 onPressed: () {
//                   // Implement the onAudioCall action
//                 },
//                 child: Icon(
//                   Icons.call,
//                   size: 35,
//                 ),
//               ),
//               SizedBox(width: 30),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   primary: Colors.green,
//                 ),
//                 onPressed: () {
//                   // Implement the onVideoCall action
//                 },
//                 child: Icon(
//                   Icons.video_call,
//                   size: 35,
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//         ]
//     ));
//   }
// }



class UserCard extends StatelessWidget {
  final UserModel user;

  UserCard({required this.user});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(builder:(context)=>MainPage()));
      },
      child: Container(
        padding: EdgeInsets.all(16),
        margin: EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage: AssetImage("assets/img_2.png"),
            ),
            SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user.name ?? '',
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                        
                            Row(
                              children: [
                                Text(user.category!,  style: GoogleFonts.poppins(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),),
                            SizedBox(width: 10,),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.verified,
                                      color: Colors.blue,
                                      size: 16,
                                    ),
                                    Text(
                                      'Verified',
                                      style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: 10,),
                             Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: Colors.deepPurpleAccent,
                        ),
                        onPressed: () {
                          // Implement the onAudioCall action
                        },
                        child: Icon(
                          Icons.call,color: Colors.white,
                          size: 20,
                        ),
                      ),
                      SizedBox(width: 10),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: Colors.green,
                        ),
                        onPressed: () {
                          // Implement the onVideoCall action
                        },
                        child: Icon(
                          Icons.video_call,color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                        ],
                      ),
                  //     Row(
                  //       children: [
                  //         Icon(
                  //           Icons.star,
                  //           color: Colors.yellow,
                  //         ),
                  //         Text(
                  //           '${user.rating}',
                  //           style: GoogleFonts.poppins(
                  //             fontWeight: FontWeight.bold,
                  //           ),
                  //         ),
                  //       ],
                  //     ),
                  //   ],
                  // ),
                //  SizedBox(height: 5),
                 
                  // SizedBox(height: 10),
                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //   children: [
                  //     ElevatedButton(
                  //       style: ElevatedButton.styleFrom(
                  //         primary: Colors.deepPurpleAccent,
                  //       ),
                  //       onPressed: () {
                  //         // Implement the onAudioCall action
                  //       },
                  //       child: Icon(
                  //         Icons.call,
                  //         size: 20,
                  //       ),
                  //     ),
                  //     SizedBox(width: 10),
                  //     ElevatedButton(
                  //       style: ElevatedButton.styleFrom(
                  //         primary: Colors.green,
                  //       ),
                  //       onPressed: () {
                  //         // Implement the onVideoCall action
                  //       },
                  //       child: Icon(
                  //         Icons.video_call,
                  //         size: 20,
                  //       ),
                  //     ),
                  //   ],
                  // ),
                ],
              ),
          ]),
        )],
        ),
      ),
    );
  }
}

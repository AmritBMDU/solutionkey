import 'package:flutter/material.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class AvailabilityFilters extends StatefulWidget {
  const AvailabilityFilters({super.key});

  @override
  State<AvailabilityFilters> createState() => _AvailabilityFiltersState();
}

class _AvailabilityFiltersState extends State<AvailabilityFilters> {
  List<String> availabilityOptions = ["Available", "Not Available"];
  List<bool> checkboxValues = [];

  @override
  void initState() {
    super.initState();
    checkboxValues = List<bool>.filled(availabilityOptions.length, false);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.end,
        children: [
           TextButton(
            onPressed: () {
              List<String> selectedAvailabilityOptions = getSelectedAvailabilityOptions();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FilteredScreen(selectedFilters: selectedAvailabilityOptions),
                ),
              );
            },
            child: Text('Apply'),
                     ),
          for (int i = 0; i < availabilityOptions.length; i++)
            CheckboxListTile(
              value: checkboxValues[i],
              onChanged: (bool? value) {
                setState(() {
                  checkboxValues[i] = value!;
                });
              },
              title: Text(availabilityOptions[i]),
            ),
          SizedBox(
            height: 270,
          ),
          // ElevatedButton(
          //   onPressed: () {
          //     List<String> selectedAvailabilityOptions = getSelectedAvailabilityOptions();
          //     Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //         builder: (context) => FilteredScreen(selectedFilters: selectedAvailabilityOptions),
          //       ),
          //     );
          //   },
          //   child: Text('Apply'),
          // ),
        ],
      ),
    );
  }

  List<String> getSelectedAvailabilityOptions() {
    List<String> selectedAvailabilityOptions = [];
    for (int i = 0; i < availabilityOptions.length; i++) {
      if (checkboxValues[i]) {
        selectedAvailabilityOptions.add(availabilityOptions[i]);
      }
    }
    return selectedAvailabilityOptions;
  }
}

class FilteredScreen extends StatefulWidget {
  final List<String> selectedFilters;

  FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
  List<UserModel> Users = UserModel.user;

  @override
  Widget build(BuildContext context) {
    List<UserModel> filteredUsers = Users
        .where((user) =>
            widget.selectedFilters.contains(user.availability))
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class RatingFilters extends StatefulWidget {
  const RatingFilters({super.key});

  @override
  State<RatingFilters> createState() => _RatingFiltersState();
}

class _RatingFiltersState extends State<RatingFilters> {
 List<double> Ratings = [];
  List<bool> checkboxValues = [];

  @override
  void initState() {
    super.initState();
    // subcategories = categorySubcategories[widget.selectedCategory] ?? [];
     Ratings=[0,5,10,15,20];
    
      checkboxValues = List<bool>.filled(Ratings.length, false);
  }

  @override
  Widget build(BuildContext context) {
 
    return  
       Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
                TextButton(
                onPressed: () {
                 List<double> selectedRatings = getSelectedRatings();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FilteredScreen(selectedFilters: selectedRatings)
                    ),
                  );
                },
                child: Text('Apply'),
              ),
              for (int i = 0; i < Ratings.length; i++)
                CheckboxListTile(
                  value: checkboxValues[i],
                  onChanged: (bool? value) {
                    setState(() {
                      checkboxValues[i] = value!;
                    });
                  },
                  title: Text("${Ratings[i]} years"),
                ),
                SizedBox(
                  height: 270,
                ),
              // ElevatedButton(
              //   onPressed: () {
              //    List<double> selectedRatings = getSelectedRatings();
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(
              //         builder: (context) => FilteredScreen(selectedFilters: selectedRatings)
              //       ),
              //     );
              //   },
              //   child: Text('Apply'),
              // ),
            ],
          ),
        
      
    );
  }

  // List<String> getLocations(String category) {
  //   return categorySubcategories[category] ?? [];
  // }

  List<double> getSelectedRatings() {
    List<double> selectedLocations = [];
    for (int i = 0; i < Ratings.length; i++) {
      if (checkboxValues[i]) {
        selectedLocations.add(Ratings[i]);
      }
    }
    return selectedLocations;
  }
}

class FilteredScreen extends StatefulWidget {
  final List<double> selectedFilters;

  FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
    List<UserModel> Users=UserModel.user;

  @override
  Widget build(BuildContext context) {
   List<UserModel> filteredUsers = Users
        .where((user) => widget.selectedFilters.contains((user.experience)))
        .toList();
        print(filteredUsers);
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );

    
  }
}
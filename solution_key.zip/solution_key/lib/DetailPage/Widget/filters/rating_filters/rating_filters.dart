import 'package:flutter/material.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class RatingFilter extends StatefulWidget {
  const RatingFilter({Key? key}) : super(key: key);

  @override
  State<RatingFilter> createState() => _RatingFilterState();
}

class _RatingFilterState extends State<RatingFilter> {
  List<int> ratings = [1, 2, 3, 4, 5];
  List<bool> checkboxValues = [];

  @override
  void initState() {
    super.initState();
    checkboxValues = List<bool>.filled(ratings.length, false);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
            TextButton(
            onPressed: () {
              List<int> selectedRatings = getSelectedRatings();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FilteredScreen(
                    selectedFilters: selectedRatings,
                    filterType: 'rating',
                  ),
                ),
              );
            },
            child: Text('Apply'),
          ),
          for (int i = 0; i < ratings.length; i++)
            CheckboxListTile(
              value: checkboxValues[i],
              onChanged: (bool? value) {
                setState(() {
                  checkboxValues[i] = value!;
                });
              },
              title: Row(
                children: [
                 
                  Text('${ratings[i]}'),
                   Icon(Icons.star,color: Colors.yellow,),
                ],
              ),
            ),
          // SizedBox(
          //   height: 340,
          // ),
          // ElevatedButton(
          //   onPressed: () {
          //     List<int> selectedRatings = getSelectedRatings();
          //     Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //         builder: (context) => FilteredScreen(
          //           selectedFilters: selectedRatings,
          //           filterType: 'rating',
          //         ),
          //       ),
          //     );
          //   },
          //   child: Text('Apply'),
          // ),
        ],
      ),
    );
  }

  List<int> getSelectedRatings() {
    List<int> selectedRatings = [];
    for (int i = 0; i < ratings.length; i++) {
      if (checkboxValues[i]) {
        selectedRatings.add(ratings[i]);
      }
    }
    return selectedRatings;
  }
}

class FilteredScreen extends StatefulWidget {
  final List<int> selectedFilters;
  final String filterType;

  FilteredScreen({
    Key? key,
    required this.selectedFilters,
    required this.filterType,
  }) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
  List<UserModel> users = UserModel.user;

  @override
  Widget build(BuildContext context) {
    List<UserModel> filteredUsers = [];

    if (widget.filterType == 'rating') {
      filteredUsers = users
          .where((user) =>
              widget.selectedFilters.contains(user.rating))
          .toList();
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class PriceFilters extends StatefulWidget {
  const PriceFilters({super.key});

  @override
  State<PriceFilters> createState() => _PriceFiltersState();
}

class _PriceFiltersState extends State<PriceFilters> {
  List<String> priceRanges = ["< 50", "51-100", "101-500", "> 500"];
  List<bool> checkboxValues = [];

  @override
  void initState() {
    super.initState();
    checkboxValues = List<bool>.filled(priceRanges.length, false);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Column(
crossAxisAlignment: CrossAxisAlignment.end,
        children: [
           TextButton(
            onPressed: () {
              List<String> selectedPriceRanges = getSelectedPriceRanges();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FilteredScreen(selectedFilters: selectedPriceRanges),
                ),
              );
            },
            child: Text('Apply'),
          ),
          for (int i = 0; i < priceRanges.length; i++)
            CheckboxListTile(
              value: checkboxValues[i],
              onChanged: (bool? value) {
                setState(() {
                  checkboxValues[i] = value!;
                });
              },
              title: Row(
                children: [
                  Text("${priceRanges[i]} "),
                   Text("Rs/min",style: TextStyle(fontSize: 14),),
                ],
              ),
            ),
          SizedBox(
            height: 270,
          ),
        
        ],
      ),
    );
  }

  List<String> getSelectedPriceRanges() {
    List<String> selectedPriceRanges = [];
    for (int i = 0; i < priceRanges.length; i++) {
      if (checkboxValues[i]) {
        selectedPriceRanges.add(priceRanges[i]);
      }
    }
    return selectedPriceRanges;
  }
}

class FilteredScreen extends StatefulWidget {
  final List<String> selectedFilters;

  FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
  List<UserModel> Users = UserModel.user;

  @override
  Widget build(BuildContext context) {
    List<UserModel> filteredUsers = Users
        .where((user) =>
            widget.selectedFilters.contains(user.priceRange))
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );
  }
}

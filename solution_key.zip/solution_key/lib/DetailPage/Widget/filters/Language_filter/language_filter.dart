import 'dart:core';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:solution_key/DetailPage/Widget/filters/FilterPage.dart';

class LangaugeFilter extends StatefulWidget {
  const LangaugeFilter({super.key});

  @override
  State<LangaugeFilter> createState() => _LangaugeFilterState();
}

class _LangaugeFilterState extends State<LangaugeFilter> {
  // Map<String, List<String>> categorySubcategories = {
  //   'Doctor': ['Surgeon', 'Physiotherapist', 'Pediatrician'],
  //   'Mechanic': ['Car Mechanic', 'Truck Mechanic', 'Bike Mechanic'],
    
  // };
 List<String> Languages = [];
  List<bool> checkboxValues = [];

  @override
  void initState() {
    super.initState();
    // subcategories = categorySubcategories[widget.selectedCategory] ?? [];
     Languages=[ 'Hindi',
  'Bengali',
  'Telugu',
  'Marathi',
  'Tamil',
  'Urdu',
  'Gujarati',
  'Malayalam',
  'Kannada',
  'Oriya',
  'Punjabi',
  'Assamese',
  'Maithili',
  'Santali',
  'Kashmiri',
  'Nepali',
  'Konkani',
  'Sindhi',
  'Dogri',
  'Manipuri',
  'Bodo',
  'Sanskrit',];
    
      checkboxValues = List<bool>.filled(Languages.length, false);
  }

  @override
  Widget build(BuildContext context) {
 
    return  Padding(
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
             TextButton(
              onPressed: () {
               List<String> selectedLanguages = getSelectedLanguages();
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FilteredScreen(selectedFilters: selectedLanguages)
                  ),
                );
              },
              child: Text('Apply'),
            ),
            for (int i = 0; i < Languages.length; i++)
              CheckboxListTile(
                value: checkboxValues[i],
                onChanged: (bool? value) {
                  setState(() {
                    checkboxValues[i] = value!;
                  });
                },
                title: Text(Languages[i]),
              ),
              // SizedBox(
              //   height: 240,
              // ),
            // ElevatedButton(
            //   onPressed: () {
            //    List<String> selectedLanguages = getSelectedLanguages();
            //     Navigator.push(
            //       context,
            //       MaterialPageRoute(
            //         builder: (context) => FilteredScreen(selectedFilters: selectedLanguages)
            //       ),
            //     );
            //   },
            //   child: Text('Apply'),
            // ),
          ],
        ),
      
    );
  }

  // List<String> getLocations(String category) {
  //   return categorySubcategories[category] ?? [];
  // }

  List<String> getSelectedLanguages() {
    List<String> selectedLocations = [];
    for (int i = 0; i < Languages.length; i++) {
      if (checkboxValues[i]) {
        selectedLocations.add(Languages[i]);
      }
    }
    return selectedLocations;
  }
}

class FilteredScreen extends StatefulWidget {
  final List<String> selectedFilters;

  FilteredScreen({Key? key, required this.selectedFilters}) : super(key: key);

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
    List<UserModel> Users=UserModel.user;

  @override
  Widget build(BuildContext context) {
   List<UserModel> filteredUsers = Users
        .where((user) => user.languages!.contains(widget.selectedFilters[0]))
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Filtered Screen'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: ListView.builder(
          itemCount: filteredUsers.length,
          itemBuilder: (context, int index) {
            return UserCard(user: filteredUsers[index]);
          },
        ),
      ),
    );

    
  }
}
import 'package:flutter/material.dart';
import 'package:solution_key/appcolor.dart';
import 'package:solution_key/seachPage/SetMetting.dart';

class MyListItems extends StatelessWidget {
  MyListItems({super.key,required this.text,required this.date,required this.time});
  late String text;
  late String date;
  late String time;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              children: [
                Text(text,style:TextStyle(fontSize: 19,color: Colors.grey.shade500),),
                SizedBox(height: 10,),
                Text(date,style: TextStyle(color: Colors.grey.shade500),),
              ],
            ),
            Column(
              children: [
                SizedBox(
                  height: 30,
                  child: ElevatedButton(
                    style:ElevatedButton.styleFrom(
                        backgroundColor: appcolor.appcolors
                    ),
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> SetMeeting()));
                    }, child:  Text('Selected',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 14,color: Colors.white),),),
                ),
                SizedBox(height: 10,),
                Text(time,style: TextStyle(color: Colors.grey.shade500),),
              ],
            ),
          ],
        ),
      ),
    );;
  }
}


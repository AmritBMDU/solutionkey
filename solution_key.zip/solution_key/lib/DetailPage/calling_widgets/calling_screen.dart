
import 'package:flutter/material.dart';
import 'package:solution_key/DetailPage/detail_Screen.dart';

class ViewCall extends StatefulWidget {
 ViewCall({
    super.key,
    required this.name
  });
  String name;

  @override
  State<ViewCall> createState() => _ViewCallState();
}

class _ViewCallState extends State<ViewCall> {
  int selectedPackage = 0;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height*0.85 ,
        width: MediaQuery.of(context).size.width,
        child: Padding(
          padding: const EdgeInsets.all(0.0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                child: Text(
                  "What can you ask me:",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
             Padding(
               padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 10),
               child: Row(
                 children: [
                  Container(height: 5,width: 5,decoration: BoxDecoration(color: Colors.orangeAccent,shape:BoxShape.circle),),
                  SizedBox(width: 10,),
                   Text("How to manage mental health/peace?", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),),
                 ],
               ),
             ),
              Padding(
               padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 10),
               child: Row(
                 children: [
                  Container(height: 5,width: 5,decoration: BoxDecoration(color: Colors.orangeAccent,shape:BoxShape.circle),),
                  SizedBox(width: 10,),
                   Text("How to manage my relationships?", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),),
                 ],
               ),
             ),
              Padding(
               padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 10),
               child: Row(
                 children: [
                  Container(height: 5,width: 5,decoration: BoxDecoration(color: Colors.orangeAccent,shape:BoxShape.circle),),
                  SizedBox(width: 10,),
                   Text("How to understand myself better?", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),),
                 ],
               ),
             ),
            
               Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                child: Text(
                  "Who can reach me out?:",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
                Padding(
               padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 10),
               child: Row(
                 children: [
                  CustomContainer("Students",90),
                  SizedBox(width: 15,),
                  CustomContainer("Young Adults",110),
                  SizedBox(width: 15,),
                 // CustomContainer("Teenagers"),
                 ],
               ),
             ),
               Padding(
               padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 10),
               child: Row(
                 children: [
                  CustomContainer("Working Professions",180),
                  SizedBox(width: 15,),
                  CustomContainer("Teenagers",110),
                  SizedBox(width: 15,),
                 // CustomContainer("Teenagers"),
                 ],
               ),
             ),
               Padding(
               padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 10),
               child: Row(
                 children: [
                  CustomContainer("Job Aspirants",120),
                  SizedBox(width: 10,),
                  CustomContainer("Couples",100),
                  SizedBox(width: 10,),
                  CustomContainer("Parents", 100)
                 // CustomContainer("Teenagers"),
                 ],
               ),
             ),
               Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                child: Text(
                  "What can I help you achieve:",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
             
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    child: CustomChatCard(Icons.heart_broken,"  Managing \n Relationship"),
                  ),
                 Container(height: 100,width: 2,color: Colors.grey.shade400,),
                   Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    child: CustomChatCard(Icons.balance,"  Emotional \n    Stability"),
                  ),
                 Container(height: 100,width: 2,color: Colors.grey.shade400,),
                    Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    child: CustomChatCard(Icons.person,"  Self-Care"),
                  ),
                // Container(height: 100,width: 2,color: Colors.grey.shade400,)
                ],
              ),
             Padding(
               padding: const EdgeInsets.symmetric(vertical: 25),
               child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  CustomChatButton(Icons.calendar_month, "Book", (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>BookChat(name: widget.name,)));
                  },Colors.white,),
                  CustomChatButton(Icons.call, "call", (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatRateScreen(name: widget.name,)));
                  },const Color.fromARGB(255, 74, 142, 197),iconColor: Colors.white,textColor: Colors.white)
                ],
               ),
             )
            ],
          ),
        ),
      ),
    );
  }
}
Widget CustomChatButton(IconData icon,String text,Function()?onTap,Color color,{Color iconColor=Colors.purple,Color textColor=Colors.redAccent}){
  return Container(
    width: 150,
    height: 50,
    child: ElevatedButton(onPressed: onTap, child:Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
        Icon(icon,color: iconColor,),
        Text(text,style: TextStyle(color:textColor,fontWeight: FontWeight.bold,fontSize: 15),),
        
      ],),
    
    ),
    style: ElevatedButton.styleFrom(side: BorderSide(color: Colors.grey),backgroundColor: color,shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
    
    ),
  );
}

Widget CustomContainer(String name,double width){
  return Container(
     height: 40,
     width:width,
     decoration: BoxDecoration(
      color: const Color.fromARGB(255, 255, 175, 64).withOpacity(0.4),
      borderRadius: BorderRadius.circular(15),
     ),
     child: Center(child: Text(name,style: TextStyle(color: Colors.deepOrange,fontWeight: FontWeight.bold,fontSize: 15),)),
  );
}
Widget CustomChatCard(IconData icon,String text){
  return Column(
    children: [
      Icon(icon,color: Colors.red,size: 40,),
      Text(text,style:TextStyle(fontSize: 17),)
    ],
  );
}
class BookChat extends StatefulWidget {
   BookChat({super.key,required this.name});
  String name;

  @override
  State<BookChat> createState() => _BookChatState();
}

class _BookChatState extends State<BookChat> {
  int selectedPackage=0;
  TextEditingController input1=TextEditingController();
   TextEditingController input2=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(top: 80),
        child: Column(
          children: [
           Image.asset("assets/schedule_call.png"),
            Container(
                                width: MediaQuery.of(context).size.width,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20, left: 20),
                                      child: Text(
                                        "Schedule your Call",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 20, top: 10),
                                      child: Text(
                                        "*Date",
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.normal),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 20, top: 10),
                                      child: Container(
                                        height: 50,
                                        width: MediaQuery.of(context).size.width * 0.9,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(10),
                                            border: Border.all(color: Colors.black)),
                                        child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            child: DateTimer()
                                            // child: TextFormField(
                                            //   decoration: InputDecoration(
                                            //     border: InputBorder.none,
                                            //     hintText: "Select Preferred Date",
                                            //   ),
                                            // ),
                                            ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 20, top: 10),
                                      child: Text(
                                        "*Preferred time",
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.normal),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 20, top: 10),
                                      child: Container(
                                        height: 50,
                                        width: MediaQuery.of(context).size.width * 0.9,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(10),
                                            border: Border.all(color: Colors.black)),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: TextFormField(
                                              controller: input1,
                                              decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintText: "Select Preferred time",
                                              ),
                                              readOnly:
                                                  true, //set it true, so that user will not able to edit text
                                              onTap: ()  {
                                                Navigator.push(context, MaterialPageRoute(builder: (context)=>SlotBookingScreen(text1: input1,)));
                                              }
                                              ),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 20, top: 10),
                                      child: Text(
                                        "*Second preferred time",
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.normal),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 20, top: 10),
                                    //  child: SlotBookingScreen(),
                                      child: Container(
                                        height: 50,
                                        width: MediaQuery.of(context).size.width * 0.9,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(10),
                                            border: Border.all(color: Colors.black)),
                                            
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: TextFormField(
                                            controller: input2,
                                            decoration: InputDecoration(
                                              border: InputBorder.none,
                                              hintText:
                                                  "Select a second preferred time",
                                            ),
                                            readOnly: true,
                                            onTap: (){
                                        Navigator.push(context, MaterialPageRoute(builder: (context)=>SlotBookingScreen(text1: input2,)));
                                            },
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    // Padding(
                                    //   padding: const EdgeInsets.only(left: 30),
                                    //   child: Row(
                                    //     children: [
                                    //       Radio(
                                    //           value: 1,
                                    //           groupValue: selectedPackage,
                                    //           onChanged: (value) {
                                    //             setState(() {
                                    //               selectedPackage = value!;
                                    //             });
                                    //           }),
                                    //       Text(
                                    //         "Chat",
                                    //         style: TextStyle(
                                    //             fontSize: 14,
                                    //             fontWeight: FontWeight.normal),
                                    //       ),
                                    //       SizedBox(
                                    //         width: 40,
                                    //       ),
                                    //       Radio(
                                    //           value: 2,
                                    //           groupValue: selectedPackage,
                                    //           onChanged: (value) {
                                    //             setState(() {
                                    //               selectedPackage = value!;
                                    //             });
                                    //           }),
                                    //       Text(
                                    //         "Call",
                                    //         style: TextStyle(
                                    //             fontSize: 14,
                                    //             fontWeight: FontWeight.normal),
                                    //       ),
                                    //       SizedBox(
                                    //         width: 40,
                                    //       ),
                                    //       Radio(
                                    //           value: 3,
                                    //           groupValue: selectedPackage,
                                    //           onChanged: (value) {
                                    //             setState(() {
                                    //               selectedPackage = value!;
                                    //             });
                                    //           }),
                                    //       Text(
                                    //         "Call",
                                    //         style: TextStyle(
                                    //             fontSize: 14,
                                    //             fontWeight: FontWeight.normal),
                                    //       ),
                                    //     ],
                                    //   ),
                                    // ),
                                    // SizedBox(
                                    //   height: 10,
                                    // ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                                      children: [
                                        ElevatedButton(
                                            onPressed: () {},
                                            style: ElevatedButton.styleFrom(
                                                //backgroundColor: Colors.blueAccent,
                                                shape: RoundedRectangleBorder(
                                                    side:
                                                        BorderSide(color: Colors.black),
                                                    borderRadius:
                                                        BorderRadius.circular(10))),
                                            child: Text(
                                              "Cancel",
                                              style: TextStyle(fontSize: 15),
                                            )),
                                        ElevatedButton(
                                            onPressed: () {
                                              Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatRateScreen(name: widget.name!)));
                                            },
                                            style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(10)),
                                                backgroundColor: const Color.fromARGB(
                                                    255, 98, 64, 251)),
                                            child: Text(
                                              "Submit",
                                              style: TextStyle(
                                                  fontSize: 15, color: Colors.white),
                                            )),
                                      ],
                                    )
                                  ],
                                ),
                              ),
          ],
        ),
      ),
    );
  }
}
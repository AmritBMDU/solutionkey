import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:like_button/like_button.dart';
import 'package:solution_key/DetailPage/Widget/custom_button.dart';
import 'package:solution_key/DetailPage/Widget/list_item.dart';
import 'package:solution_key/appcolor.dart';

class MyScreen extends StatefulWidget {
  MyScreen(
      {required this.profession,
      required this.name,
      required this.imgurl,
      this.isAvailable = true});
  String? profession;
  String? name;
  String? imgurl;
  String rating = "4.5";
  String language = "Hinglish,Hindi,English";
  String skill = "Life Coach";
  String sessions = "886";
  double charges = 25;
  bool view_more = false;
  bool isAvailable = true;

  @override
  State<MyScreen> createState() => _MyScreenState();
}

class _MyScreenState extends State<MyScreen> {
  String? rating;

  @override
  Widget build(BuildContext context) {
    double ratings = 0;
    return SafeArea(
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            //title: Text("Employer Details"),
            actions: [
              // IconButton(onPressed:(){}, icon: Icon(Icons.message_outlined)),
              //  IconButton(onPressed:(){}, icon: Icon(Icons.notifications_outlined)),
              IconButton(onPressed: () {}, icon: Icon(Icons.share_outlined)),
            ],
            elevation: 15,
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                    color: Colors.white,
                    height: 150,
                    width: MediaQuery.of(context).size.width,
                    child: Image.asset(
                      widget.imgurl!,
                      fit: BoxFit.cover,
                    )),
                Padding(
                  padding: const EdgeInsets.only(top: 0),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Card(
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10.0),
                            topRight: Radius.circular(10.0),
                          ),
                        ),
                        child: SizedBox(
                            width: MediaQuery.of(context).size.width,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 85,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(Icons.work_outline_outlined),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Text(widget.profession!,
                                              style: GoogleFonts.poppins(
                                                  color: Colors.grey,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 15))
                                        ],
                                      ),

                                      // LikeButton(
                                      // size: 30,
                                      // circleColor:
                                      // CircleColor(start: Color(0xff00ddff), end: Color(0xff0099cc)),
                                      // bubblesColor: BubblesColor(
                                      //   dotPrimaryColor: Color(0xff33b5e5),
                                      //   dotSecondaryColor: Color(0xff0099cc),
                                      // ),
                                      // likeBuilder: (bool isLiked) {
                                      //   return FaIcon(
                                      //    FontAwesomeIcons.thumbsUp,
                                      //     color: isLiked ? Colors.red : appcolor.appcolors,
                                      //     size: 30,
                                      //   );
                                      // },
                                      // //likeCount: 665,
                                      // )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Row(
                                    children: [
                                      Icon(Icons.language),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        widget.language!,
                                        style: GoogleFonts.poppins(
                                            color: Colors.grey,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(left: 8),
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.star,
                                            color: Colors.green,
                                            size: 25,
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Text(widget.rating!,
                                              style: GoogleFonts.poppins(
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 17)),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      width: 100,
                                      child: TextButton(
                                        onPressed: () {},
                                        child: Text(
                                          "Follow",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                        style: TextButton.styleFrom(
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(5)),
                                            backgroundColor: Colors.blue),
                                      ),
                                    )
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Row(
                                    children: [
                                      Text(
                                        "Expertise: ",
                                        style: TextStyle(
                                            fontSize: 17,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        "Relationship&Family",
                                        style: GoogleFonts.poppins(
                                            color: Colors.grey,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Row(
                                    children: [
                                      Text(
                                        "Availability: ",
                                        style: TextStyle(
                                            fontSize: 17,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        "Delhi,Noida,Gurugram",
                                        style: GoogleFonts.poppins(
                                            color: Colors.grey,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15),
                                      )
                                    ],
                                  ),
                                ),
                                //
                                const SizedBox(
                                  height: 10,
                                ),
                                Divider(
                                  thickness: 5,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Start at: ₹${widget.charges}/min",
                                        style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18),
                                      ),
                                      TextButton(
                                          onPressed: () {
                                            showModalBottomSheet(
                                                context: context,
                                                builder: (context) {
                                                  return ViewPackage();
                                                });
                                          },
                                          child: Row(
                                            children: [
                                              Text(
                                                "View Package",
                                                style: TextStyle(),
                                              ),
                                            ],
                                          ))
                                    ],
                                  ),
                                ),
                                Divider(
                                  thickness: 5,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                Container(
                                  width: 110,
                                  child: IconButton(
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        GallarySection()));
                                      },
                                      icon: Row(
                                        children: [
                                          Icon(Icons.photo_outlined),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Text(
                                            "Gallery",
                                            style: TextStyle(
                                                fontSize: 17,
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      )),
                                ),

                                Divider(
                                  thickness: 5,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    Column(
                                      children: [
                                        CustomIconButton(
                                          icon: (Icons.call),
                                          onPressed: () {},
                                        ),
                                        Text(
                                          "₹50/min",
                                          style: TextStyle(fontSize: 16),
                                        )
                                      ],
                                    ),
                                    Column(
                                      children: [
                                        CustomIconButton(
                                          icon: (Icons.video_call),
                                          onPressed: () {},
                                        ),
                                        Text(
                                          "₹100/min",
                                          style: TextStyle(fontSize: 16),
                                        )
                                      ],
                                    ),
                                    Column(
                                      children: [
                                        CustomIconButton(
                                          icon: (Icons
                                              .chat_bubble_outline_outlined),
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                        ChatScreen(
                                                          name: widget.name!,
                                                        )));
                                          },
                                        ),
                                        Text(
                                          "₹20/min",
                                          style: TextStyle(fontSize: 16),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Divider(
                                  thickness: 5,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(left: 8),
                                  child: About(
                                    work: 'NTT Data Inc,Nsez Sector 144 Noida',
                                    home: 'Noida, India',
                                    Location: 'Haridwar',
                                    follower: '1123',
                                  ),
                                ),

                                const SizedBox(
                                  height: 10,
                                ),

                                Divider(
                                  thickness: 5,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Schedules(profession: widget.profession!),

                                // const Padding(
                                //   padding: EdgeInsets.only(left: 8),
                                //   child: Text("Schedule",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w400),),
                                // ),
                                // const SizedBox(
                                //   height: 20,
                                // ),
                                // MyListItems(text: "Saturday", date:"2023-11-04", time:"06:00 pm- 07:00 pm"),
                                // Divider(
                                //   thickness:2,
                                //   color: Colors.grey.shade300,
                                //   indent: 10,
                                //   endIndent: 10,
                                // ),
                                // const SizedBox(
                                //   height: 20,
                                // ),
                                // MyListItems(text: "Monday", date:"2023-11-06", time:"06:00 pm- 07:00 pm"),
                                // Divider(
                                //   thickness:2,
                                //   color: Colors.grey.shade300,
                                //   indent: 10,
                                //   endIndent: 10,
                                // ),
                                // const SizedBox(
                                //   height: 20,
                                // ),
                                // MyListItems(text: "Tuesday", date:"2023-11-07", time:"06:00 pm- 07:00 pm"),
                                // Divider(
                                //   thickness:2,
                                //   color: Colors.grey.shade300,
                                //   indent: 10,
                                //   endIndent: 10,
                                // ),
                                // const SizedBox(
                                //   height: 20,
                                // ),
                                // MyListItems(text: "Today", date:"2023-11-08", time:"06:00 pm- 07:00 pm"),
                                // Divider(
                                //   thickness:2,
                                //   color: Colors.grey.shade300,
                                //   indent: 10,
                                //   endIndent: 10,
                                // ),
                                // const SizedBox(
                                //   height: 20,
                                // ),
                                // MyListItems(text: "Thursday", date:"2023-11-09", time:"06:00 pm- 07:00 pm"),
                                // Divider(
                                //   thickness:2,
                                //   color: Colors.grey.shade300,
                                //   indent: 10,
                                //   endIndent: 10,
                                // ),
                                // const SizedBox(
                                //   height: 20,
                                // ),
                                // MyListItems(text: "Friday", date:"2023-11-10", time:"06:00 pm- 07:00 pm"),
                                SizedBox(
                                  height: 5,
                                ),
                                Divider(
                                  thickness: 5,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Container(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(left: 10),
                                        child: Text(
                                          "Rating & Reviews",
                                          style: TextStyle(fontSize: 20),
                                        ),
                                      ),

                                      RatingReviews(
                                        ratings: widget.rating.toString(),
                                      ),
                                      Center(
                                        child: TextButton(
                                            onPressed: () {
                                              setState(() {
                                                widget.view_more =
                                                    !widget.view_more;
                                              });
                                            },
                                            child: Text("View More")),
                                      ),
                                      widget.view_more == true
                                          ? Container(
                                              height: 900,
                                              // color: Colors.amber,
                                              child: Column(
                                                children: [
                                                  ReviewWidget(
                                                      avatarName: "SB",
                                                      yourName:
                                                          "Saurabh Baghel",
                                                      stateAndCountry:
                                                          "Uttar Pradesh,India",
                                                      rating: 5,
                                                      review:
                                                          "afagj avasga avgas hgasv jaga gabaga bagga gagv agjscga gafab vat etga gbvs "),
                                                  ReviewWidget(
                                                      avatarName: "NS",
                                                      yourName: "Nisha",
                                                      stateAndCountry:
                                                          "Uttarakhand,India",
                                                      rating: 4,
                                                      review:
                                                          "afagj avasga avgas hgasv jaga gabaga bagga gagv agjscga gafab vat etga gbvs "),
                                                  ReviewWidget(
                                                      avatarName: "AM",
                                                      yourName: "Amit",
                                                      stateAndCountry:
                                                          "Harayana,India",
                                                      rating: 3,
                                                      review:
                                                          "afagj avasga avgas hgasv jaga gabaga bagga gagv agjscga gafab vat etga gbvs "),
                                                  ReviewWidget(
                                                      avatarName: "MH",
                                                      yourName: "Mohit",
                                                      stateAndCountry:
                                                          "Delhi,India",
                                                      rating: 4,
                                                      review:
                                                          "afagj avasga avgas hgasv jaga gabaga bagga gagv agjscga gafab vat etga gbvs "),
                                                  Center(
                                                    child: TextButton(
                                                        onPressed: () {
                                                          setState(() {
                                                            widget.view_more =
                                                                !widget
                                                                    .view_more;
                                                          });
                                                        },
                                                        child:
                                                            Text("View Less")),
                                                  ),
                                                ],
                                              ),
                                            )
                                          : Container(),

                                      //  Text(ratings.toString()),
                                      Divider(
                                        thickness: 5,
                                        color: Colors.grey.shade300,
                                        indent: 0,
                                        endIndent: 0,
                                      ),
                                    ],
                                  ),
                                ),
                                // SizedBox(
                                //   height: 30,
                                // ),
                                Posts(
                                  profileurl: widget.imgurl,
                                  imgurl: "assets/img_7.png",
                                  name: widget.name,
                                ),
                                Divider(
                                  thickness: 9,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                Posts(
                                    profileurl: widget.imgurl,
                                    imgurl: "assets/img_6.png",
                                    name: widget.name),
                                Divider(
                                  thickness: 9,
                                  color: Colors.grey.shade300,
                                  indent: 0,
                                  endIndent: 0,
                                ),
                                Posts(
                                    profileurl: widget.imgurl,
                                    imgurl: "assets/img_4.png",
                                    name: widget.name)
                              ],
                            )),
                      ),
                      //Circle Avatar
                      Positioned(
                        width: MediaQuery.of(context).size.width,
                        top: -65,
                        left: 5,
                        child: Row(
                          children: [
                            Stack(children: [
                              CircleAvatar(
                                radius: 75,
                                backgroundColor: Colors.transparent,
                                backgroundImage: AssetImage('assets/img_2.png'),
                                // child: ClipOval(child: Image.asset('assets/img_2.png')),
                              ),

                              // Positioned(
                              //     top: 110,
                              //     left: 220,
                              //     child: CircleAvatar(
                              //         radius: 20,
                              //         child: IconButton(onPressed: (){}, icon: Icon(Icons.camera_alt,color: Colors.blue,))))
                            ]),
                            Padding(
                              padding: const EdgeInsets.only(top: 60, left: 10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 25),
                                    child: Row(
                                      children: [
                                        Text(
                                          widget.name!,
                                          style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontSize: 20),
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.verified,
                                              color: Colors.blue,
                                              size: 16,
                                            ),
                                            // Text(
                                            //   'Verified',
                                            //   style: TextStyle(
                                            //     color: Colors.blue,
                                            //     fontSize: 12,
                                            //   ),
                                            // ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        widget.skill,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14,
                                            color: Colors.grey.shade600),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      if (widget.isAvailable!)
                                        Container(
                                          height: 10,
                                          width: 10,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors.green,
                                          ),
                                        )
                                      else
                                        Container(
                                          height: 10,
                                          width: 10,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors.red,
                                          ),
                                        ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      if (widget.isAvailable!)
                                        Text(
                                          "Online",
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold),
                                        )
                                      else
                                        Text(
                                          "Offline",
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold),
                                        )
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Text("Sessions: (${widget.sessions})"),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      // Container(

                                      //   height: 10,
                                      //   width: 10,
                                      //   decoration: BoxDecoration(
                                      //     shape: BoxShape.circle,
                                      //       color: Colors.green,
                                      //   ),
                                      // )
                                    ],
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
              ],
            ),
          )),
    );
  }
}

class GallarySection extends StatefulWidget {
  const GallarySection({super.key});

  @override
  State<GallarySection> createState() => _GallarySectionState();
}

class _GallarySectionState extends State<GallarySection> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Gallery",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      backgroundColor: Colors.black26,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                SizedBox(
                  width: 3,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.42,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 6),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          // height: 200,
                          child: Image.asset("assets/img_1.png"),
                        ),
                        Divider(
                          height: 10,
                          //  color: Colors.grey,
                        ),
                        Image.asset(
                          "assets/img_2.png",
                        ),
                        Divider(
                          height: 10,
                          // color: Colors.grey,
                        ),
                        Container(
                          // height: 200,
                          child: Image.asset("assets/img_4.png"),
                        ),
                        Divider(
                          height: 10,
                          //color: Colors.grey,
                        ),
                        Image.asset(
                          "assets/img_3.png",
                        ),
                        Divider(
                          height: 10,
                          // color: Colors.grey,
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  height: MediaQuery.of(context).size.height * 0,
                  width: 5,
                  color: Colors.grey,
                ),
                SizedBox(
                  width: 5,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.534,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        // height: 200,
                        child: Image.asset("assets/img_1.png"),
                      ),
                      Divider(
                        height: 10,
                        // color: Colors.grey,
                      ),
                      Image.asset(
                        "assets/img_2.png",
                      ),
                      Divider(
                        height: 10,
                        // color: Colors.grey,
                      ),
                      Image.asset(
                        "assets/img_6.png",
                        height: 187,
                      ),
                      Divider(
                        height: 10,
                        // color: Colors.grey,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              child: Image.asset("assets/img_6.png"),
            ),
            Divider(
              height: 10,
            ),
            Container(
              child: Image.asset("assets/img_2.png"),
            )
          ],
        ),
      ),
    );
  }
}

class CommentWidget extends StatelessWidget {
  final String username;
  final String comment;
  final String imgurl;

  CommentWidget(
      {required this.username, required this.comment, required this.imgurl});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 20,
            backgroundImage: AssetImage(imgurl),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5),
                Text(comment),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ViewPackage extends StatefulWidget {
  ViewPackage({
    super.key,
  });

  @override
  State<ViewPackage> createState() => _ViewPackageState();
}

class _ViewPackageState extends State<ViewPackage> {
  int selectedPackage = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      width: MediaQuery.of(context).size.width,
      child: Padding(
        padding: const EdgeInsets.all(0.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              child: Text(
                "Session Package",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.45,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  elevation: 5,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 5, left: 10),
                        child: Row(
                          children: [
                            Text(
                              "Total Duration: ",
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "45 min",
                              style: TextStyle(
                                  fontSize: 23, fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                      ),
                      Divider(
                        endIndent: 10,
                        indent: 10,
                        color: Colors.grey.shade300,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Radio(
                                  value: 1,
                                  groupValue: selectedPackage,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedPackage = value!;
                                    });
                                  }),
                              //   SizedBox(width: 15,),
                              Text(
                                "Single Session",
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold),
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Text("₹800",
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.orangeAccent)),
                          )
                        ],
                      ),
                      Divider(
                        endIndent: 10,
                        indent: 10,
                        color: Colors.grey.shade300,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Radio(
                                  value: 2,
                                  groupValue: selectedPackage,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedPackage = value!;
                                    });
                                  }),
                              //SizedBox(width: 15,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Pack of 2 Session",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Container(
                                    height: 22,
                                    width: 80,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color:
                                          Colors.orangeAccent.withOpacity(0.25),
                                    ),
                                    child: Center(
                                        child: Text(
                                      "Save 10%",
                                      style: TextStyle(
                                          color: Colors.orange,
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                    )),
                                  )
                                ],
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Text("₹1400",
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.orangeAccent)),
                          )
                        ],
                      ),
                      Divider(
                        endIndent: 10,
                        indent: 10,
                        color: Colors.grey.shade300,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Radio(
                                  value: 3,
                                  groupValue: selectedPackage,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedPackage = value!;
                                    });
                                  }),
                              // SizedBox(width: 15,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Pack of 4 Session",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Container(
                                    height: 22,
                                    width: 80,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color:
                                          Colors.orangeAccent.withOpacity(0.25),
                                    ),
                                    child: Center(
                                        child: Text(
                                      "Save 25%",
                                      style: TextStyle(
                                          color: Colors.orange,
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                    )),
                                  )
                                ],
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Text("₹2400",
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.orangeAccent)),
                          )
                        ],
                      ),
                      Divider(
                        endIndent: 10,
                        indent: 10,
                        color: Colors.grey.shade300,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Radio(
                                  value: 4,
                                  groupValue: selectedPackage,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedPackage = value!;
                                    });
                                  }),
                              //SizedBox(width: 15,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Pack of 6 Session",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Container(
                                    height: 22,
                                    width: 80,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color:
                                          Colors.orangeAccent.withOpacity(0.25),
                                    ),
                                    child: Center(
                                        child: Text(
                                      "Save 40%",
                                      style: TextStyle(
                                          color: Colors.orange,
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                    )),
                                  )
                                ],
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Text("₹2880",
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.orangeAccent)),
                          )
                        ],
                      ),
                      Divider(
                        height: 5,
                        endIndent: 10,
                        indent: 10,
                        color: Colors.grey.shade300,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                              //backgroundColor: Colors.orangeAccent,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text(
                            "Submit",
                            style: TextStyle(fontSize: 20),
                          )),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class About extends StatefulWidget {
  About(
      {super.key,
      required this.work,
      required this.home,
      required this.Location,
      required this.follower});
  String work;
  String home;
  String Location;
  String follower;

  @override
  State<About> createState() => _AboutState();
}

class _AboutState extends State<About> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Text(
                "About Us",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w500),
              )
            ],
          ),
          // SizedBox(height: 20,),
          // Row(children: [
          //   // Icon(Icons.work_outline_outlined),
          //   // SizedBox(width: 10,),
          //   // Text("Work At ${widget.work}",textAlign: TextAlign.start,style: TextStyle(fontSize: 16))
          // ],),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Icon(Icons.home_outlined),
              SizedBox(
                width: 10,
              ),
              Text("Lives in ${widget.home}",
                  textAlign: TextAlign.start, style: TextStyle(fontSize: 16))
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Icon(Icons.location_pin),
              SizedBox(
                width: 10,
              ),
              Text("From ${widget.Location}",
                  textAlign: TextAlign.start, style: TextStyle(fontSize: 16))
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Icon(Icons.follow_the_signs_rounded),
              SizedBox(
                width: 10,
              ),
              Text(
                "Followed by${widget.follower} people",
                textAlign: TextAlign.start,
                style: TextStyle(fontSize: 16),
              )
            ],
          )
        ],
      ),
    );
  }
}

class Schedules extends StatefulWidget {
  Schedules({super.key, required this.profession});
  String profession;

  @override
  State<Schedules> createState() => _SchedulesState();
}

class _SchedulesState extends State<Schedules> {
  int selectedPackage = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Take to this ${widget.profession} by\n scheduling a call",
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w500),
            ),
            ElevatedButton(
              onPressed: () {
                showModalBottomSheet(
                    context: context,
                    builder: ( context) {
                      TextEditingController timeinput1 =
                          TextEditingController();
                      TextEditingController timeinput2 =
                          TextEditingController();
                      // int groupValue=0;
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 20, left: 20),
                              child: Text(
                                "Schedule your Call",
                                style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, top: 10),
                              child: Text(
                                "*Date",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.normal),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, top: 10),
                              child: Container(
                                height: 50,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: Colors.black)),
                                child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: DateTimer()
                                    // child: TextFormField(
                                    //   decoration: InputDecoration(
                                    //     border: InputBorder.none,
                                    //     hintText: "Select Preferred Date",
                                    //   ),
                                    // ),
                                    ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, top: 10),
                              child: Text(
                                "*Preferred time",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.normal),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, top: 10),
                              child: Container(
                                height: 50,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: Colors.black)),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: TextFormField(
                                      controller: timeinput1,
                                      decoration: InputDecoration(
                                        border: InputBorder.none,
                                        hintText: "Select Preferred time",
                                      ),
                                      readOnly:
                                          true, //set it true, so that user will not able to edit text
                                      onTap: () async {
                                        TimeOfDay? pickedTime =
                                            await showTimePicker(
                                          initialTime: TimeOfDay.now(),
                                          context: context,
                                        );

                                        if (pickedTime != null) {
                                          print(pickedTime.format(
                                              context)); //output 10:51 PM
                                          DateTime parsedTime = DateFormat.jm()
                                              .parse(pickedTime
                                                  .format(context)
                                                  .toString());
                                          //converting to DateTime so that we can further format on different pattern.
                                          print(
                                              parsedTime); //output 1970-01-01 22:53:00.000
                                          String formattedTime =
                                              DateFormat('HH:mm:ss')
                                                  .format(parsedTime);
                                          print(
                                              formattedTime); //output 14:59:00
                                          //DateFormat() is from intl package, you can format the time on any pattern you need.

                                          setState(() {
                                            timeinput1.text =
                                                formattedTime; //set the value of text field.
                                          });
                                        } else {
                                          print("Time is not selected");
                                        }
                                      }),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, top: 10),
                              child: Text(
                                "*Second preferred time",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.normal),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, top: 10),
                              child: Container(
                                height: 50,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: Colors.black)),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText:
                                          "Select a second preferred time",
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 30),
                              child: Row(
                                children: [
                                  Radio(
                                      value: 1,
                                      groupValue: selectedPackage,
                                      onChanged: (value) {
                                        setState(() {
                                          selectedPackage = value!;
                                        });
                                      }),
                                  Text(
                                    "Chat",
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.normal),
                                  ),
                                  SizedBox(
                                    width: 40,
                                  ),
                                  Radio(
                                      value: 2,
                                      groupValue: selectedPackage,
                                      onChanged: (value) {
                                        setState(() {
                                          selectedPackage = value!;
                                        });
                                      }),
                                  Text(
                                    "Call",
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.normal),
                                  ),
                                  SizedBox(
                                    width: 40,
                                  ),
                                  Radio(
                                      value: 3,
                                      groupValue: selectedPackage,
                                      onChanged: (value) {
                                        setState(() {
                                          selectedPackage = value!;
                                        });
                                      }),
                                  Text(
                                    "Call",
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.normal),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                ElevatedButton(
                                    onPressed: () {},
                                    style: ElevatedButton.styleFrom(
                                        //backgroundColor: Colors.blueAccent,
                                        shape: RoundedRectangleBorder(
                                            side:
                                                BorderSide(color: Colors.black),
                                            borderRadius:
                                                BorderRadius.circular(10))),
                                    child: Text(
                                      "Cancel",
                                      style: TextStyle(fontSize: 15),
                                    )),
                                ElevatedButton(
                                    onPressed: () {},
                                    style: ElevatedButton.styleFrom(
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        backgroundColor: const Color.fromARGB(
                                            255, 98, 64, 251)),
                                    child: Text(
                                      "Submit",
                                      style: TextStyle(
                                          fontSize: 15, color: Colors.white),
                                    )),
                              ],
                            )
                          ],
                        ),
                      );
                    });
              },
              child: Text(
                "Schedule",
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
              style:
                  ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
            )
          ],
        ),
      ),
    );
  }
}

class DateTimer extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _DateTimer();
  }
}

class _DateTimer extends State<DateTimer> {
  TextEditingController dateInput = TextEditingController();

  @override
  void initState() {
    dateInput.text = ""; //set the initial value of text field
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
        child: TextField(
      controller: dateInput,
      //editing controller of this TextField
      decoration: InputDecoration(
          //icon of text field
          hintText: "Select preferred date" //label text of field
          ),
      readOnly: true,
      //set it true, so that user will not able to edit text
      onTap: () async {
        DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime.now(),
            //DateTime.now() - not to allow to choose before today.
            lastDate: DateTime(2100));

        if (pickedDate != null) {
          print(
              pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
          String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
          print(
              formattedDate); //formatted date output using intl package =>  2021-03-16
          setState(() {
            dateInput.text =
                formattedDate; //set output date to TextField value.
          });
        } else {}
      },
    ));
  }
}

class RatingReviews extends StatefulWidget {
  RatingReviews({super.key, required this.ratings});
  String ratings = "4.8";

  @override
  State<RatingReviews> createState() => _RatingReviewsState();
}

class _RatingReviewsState extends State<RatingReviews> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: [
          SizedBox(
            width: 5,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "${widget.ratings}/5",
                style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
              ),
              Text(
                "Based on 148 reviews",
                style: TextStyle(color: Colors.grey.shade700),
              ),
              Container(
                // width: 350,
                child: RatingBar.builder(
                  initialRating: 3,
                  minRating: 1,
                  direction: Axis.horizontal,
                  allowHalfRating: false,
                  itemCount: 5,
                  itemPadding: EdgeInsets.symmetric(horizontal: 1),
                  itemBuilder: (context, _) => Icon(
                    Icons.star,
                    color: Colors.green,
                  ),
                  onRatingUpdate: (rating) {
                    //ratings=rating;
                  },
                ),
              ),
            ],
          ),
          Container(
            height: 120,
            width: 1,
            color: Colors.grey,
          ),
          SizedBox(
            width: 10,
          ),
          Column(
            children: [
              ratingbars(
                rating_num: 5,
                width1: 80,
                width2: 40,
              ),
              ratingbars(rating_num: 4, width1: 60, width2: 60),
              ratingbars(rating_num: 3, width1: 20, width2: 100),
              ratingbars(rating_num: 2, width1: 15, width2: 105),
              ratingbars(rating_num: 1, width1: 10, width2: 110)
            ],
          )
        ],
      ),
    );
  }
}

class ratingbars extends StatelessWidget {
  ratingbars(
      {super.key,
      required this.rating_num,
      required this.width1,
      required this.width2});
  int rating_num;
  double width1;
  double width2;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              "${rating_num}",
              style: TextStyle(color: Colors.black, fontSize: 16),
            ),
            SizedBox(
              width: 10,
            ),
            Container(
              height: 10,
              width: width1,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15),
                      bottomLeft: Radius.circular(15)),
                  color: Colors.green),
            ),
            Container(
              height: 10,
              width: width2,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(15),
                      bottomRight: Radius.circular(15)),
                  color: Colors.grey.shade400),
            )
          ],
        )
      ],
    );
  }
}

class Posts extends StatefulWidget {
  Posts(
      {super.key,
      required this.profileurl,
      required this.imgurl,
      required this.name});
  String? profileurl;
  String? imgurl;
  String? name;
  bool isadded = false;
  String text = "add";

  @override
  State<Posts> createState() => _PostsState();
}

class _PostsState extends State<Posts> {
  TextEditingController _commentcontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      //color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // User's Photo
          Row(
            children: [
              CircleAvatar(
                radius: 24.0,
                backgroundImage: AssetImage(
                    widget.profileurl!), // replace with your photo path
              ),
              SizedBox(
                width: 20,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.name!,
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                  Text("29 nov")
                ],
              ),
            ],
          ),

          SizedBox(height: 10.0),

          // Post content
          Text(
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio.',
            style: TextStyle(fontSize: 16.0),
          ),
          SizedBox(
            height: 10,
          ),

          // Post Photo
          SizedBox(
            height: 200.0,
            width: MediaQuery.of(context).size.width,
            child: Image.asset(
              widget.imgurl!,
              fit: BoxFit.cover,
            ), // replace with your post photo path
          ),

          SizedBox(height: 16.0),

          // Like and Comment buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  LikeButton(
                    size: 30,
                    circleColor: CircleColor(
                        start: Color(0xff00ddff), end: Color(0xff0099cc)),
                    bubblesColor: BubblesColor(
                      dotPrimaryColor: Color(0xff33b5e5),
                      dotSecondaryColor: Color(0xff0099cc),
                    ),
                    likeBuilder: (bool isLiked) {
                      return FaIcon(
                        FontAwesomeIcons.thumbsUp,
                        color: isLiked ? Colors.red : appcolor.appcolors,
                        size: 30,
                      );
                    },
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Like")
                  //   likeCount: ,

                  // countBuilder: (int count, bool isLiked, String text) {
                  //   var color = isLiked ? Colors.deepPurpleAccent : Colors.grey;
                  //   Widget result;
                  //   if (count == 0) {
                  //     result = Text(
                  //       "love",
                  //       style: TextStyle(color: color),
                  //     );
                  //   } else
                  //     result = Text(
                  //       text,
                  //       style: TextStyle(color: color),
                  //     );
                  //   return result;
                  // },
                ],
              ),
              SizedBox(
                width: 100,
              ),
              InkWell(
                onTap: () {
                  showBottomSheet(
                      context: context,
                      builder: (BuildContext context) {
                        return Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                Center(
                                  child: Text("Comments"),
                                ),
                                CommentWidget(
                                  username: "Saurabh",
                                  comment: "Usefull Session",
                                  imgurl: 'assets/img_1.png',
                                ),
                                CommentWidget(
                                    username: 'john_doe',
                                    comment: 'This is an amazing photo!',
                                    imgurl: 'assets/img_2.png'),
                                CommentWidget(
                                    username: 'jane_smith',
                                    comment: 'Love it! 💖',
                                    imgurl: 'assets/img_1.png'),
                                CommentWidget(
                                    username: "Saurabh",
                                    comment: "Usefull Session",
                                    imgurl: 'assets/img_3.png'),
                                CommentWidget(
                                    username: 'john_doe',
                                    comment: 'This is an amazing photo!',
                                    imgurl: 'assets/img_4.png'),
                                // CommentWidget(
                                //   username: 'jane_smith',
                                //   comment: 'Love it! 💖', imgurl: 'assets/img_5.png'
                                // ),
                                CommentWidget(
                                    username: "Saurabh",
                                    comment: "Usefull Session",
                                    imgurl: 'assets/img_6.png'),
                                CommentWidget(
                                    username: 'john_doe',
                                    comment: 'This is an amazing photo!',
                                    imgurl: 'assets/img_7.png'),
                                widget.isadded == true
                                    ? CommentWidget(
                                        username: "Nisha",
                                        comment: widget.text,
                                        imgurl: "assets/img_3.png")
                                    : Container(
                                        height: 1,
                                      ),

                                Container(
                                    //  width: MediaQuery.of(context).size.width,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border:
                                            Border.all(color: Colors.black)),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: _commentcontroller,
                                        decoration: InputDecoration(
                                            hintText: "Comment",
                                            border: InputBorder.none),
                                      ),
                                    )),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    if (widget.isadded == false)
                                      ElevatedButton(
                                          onPressed: () {
                                            widget.text = _commentcontroller
                                                .text
                                                .trim()
                                                .toString();

                                            print(widget.text);
                                            setState(() {
                                              widget.isadded = true;
                                              _commentcontroller.clear();
                                            });
                                            print(widget.isadded);
                                            //   Navigator.pop(context);
                                          },
                                          style: ElevatedButton.styleFrom(
                                              //  backgroundColor: Colors.white,
                                              ),
                                          child: Image.asset(
                                            "assets/comment_icon.png",
                                            height: 25,
                                            width: 25,
                                          )),
                                    ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            widget.isadded = false;
                                          });
                                        },
                                        child: Text("Delete"))
                                  ],
                                )
                              ],
                            ),
                          ),
                        );
                      });
                },
                child: Row(
                  children: [
                    Image.asset(
                      'assets/comment_icon.png', // replace with your comment icon path
                      height: 24.0,
                      width: 24.0,
                    ),
                    SizedBox(width: 8.0),
                    Text('Comment'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ReviewWidget extends StatelessWidget {
  final String avatarName;
  final String yourName;
  final String stateAndCountry;
  final int rating;
  final String review;

  ReviewWidget({
    required this.avatarName,
    required this.yourName,
    required this.stateAndCountry,
    required this.rating,
    required this.review,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: 200,
      child: Card(
        elevation: 5,
        margin: EdgeInsets.all(10),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    child: Text(
                      avatarName,
                      style: TextStyle(fontSize: 20, color: Colors.green),
                    ),
                  ),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        yourName,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(stateAndCountry),
                    ],
                  ),
                  Spacer(),
                  Row(
                    children: List.generate(
                      5,
                      (index) => Icon(
                        index < rating ? Icons.star : Icons.star_border,
                        color: Colors.green,
                      ),
                    ),
                  ),
                ],
              ),
              //  Row(
              //   children: List.generate(
              //     5,
              //     (index) => Icon(
              //       index < rating ? Icons.star : Icons.star_border,
              //       color: Colors.green,
              //     ),
              //   ),
              // ),
              SizedBox(width: 5),
              //  Text('$rating stars'),
              SizedBox(height: 10),
              Text(
                review,
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400),
                textAlign: TextAlign.justify,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ChatScreen extends StatefulWidget {
  ChatScreen({required this.name});
  String name;
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  TextEditingController _messageController = TextEditingController();
  List<ChatMessage> _messages = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        title: Text(
          'Chat with ${widget.name}',
          style: TextStyle(fontSize: 20),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return _messages[index];
              },
            ),
          ),
          _buildInputField(),
        ],
      ),
    );
  }

  Widget _buildInputField() {
    return Container(
      padding: EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              decoration: InputDecoration(
                hintText: 'Type a message...',
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.send),
            onPressed: () {
              _sendMessage();
            },
          ),
        ],
      ),
    );
  }

  void _sendMessage() {
    if (_messageController.text.isNotEmpty) {
      setState(() {
        _messages.add(
          ChatMessage(
            text: _messageController.text,
            isUser: true,
          ),
        );
        _messageController.clear();
      });
    }
  }
}

class ChatMessage extends StatelessWidget {
  final String text;
  final bool isUser;

  ChatMessage({required this.text, required this.isUser});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser) CircleAvatar(), // Display avatar for received messages
          Container(
            decoration: BoxDecoration(
              color: isUser ? Colors.green : Colors.grey,
              borderRadius: BorderRadius.circular(8.0),
            ),
            padding: EdgeInsets.all(10.0),
            margin: EdgeInsets.all(5.0),
            child: Text(
              text,
              style: TextStyle(color: Colors.white),
            ),
          ),
          if (isUser)
            CircleAvatar(
              child: Text("SB"),
            ), // Display avatar for sent messages
        ],
      ),
    );
  }
}
